#!/bin/bash
# Installs "NH Driver Quiz.app" (its own window, Dock icon, and menu bar).
# Run with:  bash ~/Downloads/install_nh_quiz.sh
set -e

NAME="NH Driver Quiz"
DEST="/Applications"
if [ ! -w "$DEST" ]; then DEST="$HOME/Applications"; mkdir -p "$DEST"; fi
APP="$DEST/$NAME.app"
WORK="$(mktemp -d)"

echo "Writing files…"
cat > "$WORK/quiz.html" <<'__HTML_END__'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NH Driver Quiz</title>
<style>
  :root {
    --bg: #f5f5f7; --panel: #ffffff; --text: #1d1d1f; --muted: #6e6e73; --faint: #a1a1a6;
    --line: #e2e2e7; --accent: #0a66d9; --accent-soft: rgba(10,102,217,.10);
    --green: #1f9d55; --green-soft: rgba(31,157,85,.10); --red: #d93636; --red-soft: rgba(217,54,54,.09);
    --yellow: #b7791f; --yellow-soft: rgba(214,158,46,.12); --orange: #dd6b20;
    --radius: 12px;
  }
  @media (prefers-color-scheme: dark) {
    :root {
      --bg: #1c1c1e; --panel: #2c2c2e; --text: #f5f5f7; --muted: #a1a1a6; --faint: #6e6e73;
      --line: #3a3a3c; --accent: #4c9dff; --accent-soft: rgba(76,157,255,.16);
      --green: #34c06d; --green-soft: rgba(52,192,109,.14); --red: #ff6363; --red-soft: rgba(255,99,99,.13);
      --yellow: #e9b949; --yellow-soft: rgba(233,185,73,.13); --orange: #f6963f;
    }
  }
  * { box-sizing: border-box; }
  html, body { margin: 0; height: 100%; }
  body { font: 15px/1.45 -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", sans-serif;
         background: var(--bg); color: var(--text); -webkit-font-smoothing: antialiased; }
  button { font: inherit; color: inherit; cursor: pointer; }
  input[type=text], input[type=search] { font: inherit; color: var(--text); }

  .app { display: grid; grid-template-columns: 240px 1fr; height: 100vh; }
  .side { background: var(--panel); border-right: 1px solid var(--line); padding: 18px 12px; display: flex; flex-direction: column; gap: 4px; }
  .brand { font-weight: 700; font-size: 17px; padding: 4px 10px 14px; }
  .brand small { display: block; font-weight: 400; font-size: 12px; color: var(--muted); }
  .nav { display: flex; gap: 10px; align-items: flex-start; text-align: left; border: 0; background: none; padding: 9px 10px; border-radius: 9px; width: 100%; }
  .nav:hover { background: var(--accent-soft); }
  .nav.on { background: var(--accent); color: #fff; }
  .nav.on small { color: rgba(255,255,255,.85); }
  .nav .ico { font-size: 17px; width: 20px; text-align: center; }
  .nav b { display: block; font-weight: 600; }
  .nav small { display: block; font-size: 12px; color: var(--muted); }
  .side .stats { margin-top: auto; border-top: 1px solid var(--line); padding: 12px 10px 0; font-size: 13px; color: var(--muted); }
  .link { border: 0; background: none; color: var(--accent); padding: 0; font-size: 12px; }

  .main { overflow: hidden; display: flex; flex-direction: column; min-width: 0; }
  .scroll { overflow-y: auto; flex: 1; }
  .wrap { max-width: 780px; margin: 0 auto; padding: 32px; }
  h1 { font-size: 30px; margin: 0 0 6px; }
  .muted { color: var(--muted); }
  .faint { color: var(--faint); }
  .tag { display: inline-block; font-size: 11px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase;
         padding: 3px 8px; border-radius: 99px; background: var(--accent-soft); color: var(--accent); }
  .meta { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; font-size: 13px; }
  .meta .num { font-weight: 700; color: var(--muted); }
  .prompt { font-size: 22px; line-height: 1.5; margin: 16px 0 22px; }
  .fill { color: var(--accent); font-weight: 700; text-decoration: underline; text-underline-offset: 3px; }
  .box { border-radius: var(--radius); padding: 14px 16px; margin-top: 14px; border: 1px solid; }
  .box h4 { margin: 0 0 6px; font-size: 12px; text-transform: uppercase; letter-spacing: .05em; }
  .box.ans { background: var(--green-soft); border-color: color-mix(in srgb, var(--green) 30%, transparent); }
  .box.ans h4 { color: var(--green); }
  .box.ans p { font-size: 18px; font-weight: 600; margin: 0; }
  .box.why { background: var(--yellow-soft); border-color: color-mix(in srgb, var(--yellow) 30%, transparent); }
  .box.why h4 { color: var(--yellow); }
  .box.why p { margin: 0; }
  .bar { display: flex; align-items: center; gap: 12px; padding: 12px 20px; border-top: 1px solid var(--line); background: var(--panel); }
  .bar .grow { flex: 1; min-width: 0; }
  .btn { border: 1px solid var(--line); background: var(--panel); padding: 7px 14px; border-radius: 8px; font-weight: 500; }
  .btn:hover:not(:disabled) { border-color: var(--accent); }
  .btn.primary { background: var(--accent); border-color: var(--accent); color: #fff; font-weight: 600; min-width: 130px; }
  .btn.primary:hover:not(:disabled) { filter: brightness(1.08); }
  .btn:disabled { opacity: .45; cursor: default; }
  .kbd { font-size: 12px; color: var(--muted); }

  /* Learn */
  .learn { display: grid; grid-template-columns: 330px 1fr; height: 100%; min-height: 0; }
  .qlist { border-right: 1px solid var(--line); display: flex; flex-direction: column; min-height: 0; background: var(--panel); }
  .qlist .tools { padding: 12px; border-bottom: 1px solid var(--line); display: grid; gap: 8px; }
  .search { width: 100%; padding: 7px 10px; border: 1px solid var(--line); border-radius: 8px; background: var(--bg); outline: none; }
  .search:focus { border-color: var(--accent); }
  .qlist .items { overflow-y: auto; flex: 1; }
  .qi { display: grid; grid-template-columns: 28px 1fr auto; gap: 8px; width: 100%; text-align: left; border: 0; background: none;
        padding: 9px 12px; border-bottom: 1px solid var(--line); }
  .qi:hover { background: var(--accent-soft); }
  .qi.on { background: var(--accent); color: #fff; }
  .qi.on .faint, .qi.on .n { color: rgba(255,255,255,.8); }
  .qi .n { font-weight: 700; font-size: 12px; color: var(--muted); text-align: right; padding-top: 2px; font-variant-numeric: tabular-nums; }
  .qi .t { font-size: 13.5px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .qi .faint { font-size: 11px; }
  .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--orange); margin-top: 6px; }
  .learn-card { display: flex; flex-direction: column; min-height: 0; }
  .chk { display: flex; gap: 7px; align-items: center; font-size: 13px; cursor: pointer; }
  .missed-badge { color: var(--orange); font-weight: 700; font-size: 12px; }

  /* Setup */
  .cards { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin: 10px 0 24px; }
  .fcard { text-align: left; border: 1.5px solid var(--line); background: var(--panel); border-radius: var(--radius); padding: 16px; }
  .fcard:hover { border-color: var(--accent); }
  .fcard.on { border: 2px solid var(--accent); background: var(--accent-soft); }
  .fcard .top { display: flex; justify-content: space-between; font-size: 22px; }
  .fcard b { display: block; margin: 8px 0 4px; font-size: 16px; }
  .fcard span { color: var(--muted); font-size: 13.5px; }
  .radio { width: 20px; height: 20px; border-radius: 50%; border: 2px solid var(--faint); }
  .fcard.on .radio { border: 6px solid var(--accent); }
  .opts { display: grid; gap: 10px; margin-bottom: 26px; }
  .start { width: 100%; padding: 12px; font-size: 16px; }
  h3 { margin: 0; font-size: 15px; }

  /* Runner */
  .head { padding: 12px 20px; background: var(--panel); border-bottom: 1px solid var(--line); }
  .head .row { display: flex; align-items: center; gap: 14px; }
  .head .title { font-weight: 700; flex: 1; }
  .progress { height: 5px; background: var(--line); border-radius: 9px; margin-top: 10px; overflow: hidden; }
  .progress i { display: block; height: 100%; background: var(--accent); border-radius: 9px; transition: width .2s; }
  .choice { display: flex; align-items: center; gap: 14px; width: 100%; text-align: left; border: 1.5px solid var(--line);
            background: var(--panel); border-radius: 10px; padding: 13px 14px; margin-bottom: 10px; font-size: 17px; }
  .choice:hover:not(:disabled) { border-color: var(--accent); }
  .choice .k { flex: none; width: 30px; height: 30px; border-radius: 50%; display: grid; place-items: center; font-weight: 700;
               background: var(--line); font-size: 14px; }
  .choice .x { flex: 1; }
  .choice.sel { border: 2px solid var(--accent); background: var(--accent-soft); }
  .choice.sel .k { background: var(--accent); color: #fff; }
  .choice.good { border: 2px solid var(--green); background: var(--green-soft); }
  .choice.good .k { background: var(--green); color: #fff; }
  .choice.bad { border: 2px solid var(--red); background: var(--red-soft); }
  .choice.bad .k { background: var(--red); color: #fff; }
  .choice.dim { opacity: .55; }
  .choice:disabled { cursor: default; }
  .mark { font-size: 20px; font-weight: 700; }
  .mark.g { color: var(--green); } .mark.r { color: var(--red); }

  .field { margin-bottom: 14px; position: relative; }
  .field label { display: block; font-size: 12px; font-weight: 700; color: var(--muted); margin-bottom: 4px; }
  .field .inrow { display: flex; align-items: center; gap: 10px; }
  .field input { flex: 1; font-size: 18px; padding: 10px 12px; border: 2px solid var(--line); border-radius: 9px; background: var(--panel); outline: none; }
  .field input:focus { border-color: var(--accent); }
  .field input.g { border-color: var(--green); } .field input.r { border-color: var(--red); }
  .field input:disabled { opacity: .9; }
  .sugg { position: absolute; left: 0; right: 40px; top: 100%; margin-top: 4px; background: var(--panel); border: 1px solid var(--line);
          border-radius: 9px; box-shadow: 0 6px 20px rgba(0,0,0,.12); z-index: 10; overflow: hidden; }
  .sugg button { display: block; width: 100%; text-align: left; border: 0; background: none; padding: 8px 12px; font-size: 14.5px; }
  .sugg button.hl, .sugg button:hover { background: var(--accent-soft); }
  .sugg button::before { content: "↳ "; color: var(--faint); }
  .note { font-size: 12.5px; color: var(--muted); }

  .feedback { margin-top: 22px; padding: 18px; border-radius: 14px; }
  .feedback.g { background: var(--green-soft); } .feedback.r { background: var(--red-soft); }
  .fb-top { display: flex; align-items: center; gap: 12px; }
  .fb-top .big { font-size: 34px; line-height: 1; }
  .fb-top h2 { margin: 0; font-size: 22px; flex: 1; }
  .fb-top h2 small { display: block; font-size: 14px; font-weight: 400; color: var(--muted); }

  .strip { display: flex; gap: 4px; overflow-x: auto; padding: 2px; scrollbar-width: none; }
  .strip::-webkit-scrollbar { display: none; }
  .strip button { flex: none; width: 24px; height: 24px; border-radius: 50%; border: 1px solid var(--faint); background: none;
                  font-size: 10px; font-weight: 700; padding: 0; font-variant-numeric: tabular-nums; }
  .strip button.ans { background: color-mix(in srgb, var(--accent) 55%, transparent); color: #fff; border-color: transparent; }
  .strip button.cur { border: 2px solid var(--accent); }
  .strip button.cur.ans { background: var(--accent); }

  /* Results */
  .res-head { display: flex; gap: 24px; align-items: center; padding: 26px 32px; background: var(--panel); border-bottom: 1px solid var(--line); flex-wrap: wrap; }
  .ring { width: 110px; height: 110px; flex: none; }
  .res-head h1 { font-size: 28px; }
  .pass { font-weight: 700; font-size: 17px; }
  .res-actions { margin-left: auto; display: grid; gap: 8px; justify-items: end; }
  .seg { display: inline-flex; border: 1px solid var(--line); border-radius: 8px; overflow: hidden; }
  .seg button { border: 0; background: var(--panel); padding: 5px 14px; font-size: 13px; }
  .seg button.on { background: var(--accent); color: #fff; }
  .rrow { display: grid; grid-template-columns: 28px 1fr; gap: 12px; padding: 14px 0; border-bottom: 1px solid var(--line); }
  .rrow .q { font-weight: 600; }
  .rrow .line { margin-top: 4px; font-size: 14.5px; }
  .rrow .actions { display: flex; gap: 16px; margin-top: 6px; font-size: 13px; align-items: center; }
  .g-t { color: var(--green); } .r-t { color: var(--red); }
  .empty { display: grid; place-items: center; height: 100%; color: var(--muted); }

  .modal-back { position: fixed; inset: 0; background: rgba(0,0,0,.35); display: grid; place-items: center; z-index: 100; }
  .modal { background: var(--panel); border-radius: 14px; padding: 22px; width: min(420px, 90vw); box-shadow: 0 20px 60px rgba(0,0,0,.3); }
  .modal p { margin: 0 0 18px; font-size: 15.5px; }
  .modal .mbtns { display: flex; justify-content: flex-end; gap: 10px; }
  .btn.danger { background: var(--red); border-color: var(--red); color: #fff; }


  /* Sidebar groups + help tooltips */
  .side { position: relative; z-index: 20; overflow: visible; }
  .group-h { display: flex; align-items: center; gap: 6px; width: 100%; border: 0; background: none; padding: 14px 10px 6px;
             font-size: 11px; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; color: var(--muted); text-align: left; }
  .group-h .chev { transition: transform .15s; display: inline-block; }
  .group-h.closed .chev { transform: rotate(-90deg); }
  .sec-h { padding: 4px 10px 6px; font-size: 11px; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; color: var(--muted); }
  .nav.game { align-items: center; padding: 8px 10px; }
  .nav.game span.lbl { flex: 1; font-weight: 600; }
  .help { position: relative; flex: none; width: 20px; height: 20px; border-radius: 50%; display: grid; place-items: center;
          font-size: 12px; font-weight: 700; background: var(--line); color: var(--muted); cursor: help; }
  .nav.on .help { background: rgba(255,255,255,.25); color: #fff; }
  .help .tip { display: none; position: absolute; left: calc(100% + 14px); top: -12px; width: 290px; z-index: 50;
               background: var(--panel); color: var(--text); border: 1px solid var(--line); border-radius: 12px; padding: 14px 16px;
               box-shadow: 0 12px 34px rgba(0,0,0,.22); text-align: left; font-weight: 400; cursor: default; font-size: 13.5px; line-height: 1.45; }
  .help .tip::before { content: ""; position: absolute; left: -7px; top: 16px; width: 12px; height: 12px; background: var(--panel);
                       border-left: 1px solid var(--line); border-bottom: 1px solid var(--line); transform: rotate(45deg); }
  .help:hover .tip, .help:focus .tip { display: block; }
  .tip b { display: block; font-size: 15px; margin-bottom: 4px; }
  .tip .tip-h { font-size: 11px; font-weight: 700; letter-spacing: .05em; text-transform: uppercase; color: var(--accent); margin: 10px 0 4px; }
  .tip ul { margin: 0; padding-left: 18px; }
  .tip li { margin: 2px 0; }

  /* Lane Runner */
  .lr { display: flex; flex-direction: column; height: 100%; }
  .lr-top { background: var(--panel); border-bottom: 1px solid var(--line); padding: 12px 20px 14px; }
  .lr-stats { display: flex; gap: 22px; font-size: 14px; align-items: center; }
  .lr-stats b { font-size: 18px; font-variant-numeric: tabular-nums; margin-left: 4px; }
  .lr-q { font-size: 18px; font-weight: 600; margin: 10px 0 10px; line-height: 1.4; }
  .lr-choices { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .lr-ch { display: flex; gap: 10px; align-items: center; text-align: left; border: 2px solid transparent; background: var(--bg);
           border-radius: 9px; padding: 7px 10px; font-size: 14px; }
  .lr-ch span { flex: none; width: 24px; height: 24px; border-radius: 6px; background: var(--c); color: #fff; font-weight: 700; display: grid; place-items: center; font-size: 13px; }
  .lr-ch em { font-style: normal; }
  .lr-ch.on { border-color: var(--c); background: color-mix(in srgb, var(--c) 14%, transparent); }
  .lr-stage { position: relative; flex: 1; min-height: 260px; overflow: hidden; }
  .lr-stage canvas { display: block; cursor: pointer; }
  .lr-overlay { position: absolute; inset: 0; display: grid; place-items: center; background: rgba(0,0,0,.35); padding: 20px; overflow-y: auto; }
  .lr-overlay[hidden] { display: none; }
  .lr-card { background: var(--panel); border-radius: 16px; padding: 24px 26px; width: min(520px, 100%); box-shadow: 0 20px 60px rgba(0,0,0,.35); text-align: center; }
  .lr-card h2 { margin: 0 0 6px; }
  .lr-card .box { text-align: left; }
  .lr-how { text-align: left; color: var(--muted); font-size: 14px; margin: 12px 0 18px; padding-left: 20px; }
  .lr-big { font-size: 54px; font-weight: 800; line-height: 1.1; color: var(--accent); }
  .lr-missed { text-align: left; max-height: 200px; overflow-y: auto; font-size: 13.5px; display: grid; gap: 8px; }
  .lr-toast { position: absolute; left: 50%; top: 22px; transform: translate(-50%, -20px); opacity: 0; transition: all .25s;
              background: var(--panel); padding: 8px 16px; border-radius: 99px; font-weight: 600; font-size: 14px; box-shadow: 0 6px 20px rgba(0,0,0,.25);
              max-width: 90%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; pointer-events: none; }
  .lr-toast.show { opacity: 1; transform: translate(-50%, 0); }
  .lr-toast.g { color: var(--green); } .lr-toast.r { color: var(--red); }

  /* Number Crunch */
  .nc-top { display: flex; align-items: center; gap: 18px; font-size: 14px; }
  .nc-top .num { font-weight: 700; color: var(--muted); }
  .nc-dots { display: flex; gap: 5px; flex: 1; }
  .nc-dots i { width: 12px; height: 12px; border-radius: 50%; background: var(--line); }
  .nc-dots i.cur { background: var(--accent); }
  .nc-dots i.g { background: var(--green); } .nc-dots i.y { background: var(--yellow); } .nc-dots i.r { background: var(--red); }
  .nc-blank { display: inline-block; min-width: 54px; text-align: center; background: var(--accent); color: #fff; border-radius: 8px; padding: 0 10px; font-weight: 800; }
  .nc-input { display: flex; align-items: center; gap: 10px; justify-content: center; margin-top: 8px; }
  .nc-input input { width: 220px; font-size: 40px; font-weight: 800; text-align: center; padding: 8px 10px; border: 3px solid var(--line);
                    border-radius: 14px; background: var(--panel); outline: none; font-variant-numeric: tabular-nums; }
  .nc-input input:focus { border-color: var(--accent); }
  .nc-input.g input { border-color: var(--green); } .nc-input.r input { border-color: var(--red); }
  .nc-step { width: 44px; height: 44px; border-radius: 50%; border: 1px solid var(--line); background: var(--panel); font-size: 22px; font-weight: 700; }
  .nc-step:hover:not(:disabled) { border-color: var(--accent); }
  .nc-unit { font-size: 17px; color: var(--muted); min-width: 60px; }
  .nc-range { width: 100%; margin-top: 20px; accent-color: var(--accent); }
  .nc-scale { display: flex; justify-content: space-between; font-size: 12px; color: var(--faint); }
  .nc-hint { margin-top: 16px; padding: 12px 16px; border-radius: 12px; background: var(--accent-soft); font-size: 15.5px; text-align: center; }
  .nc-stars { font-size: 46px; color: #f5b301; letter-spacing: 6px; }
  .nc-stars span { color: var(--line); }

  /* Road Trip */
  .trip { display: grid; grid-template-columns: 1fr 360px; height: 100%; min-height: 0; }
  .trip-map { min-height: 0; padding: 14px; display: grid; place-items: center; overflow: hidden; }
  .trip-map svg { width: 100%; height: 100%; max-height: calc(100vh - 28px); }
  .land { fill: color-mix(in srgb, var(--green) 14%, var(--bg)); stroke: color-mix(in srgb, var(--green) 30%, transparent); stroke-width: 2; }
  .tree { font-size: 26px; }
  .road { fill: none; stroke: #5b6168; stroke-width: 16; stroke-linecap: round; }
  .road-line { fill: none; stroke: #f4d03f; stroke-width: 2.5; stroke-dasharray: 10 10; }
  .town { cursor: pointer; }
  .town .halo { fill: transparent; }
  .town .dot { fill: var(--panel); stroke: var(--faint); stroke-width: 3; }
  .town .glyph { font-size: 15px; font-weight: 800; fill: var(--muted); }
  .town.open .dot { fill: var(--accent); stroke: #fff; }
  .town.open .glyph { fill: #fff; }
  .town.open .halo { fill: color-mix(in srgb, var(--accent) 30%, transparent); animation: pulse 1.6s ease-in-out infinite; transform-box: fill-box; transform-origin: center; }
  .town.done .dot { fill: var(--green); stroke: #fff; }
  .town.done .glyph { fill: #fff; }
  .town.locked .glyph { font-size: 13px; }
  .town.sel .dot { stroke: var(--text); stroke-width: 4; }
  .town:hover .dot { stroke: var(--accent); }
  .tname { font-size: 16px; font-weight: 700; fill: var(--text); }
  .tsub { font-size: 12px; fill: var(--muted); }
  .town.locked .tname { fill: var(--muted); }
  .car { font-size: 28px; pointer-events: none; }
  @keyframes pulse { 0%,100% { transform: scale(1); opacity: .9; } 50% { transform: scale(1.25); opacity: .35; } }
  .trip-panel { border-left: 1px solid var(--line); background: var(--panel); padding: 24px; overflow-y: auto; }
  .trip-panel h1 { margin-top: 8px; }
  .trip-progress { font-size: 13.5px; color: var(--muted); margin-bottom: 22px; }
  .trip-stat { display: flex; justify-content: space-between; font-size: 14px; margin-bottom: 6px; }
  .trip-topics { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
  .leg-banner { width: 100%; padding: 14px 18px; border-radius: 12px; font-size: 16px; font-weight: 600; }
  .leg-banner.g { background: var(--green-soft); color: var(--green); } .leg-banner.r { background: var(--yellow-soft); color: var(--yellow); }

  @media (max-width: 820px) {
    .app { grid-template-columns: 1fr; grid-template-rows: auto 1fr; }
    .side { flex-direction: row; padding: 8px; overflow-x: auto; border-right: 0; border-bottom: 1px solid var(--line); }
    .brand, .nav small, .side .stats { display: none; }
    .learn { grid-template-columns: 1fr; grid-template-rows: 40% 60%; }
    .trip { grid-template-columns: 1fr; grid-template-rows: 55% 45%; }
    .help .tip { display: none !important; }
    .cards { grid-template-columns: 1fr; }
    .wrap { padding: 20px; }
  }
</style>
</head>
<body>
<div class="app">
  <aside class="side" id="side"></aside>
  <main class="main" id="main"></main>
</div>

<script>
const QS = [{"id": 1, "topic": "Lights", "q": "New Hampshire law requires every motor vehicle driven during the period from ___ to ___ to have their headlights activated.", "blanks": [{"a": "½ hour after sunset", "k": [["1/2", "half", "30"], ["sunset"]]}, {"a": "½ hour before sunrise", "k": [["1/2", "half", "30"], ["sunrise"]]}], "wrong": ["Sunset / sunrise", "1 hour after sunset / 1 hour before sunrise", "8 p.m. / 6 a.m."], "lesson": "Headlights go on from ½ hour after sunset to ½ hour before sunrise. Also turn them on any time you can't clearly see 1,000 feet ahead, like in rain, snow, or fog."}, {"id": 2, "topic": "Traffic Signals", "q": "Right turns on a red light are permitted after a stop except when ___ or ___.", "blanks": [{"a": "a sign prohibits it (\"No Turn on Red\")", "k": [["sign", "posted", "no turn", "prohibit"]]}, {"a": "a red arrow is showing", "k": [["arrow"]]}], "wrong": ["Another car is behind you / it is raining", "It is between 1 and 4 a.m. / you are under 18", "A yellow light is flashing / you are on a highway"], "lesson": "After a full stop you may turn right on red unless a sign says \"No Turn on Red\" or the signal is a red arrow. You still yield to pedestrians and cross traffic.", "anyOrder": true}, {"id": 3, "topic": "Vehicle Ownership", "q": "A privately owned motor vehicle must be inspected ___ during the owner's ___.", "blanks": [{"a": "annually", "k": [["annual", "yearly", "once a year", "every year", "each year", "1 year", "once"]]}, {"a": "birth month", "k": [["birth", "bday"]]}], "wrong": ["Every 2 years / registration month", "Annually / purchase anniversary", "Every 6 months / birth month"], "lesson": "Inspection is every year, during the owner's birth month. That's the same month the registration renews."}, {"id": 4, "topic": "Vehicle Ownership", "q": "New Hampshire does not title motor vehicles that have a model year of ___ or older.", "blanks": [{"a": "1999", "k": [["1999", "99"]]}], "wrong": ["1985", "1995", "2005"], "lesson": "NH titles vehicles from model year 2000 and newer. Model year 1999 and older are title-exempt (heavy trucks are the exception)."}, {"id": 5, "topic": "Signs", "q": "An eight-sided (octagonal) sign always means ___.", "blanks": [{"a": "Stop", "k": [["stop"]]}], "wrong": ["Yield", "Railroad crossing", "Do not enter"], "lesson": "The red octagon is used only for STOP. Make a full stop at the stop line, or before the crosswalk or intersection if there's no line."}, {"id": 6, "topic": "Speed", "q": "The speed limit when passing a school during school opening is ___.", "blanks": [{"a": "10 MPH below the posted limit", "k": [["10"], ["below", "less", "under", "slower", "minus", "lower", "off", "reduce"]]}], "wrong": ["15 MPH", "20 MPH", "5 MPH below the posted limit"], "lesson": "In a posted school zone, drive 10 MPH below the usual limit from 45 minutes before school opens until it opens, and from closing until 45 minutes after."}, {"id": 7, "topic": "Crashes", "q": "When you are involved in any accident causing death, personal injury, or aggregate damage of over $___, a written report must be filed within ___ days, which must be filed with the ___.", "blanks": [{"a": "1,000", "k": [["1000"]]}, {"a": "15", "k": [["15"]]}, {"a": "Division of Motor Vehicles (DMV)", "k": [["dmv", "motor vehicle", "division of motor", "department of motor", "dept of motor"]]}], "wrong": ["500 / 30 / local police", "1,000 / 30 / your insurance company", "2,500 / 10 / town clerk"], "lesson": "Death, injury, or over $1,000 in total damage means you file a written crash report with the DMV within 15 days. If police investigated the crash, you don't have to file a separate one."}, {"id": 8, "topic": "Licensing", "q": "The N.H. vision test requires that you can read letters and obtain a reading of 20/___.", "blanks": [{"a": "40", "k": [["40"]]}], "wrong": ["20", "30", "50"], "lesson": "You need 20/40 vision (with glasses or contacts if needed) to pass. Someone with sight in only one eye needs 20/30 (question 36)."}, {"id": 9, "topic": "Alcohol", "q": "In New Hampshire a blood alcohol level of ___% is evidence of legal intoxication.", "blanks": [{"a": "0.08", "k": [["0.08", ".08", "08"]]}], "wrong": ["0.10", "0.05", "0.02"], "lesson": "0.08% is the legal limit for drivers 21 and over. Under 21 it's 0.02% (question 27). For commercial drivers it's 0.04%."}, {"id": 10, "topic": "Licensing", "q": "Upon change of your name or address you should notify the ___ within ___ days.", "blanks": [{"a": "Division of Motor Vehicles (DMV)", "k": [["dmv", "motor vehicle", "division of motor", "department of motor", "dept of motor"]]}, {"a": "10", "k": [["10"]]}], "wrong": ["Local police / 30", "Town clerk / 60", "DMV / 30"], "lesson": "If you change your name or address, tell the DMV within 10 days."}, {"id": 11, "topic": "Emergency Vehicles", "q": "Upon being approached by an emergency vehicle, you should take what action: ___ and ___.", "blanks": [{"a": "pull over to the right edge of the road", "k": [["right", "pull over", "side of the road", "curb", "shoulder", "pull to"]]}, {"a": "stop until it passes", "k": [["stop"]]}], "wrong": ["Speed up / move to the left", "Pull left / keep driving slowly", "Stop where you are / turn on hazards"], "lesson": "When you see or hear an emergency vehicle with lights or siren, pull to the right edge of the road and stop. Stay stopped until it has passed. Never stop in an intersection."}, {"id": 12, "topic": "Penalties", "q": "A driver under the age of 20 is convicted of a motor vehicle violation. How many days will their license be suspended? ___", "blanks": [{"a": "20 days", "k": [["20"]]}], "wrong": ["10 days", "30 days", "60 days"], "lesson": "Under 20, any moving violation conviction means a suspension: 20 days for the 1st, 45 for the 2nd, 90 for the 3rd or more."}, {"id": 13, "topic": "Speed", "q": "The speed limit in a business or urban residence district is ___ MPH.", "blanks": [{"a": "30", "k": [["30"]]}], "wrong": ["25", "35", "20"], "lesson": "Business and urban residence districts: 30 MPH unless posted otherwise."}, {"id": 14, "topic": "Right-of-Way", "q": "If two vehicles enter an uncontrolled intersection at the same time, the vehicle on the ___ has to yield the right-of-way.", "blanks": [{"a": "left", "k": [["left"]]}], "wrong": ["right", "faster road", "smaller road"], "lesson": "At an uncontrolled intersection, the car on the left yields to the car on the right."}, {"id": 15, "topic": "Signs", "q": "A rectangular sign indicates a ___.", "blanks": [{"a": "regulation or guide information", "k": [["regulat", "rule", "guide", "direction", "law", "information", "instruct"]]}], "wrong": ["warning of a hazard ahead", "school zone", "railroad crossing"], "lesson": "Vertical rectangles usually give rules (like speed limits). Horizontal rectangles usually give guide information (directions and distances)."}, {"id": 16, "topic": "Signs", "q": "A brown sign means ___.", "blanks": [{"a": "recreation or cultural interest area", "k": [["recreat", "park", "cultur", "touris", "scenic", "historic", "camp", "leisure"]]}], "wrong": ["construction ahead", "motorist services", "directions to a highway"], "lesson": "Brown signs point to recreation and tourist spots like state parks, campgrounds, and historic sites."}, {"id": 17, "topic": "Traffic Signals", "q": "A solid red traffic signal means ___.", "blanks": [{"a": "come to a full stop and stay stopped until it turns green", "k": [["stop"]], "x": ["then go", "then proceed", "proceed when", "go when", "caution"]}], "wrong": ["slow down and proceed with caution", "stop, then go when clear (like a stop sign)", "yield to cross traffic"], "lesson": "Solid red means stop and wait until it turns green. The only exception is a right turn on red after stopping, where it's allowed. Stopping and then going when clear is what a flashing red means."}, {"id": 18, "topic": "Signs", "q": "A general warning sign with 5 sides (shaped like a house) indicates: ___.", "blanks": [{"a": "school zone or school crossing", "k": [["school"]]}], "wrong": ["pedestrian crossing", "no passing zone", "yield"], "lesson": "The 5-sided pentagon is only used for school zones and school crossings. Slow down and watch for children."}, {"id": 19, "topic": "Lane Markings", "q": "On multi-lane highways a dashed white line means ___.", "blanks": [{"a": "you may change lanes or pass when safe", "k": [["pass", "change lane", "lane change", "changing lane", "cross", "switch lane"]], "x": ["no pass", "not pass", "cant", "cannot", "dont", "do not", "never", "opposite"]}], "wrong": ["no passing allowed", "traffic moves in opposite directions", "edge of the road"], "lesson": "White lines separate lanes going the same direction. When the line is dashed, you may change lanes once it's safe."}, {"id": 20, "topic": "Highway Driving", "q": "If, when driving on a freeway or toll road, you miss your exit you should ___.", "blanks": [{"a": "continue to the next exit", "k": [["next exit", "next", "continue", "keep going", "go to the next"]]}], "wrong": ["back up on the shoulder", "make a U-turn through the median", "stop and wait for traffic to clear"], "lesson": "If you miss your exit, go on to the next one. Never back up or U-turn on a freeway."}, {"id": 21, "topic": "Emergency Vehicles", "q": "Fire apparatus responding to an alarm should not be followed closer than ___ feet.", "blanks": [{"a": "500", "k": [["500"]]}], "wrong": ["100", "300", "1,000"], "lesson": "Stay at least 500 feet behind a fire truck that's running its siren or flashing lights."}, {"id": 22, "topic": "Alcohol", "q": "Any person convicted for the first time of driving under the influence shall lose their license for at least ___.", "blanks": [{"a": "9 months", "k": [["9"], ["month"]]}], "wrong": ["30 days", "90 days", "6 months"], "lesson": "A first DUI conviction means losing your license for 9 months to 2 years, plus fines. Part of that time may be reduced if you complete an alcohol program."}, {"id": 23, "topic": "Speed", "q": "The speed limit in a rural residence district is ___ MPH.", "blanks": [{"a": "35", "k": [["35"]]}], "wrong": ["30", "45", "40"], "lesson": "Rural residence districts: 35 MPH unless posted otherwise. Business and urban districts are 30 MPH."}, {"id": 24, "topic": "Signs", "q": "A diamond shaped sign indicates ___.", "blanks": [{"a": "warning", "k": [["warn", "hazard", "caution", "danger"]]}], "wrong": ["regulation", "guide information", "school zone"], "lesson": "Diamond signs, usually yellow, warn you about something ahead, like curves, crossings, or merging lanes."}, {"id": 25, "topic": "Safe Driving", "q": "The closest, safe following distance is ___.", "blanks": [{"a": "4 seconds", "k": [["4"], ["second", "sec"]]}], "wrong": ["1 second", "2 seconds", "1 car length"], "lesson": "Keep at least 4 seconds behind the car ahead. When it passes a fixed object, count \"one-thousand-one...\" and you shouldn't reach that object before four. Leave more room in bad weather."}, {"id": 26, "topic": "Alcohol", "q": "Alcoholic beverages may be transported by a person under age 21 in a motor vehicle upon a public way if they are accompanied by ___.", "blanks": [{"a": "a parent, legal guardian, or legal-age spouse", "k": [["parent", "guardian", "spouse", "mom", "dad", "mother", "father"]]}], "wrong": ["any adult over 18", "a friend who is 21", "any licensed driver over 25"], "lesson": "Under 21, you can only carry alcohol in a vehicle if a parent, legal guardian, or legal-age spouse is with you."}, {"id": 27, "topic": "Alcohol", "q": "It is illegal for an operator under 21 years of age to have physical control of a vehicle while under the influence of intoxicating liquor or controlled drugs, prescription drugs, OTC drugs, or any other chemical substances, natural or synthetic, which impair a person's ability to drive or while having an alcohol concentration of ___% or more.", "blanks": [{"a": "0.02", "k": [["0.02", ".02", "02"]]}], "wrong": ["0.08", "0.04", "0.05"], "lesson": "Under 21, the limit is 0.02%, which is basically zero tolerance. The adult limit is 0.08%."}, {"id": 28, "topic": "Traffic Signals", "q": "A green arrow on a traffic light means ___.", "blanks": [{"a": "you may turn in the direction of the arrow", "k": [["turn", "arrow", "direction", "go", "proceed", "protected"]], "x": ["not allowed", "no turn", "must stop", "yield"]}], "wrong": ["you must stop", "turns are not allowed", "you must yield to oncoming traffic before turning"], "lesson": "A green arrow means you can go in the direction it points, and oncoming traffic is stopped for you. Still yield to any pedestrians or vehicles already in the intersection."}, {"id": 29, "topic": "Signaling", "q": "Drivers should signal at least ___ feet before a turn and, on the highway, drivers should signal at least ___ feet before changing lanes or exiting the roadway.", "blanks": [{"a": "100", "k": [["100"]]}, {"a": "500", "k": [["500"]]}], "wrong": ["50 / 200", "200 / 1,000", "100 / 300"], "lesson": "Signal at least 100 feet before a turn. On a highway, signal at least 500 feet before you change lanes or exit."}, {"id": 30, "topic": "Signs", "q": "A green sign indicates ___.", "blanks": [{"a": "directional guidance (directions and distances)", "k": [["direct", "guid", "distance", "destination", "where to go", "exit"]]}], "wrong": ["construction work", "a recreation area", "a regulation"], "lesson": "Green signs give directions: destinations, distances, exits, and highway info."}, {"id": 31, "topic": "Licensing", "q": "Drivers do not need a moped license if they already possess a ___ license.", "blanks": [{"a": "valid driver's", "k": [["driver", "operator", "valid", "class", "car", "regular", "standard"]]}], "wrong": ["learner's permit", "boating", "hunting"], "lesson": "Any valid driver's license covers a moped, so you don't need a separate moped license."}, {"id": 32, "topic": "Lane Markings", "q": "A solid yellow line on your side of the roadway parallel to the yellow center line means ___.", "blanks": [{"a": "no passing", "k": [["no pass", "not pass", "dont pass", "do not pass", "cannot pass", "cant pass", "no passing", "passing is not", "passing not"]]}], "wrong": ["passing allowed when safe", "two-way left turn lane", "edge of the road"], "lesson": "A solid yellow line on your side of the center line means don't pass. When your side is dashed, you can pass if it's safe."}, {"id": 33, "topic": "Night Driving", "q": "When driving at night and another vehicle approaches with their lights on you should: ___.", "blanks": [{"a": "dim your headlights to low beam and look toward the right edge of the road", "k": [["dim", "low"]]}], "wrong": ["flash your high beams back", "look directly at their headlights", "turn your headlights off"], "lesson": "Switch to low beams and look toward the right edge of your lane so the glare doesn't blind you. Don't wait for the other driver to dim first."}, {"id": 34, "topic": "Night Driving", "q": "You must put the headlights on ___ beams when approaching or overtaking another vehicle within ___ feet.", "blanks": [{"a": "low", "k": [["low", "dim"]]}, {"a": "150", "k": [["150"]]}], "wrong": ["High / 150", "Low / 500", "Parking / 300"], "lesson": "The law says dim to low beams within 150 feet of an oncoming car or a car you're following. Dimming sooner is safer."}, {"id": 35, "topic": "Signs", "q": "A down pointed triangle sign means ___.", "blanks": [{"a": "yield", "k": [["yield"]]}], "wrong": ["stop", "warning", "no passing"], "lesson": "An upside-down red and white triangle means YIELD. Slow down, be ready to stop, and let traffic and pedestrians go first."}, {"id": 36, "topic": "Licensing", "q": "A person with sight in one eye must read the 20/___ line to get a driver license.", "blanks": [{"a": "30", "k": [["30"]]}], "wrong": ["20", "40", "50"], "lesson": "With sight in only one eye, you need 20/30. With two eyes the requirement is 20/40."}, {"id": 37, "topic": "Railroad", "q": "When a train or railroad vehicle is approaching the intersection, a driver must stop behind the stop line or not less than ___ feet nor more than ___ feet from the nearest rail of the track.", "blanks": [{"a": "15", "k": [["15"]]}, {"a": "50", "k": [["50"]]}], "wrong": ["5 / 25", "10 / 100", "25 / 75"], "lesson": "Stop between 15 and 50 feet from the nearest rail. Don't go until the train has passed and it's clear."}, {"id": 38, "topic": "Traffic Signals", "q": "What does a flashing yellow traffic light mean? ___", "blanks": [{"a": "slow down and proceed with caution", "k": [["caution", "careful", "slow"]]}], "wrong": ["stop, then go", "the light is about to turn red", "stop and wait for green"], "lesson": "A flashing yellow means slow down, look carefully, and keep going. You don't have to stop."}, {"id": 39, "topic": "Signs", "q": "The color of a traffic sign indicates the type of message to be found on the sign. Red indicates ___.", "blanks": [{"a": "stop, yield, or a prohibited action", "k": [["stop", "yield", "prohibit", "not allowed", "do not", "dont", "forbid", "wrong way"]]}], "wrong": ["a warning", "construction", "motorist services"], "lesson": "Red means stop, yield, or don't, as in STOP, YIELD, DO NOT ENTER, and WRONG WAY signs."}, {"id": 40, "topic": "Parking", "q": "A person in charge of a vehicle must remove ___ from an unattended vehicle.", "blanks": [{"a": "the key", "k": [["key"]]}], "wrong": ["all valuables", "the registration", "the floor mats"], "lesson": "Before you leave a vehicle, stop the engine, set the parking brake, and take the key with you."}, {"id": 41, "topic": "School Buses", "q": "When approaching a school bus with flashing red lights in operation, you must bring your vehicle to a full stop in front or rear of the bus at a distance of ___ feet away.", "blanks": [{"a": "25", "k": [["25"]]}], "wrong": ["10", "50", "100"], "lesson": "Stop at least 25 feet away, from either direction, and stay stopped until the red lights turn off."}, {"id": 42, "topic": "Emergencies", "q": "If you become stuck in a heavy snowstorm or blizzard, attach a ___ to your vehicle and stay with the vehicle.", "blanks": [{"a": "brightly colored cloth (flag)", "k": [["cloth", "flag", "rag", "bright", "colored", "scarf", "ribbon", "material", "fabric", "bandana"]]}], "wrong": ["tow chain", "rope", "flashlight"], "lesson": "Tie a brightly colored cloth to the antenna or door handle so rescuers can find you, and stay with the car. Run the engine only a little at a time, with a window cracked and the tailpipe clear."}, {"id": 43, "topic": "Parking", "q": "Parking is not allowed within ___ feet of a fire hydrant.", "blanks": [{"a": "15", "k": [["15"]]}], "wrong": ["10", "20", "25"], "lesson": "Don't park within 15 feet of a fire hydrant."}, {"id": 44, "topic": "Emergencies", "q": "Which way should you steer if you have a blowout? ___", "blanks": [{"a": "straight ahead", "k": [["straight"]]}], "wrong": ["toward the blown tire", "away from the blown tire", "hard toward the shoulder"], "lesson": "In a blowout, grip the wheel firmly, keep the car going straight, and ease off the gas. Don't slam the brakes. Pull off the road once you've slowed down."}, {"id": 45, "topic": "Highway Driving", "q": "Almost all major roads are numbered with route signs. To make traveling easier, interstate routes are numbered by code. Even numbers are ___ routes, odd numbers are ___ routes.", "blanks": [{"a": "east-west", "k": [["east", "west"]]}, {"a": "north-south", "k": [["north", "south"]]}], "wrong": ["North-south / east-west", "Toll / free", "Loop / spur"], "lesson": "Even-numbered interstates run east-west (I-90). Odd-numbered ones run north-south (I-93, I-95)."}, {"id": 46, "topic": "Night Driving", "q": "Drive with the headlights on ___ beam to reduce the glaring reflection of the lights bouncing back at you in thick fog.", "blanks": [{"a": "low", "k": [["low", "dim"]]}], "wrong": ["high", "flashing", "no"], "lesson": "In fog, use low beams. High beams bounce off the fog and make it harder to see."}, {"id": 47, "topic": "Parking", "q": "You should not park the vehicle on the roadway unless it can be seen for a distance of ___ feet.", "blanks": [{"a": "200", "k": [["200"]]}], "wrong": ["100", "500", "1,000"], "lesson": "If you have to stop on the roadway, your vehicle must be visible for 200 feet in each direction."}, {"id": 48, "topic": "Alcohol", "q": "If you refuse to take a breath test your license will be ___.", "blanks": [{"a": "suspended", "k": [["suspend", "revok", "lose", "lost", "taken", "180"]], "x": ["only if", "unaffected", "nothing", "warning"]}], "wrong": ["unaffected", "marked with a warning", "suspended only if you're under 21"], "lesson": "Driving in NH means you've agreed to chemical testing (implied consent). Refusing gets your license suspended: 180 days for a first refusal, and longer with a prior offense."}, {"id": 49, "topic": "Pedestrians", "q": "When it becomes necessary to walk on a roadway, which side should you walk on? ___", "blanks": [{"a": "the left side, facing traffic", "k": [["left", "facing", "against"]]}], "wrong": ["the right side, with traffic", "the middle", "either side"], "lesson": "Walk on the left, facing oncoming traffic, so you can see cars coming and step out of the way."}, {"id": 50, "topic": "Signaling", "q": "The correct hand signal for slow or stop is ___.", "blanks": [{"a": "left arm extended downward", "k": [["down"]]}], "wrong": ["left arm extended upward", "left arm straight out", "right arm out the window"], "lesson": "Hand signals use your left arm: straight out for a left turn, up for a right turn, and down for slow or stop."}, {"id": 51, "topic": "Safe Driving", "q": "The area of the roadway that cannot be seen by looking in your mirrors is known as the ___.", "blanks": [{"a": "blind spot", "k": [["blind"]]}], "wrong": ["crumple zone", "buffer zone", "sight line"], "lesson": "Your mirrors can't show everything, so turn your head and check your blind spot before you change lanes or merge."}, {"id": 52, "topic": "Alcohol", "q": "What is the only thing that reduces the effects of alcohol? ___", "blanks": [{"a": "time", "k": [["time"]]}], "wrong": ["coffee", "a cold shower", "eating food"], "lesson": "Only time sobers you up. Your body clears roughly one drink per hour, and coffee, showers, and food don't change that."}, {"id": 53, "topic": "Licensing", "q": "Individuals holding an out-of-state license shall not be issued their New Hampshire driver's license until they ___ their out-of-state license.", "blanks": [{"a": "surrender", "k": [["surrender", "turn in", "give up", "hand in", "return", "relinquish", "hand over"]]}], "wrong": ["renew", "copy", "let expire"], "lesson": "You have to turn in your old state's license to get a NH license. You can only hold one."}, {"id": 54, "topic": "Licensing", "q": "A motor-driven cycle has an engine which produces no greater than ___ horsepower.", "blanks": [{"a": "5", "k": [["5"]]}], "wrong": ["2", "10", "15"], "lesson": "A motor-driven cycle is 5 brake horsepower or less. A moped is smaller: 50cc or 2 horsepower at most."}, {"id": 55, "topic": "Safe Driving", "q": "You must not drive a vehicle with more people than there are ___.", "blanks": [{"a": "seat belts (safety restraints)", "k": [["belt", "restraint", "seat"]]}], "wrong": ["doors", "windows", "adults"], "lesson": "Every passenger needs their own seat belt or safety restraint."}, {"id": 56, "topic": "Licensing", "q": "A \"B\" restriction on a license means that the driver must ___.", "blanks": [{"a": "wear corrective lenses (glasses or contacts)", "k": [["lens", "glass", "contact", "corrective", "spectacle"]]}], "wrong": ["drive in daylight only", "use an automatic transmission", "have an outside mirror"], "lesson": "Restriction B means you must wear glasses or contact lenses while driving."}, {"id": 57, "topic": "Licensing", "q": "Anyone driving a motor vehicle in New Hampshire must have in their possession a valid ___ and ___.", "blanks": [{"a": "driver's license", "k": [["license", "licence"]]}, {"a": "registration", "k": [["registr"]]}], "wrong": ["Insurance card / title", "Title / inspection sticker", "Birth certificate / license"], "lesson": "When you drive, always carry your valid license and the vehicle's registration.", "anyOrder": true}, {"id": 58, "topic": "Vehicle Ownership", "q": "A legal document showing ownership of a motor vehicle is called a ___.", "blanks": [{"a": "title", "k": [["title"]]}], "wrong": ["registration", "bill of sale", "inspection sticker"], "lesson": "The certificate of title proves who owns the vehicle. The registration lets you drive it on public roads."}, {"id": 59, "topic": "Alcohol", "q": "What does BAC stand for? ___", "blanks": [{"a": "Blood Alcohol Concentration", "k": [["blood"], ["alcohol"]]}], "wrong": ["Breath Analysis Count", "Basic Alcohol Check", "Body Alcohol Capacity"], "lesson": "BAC stands for Blood Alcohol Concentration, the percentage of alcohol in your blood (0.08% for adults, 0.02% under 21)."}, {"id": 60, "topic": "Vehicle Ownership", "q": "In the case of all private passenger vehicles registered by an individual, the registration expires annually on ___.", "blanks": [{"a": "the last day of the owner's birth month", "k": [["birth", "bday"]]}], "wrong": ["December 31", "the anniversary of the purchase date", "January 1"], "lesson": "Personal vehicle registrations expire at the end of the owner's birth month every year."}, {"id": 61, "topic": "Safe Driving", "q": "Skidding is caused by ___.", "blanks": [{"a": "driving too fast for conditions", "k": [["fast", "speed", "sudden", "brak", "slick", "ice", "slippery"]]}], "wrong": ["underinflated tires", "driving too slowly", "using cruise control"], "lesson": "Most skids happen because you're going too fast for road conditions, or braking or turning too hard. If you skid, ease off the gas and steer where you want the car to go."}, {"id": 62, "topic": "Pedestrians", "q": "The driver of every vehicle shall ___ for a person crossing the street who is being led by a guide dog or is holding in an extended position a white cane with a red tip.", "blanks": [{"a": "stop (yield the right-of-way)", "k": [["stop", "yield"]]}], "wrong": ["honk", "flash their lights", "slow to 15 MPH"], "lesson": "A guide dog or a white cane means the person is blind. Stop and let them cross, and don't honk."}, {"id": 63, "topic": "Signs", "q": "A pennant-shaped sign located on the left-hand side of the road points to the beginning of a ___.", "blanks": [{"a": "no passing zone", "k": [["no pass", "passing"]]}], "wrong": ["school zone", "construction zone", "sharp curve"], "lesson": "The sideways yellow pennant on the left side of the road marks where a no passing zone starts."}, {"id": 64, "topic": "Turning", "q": "To make a right turn, you should be in the ___ lane.", "blanks": [{"a": "right (far right)", "k": [["right"]]}], "wrong": ["left", "center", "any"], "lesson": "Get into the right-hand lane before a right turn, and turn into the right lane of the new road."}, {"id": 65, "topic": "Parking", "q": "If you are parking uphill with the curb, you should turn the wheels of the vehicle to the ___.", "blanks": [{"a": "left (away from the curb)", "k": [["left", "away"]]}], "wrong": ["right (toward the curb)", "straight ahead", "either direction"], "lesson": "Uphill with a curb, turn your wheels away from it (left) so the tires catch the curb if the car rolls back. Uphill with no curb and downhill: turn toward the edge (right)."}, {"id": 66, "topic": "Parking", "q": "Do not park within ___ feet of a crosswalk at an intersection.", "blanks": [{"a": "20", "k": [["20"]]}], "wrong": ["10", "15", "30"], "lesson": "Don't park within 20 feet of a crosswalk at an intersection."}, {"id": 67, "topic": "Pedestrians", "q": "When you walk on the roadway at night you should always ___.", "blanks": [{"a": "wear light-colored or reflective clothing (or carry a light)", "k": [["light", "bright", "white", "reflect", "flashlight", "visible"]]}], "wrong": ["wear dark clothing", "walk with traffic", "wear headphones"], "lesson": "At night, wear light colors or reflective gear, or carry a flashlight, so drivers can see you. Walk facing traffic."}, {"id": 68, "topic": "Licensing", "q": "An \"E\" restriction on a license means an ___ must be used.", "blanks": [{"a": "automatic transmission", "k": [["automatic", "auto"]]}], "wrong": ["outside mirror", "hand control", "corrective lens"], "lesson": "Restriction E means you can only drive vehicles with an automatic transmission."}, {"id": 69, "topic": "Bicycles", "q": "Persons riding a bicycle must ride on the ___ side of the roadway.", "blanks": [{"a": "right", "k": [["right"]]}], "wrong": ["left", "either", "middle"], "lesson": "Bikes ride on the right, with traffic. (Pedestrians are the opposite: they walk on the left, facing traffic.)"}, {"id": 70, "topic": "Licensing", "q": "New residents are allowed ___ days to obtain their New Hampshire driver's license.", "blanks": [{"a": "60", "k": [["60"]]}], "wrong": ["30", "90", "10"], "lesson": "New residents have 60 days to get a NH license."}, {"id": 71, "topic": "Traffic Signals", "q": "What should you do when you come to an intersection and the traffic light changes from green to yellow? ___", "blanks": [{"a": "stop if you can do so safely (if too close, proceed with caution)", "k": [["stop", "prepar", "slow"]]}], "wrong": ["speed up to beat the red", "slam on the brakes no matter what", "honk and go through"], "lesson": "Yellow means red is coming next. Stop if you can do it safely. If you're too close to stop safely, go through carefully."}, {"id": 72, "topic": "Traffic Signals", "q": "A red arrow on a traffic light means? ___", "blanks": [{"a": "stop. You may not go or turn in the direction of the arrow", "k": [["stop", "not", "no", "wait", "cant", "cannot", "dont"]], "x": ["turn after", "may turn", "can turn", "go after", "then turn", "then go", "caution"]}], "wrong": ["turn after stopping", "proceed with caution", "yield, then turn"], "lesson": "A red arrow means you can't go that way until it turns green, not even after stopping. That's why it's an exception to right-on-red."}, {"id": 73, "topic": "Licensing", "q": "Youth operators may not operate a vehicle between the hours of ___ and ___ before their 18th birthday.", "blanks": [{"a": "1:00 a.m.", "k": [["1"]]}, {"a": "4:00 a.m.", "k": [["4"]]}], "wrong": ["11 p.m. / 5 a.m.", "Midnight / 6 a.m.", "2 a.m. / 5 a.m."], "lesson": "Youth operators under 18 can't drive between 1:00 a.m. and 4:00 a.m."}, {"id": 74, "topic": "Parking", "q": "Parking is not allowed within ___ feet of a stop sign.", "blanks": [{"a": "30", "k": [["30"]]}], "wrong": ["15", "20", "50"], "lesson": "Don't park within 30 feet of a stop sign, yield sign, or traffic signal."}, {"id": 75, "topic": "Stopping", "q": "The distance you travel from when you see danger until you step on the brake pedal is called ___.", "blanks": [{"a": "reaction distance", "k": [["reaction", "perception", "thinking"]]}], "wrong": ["braking distance", "stopping distance", "following distance"], "lesson": "Reaction distance is how far you go between seeing a problem and hitting the brake. Braking distance is how far you go after that. Add them together to get total stopping distance."}, {"id": 76, "topic": "Signs", "q": "A white sign indicates ___.", "blanks": [{"a": "a regulation (law or rule of the road)", "k": [["regulat", "law", "rule"]]}], "wrong": ["a warning", "guide information", "construction"], "lesson": "White signs with black or red lettering give rules you have to follow, like speed limits or \"Keep Right.\""}, {"id": 77, "topic": "Railroad", "q": "A cross buck sign means ___.", "blanks": [{"a": "railroad crossing", "k": [["rail", "train"]]}], "wrong": ["four-way intersection", "hospital ahead", "school crossing"], "lesson": "The white X-shaped crossbuck marks a railroad crossing. Treat it like a yield sign and stop if a train is coming."}, {"id": 78, "topic": "Speed", "q": "What is the slowest you may travel on a New Hampshire interstate highway in good weather? ___", "blanks": [{"a": "45 MPH", "k": [["45"]]}], "wrong": ["35 MPH", "40 MPH", "55 MPH"], "lesson": "In good conditions, the minimum on a NH interstate is 45 MPH unless posted otherwise. Driving too slowly is dangerous too."}, {"id": 79, "topic": "Signs", "q": "What is indicated on a yellow sign? ___", "blanks": [{"a": "a general warning", "k": [["warn", "caution", "hazard", "danger"]]}], "wrong": ["a regulation", "a recreation area", "motorist services"], "lesson": "Yellow means a general warning about something ahead, like a curve, an intersection, deer, or slippery road."}, {"id": 80, "topic": "School Buses", "q": "What does it mean when a school bus displays yellow flashing lights? ___", "blanks": [{"a": "the bus is preparing to stop, so prepare to stop", "k": [["prepar", "about to", "going to", "slow", "ready", "will stop"]]}], "wrong": ["you may pass with caution", "the bus is broken down", "the bus is turning"], "lesson": "Flashing yellow (amber) lights mean the bus is about to stop and turn on its red lights. Slow down and get ready to stop."}, {"id": 81, "topic": "Licensing", "q": "What is a CDL license? ___", "blanks": [{"a": "Commercial Driver's License", "k": [["commercial"]]}], "wrong": ["Class D License", "Certified Driving License", "Combined Driver Learner permit"], "lesson": "A CDL is a Commercial Driver's License. You need one for vehicles over 26,000 lbs, buses that carry 16 or more people, or hazardous materials."}, {"id": 82, "topic": "Licensing", "q": "To operate a motorcycle, you must have a ___.", "blanks": [{"a": "motorcycle license (endorsement)", "k": [["motorcycle", "endorse", "class m"]]}], "wrong": ["moped permit", "commercial license", "learner's permit"], "lesson": "To ride a motorcycle you need a motorcycle license or endorsement. A regular car license isn't enough."}, {"id": 83, "topic": "Stopping", "q": "The distance you travel while operating your brakes to bring your vehicle to a stop is called ___.", "blanks": [{"a": "braking distance", "k": [["brak"]]}], "wrong": ["reaction distance", "following distance", "perception distance"], "lesson": "Braking distance is how far you go from pressing the brake until you stop. It grows quickly as speed goes up (question 99)."}, {"id": 84, "topic": "Bicycles", "q": "Are bicyclists subject to the same laws and rules as automobile drivers? ___", "blanks": [{"a": "Yes", "k": [["yes", "same", "yep", "yeah"]]}], "wrong": ["No", "Only at night", "Only on highways"], "lesson": "Yes. Cyclists follow the same traffic laws as drivers: stop at signs and lights, signal, and ride with traffic."}, {"id": 85, "topic": "Licensing", "q": "What is the heaviest vehicle you may operate with your operator's license? ___", "blanks": [{"a": "26,000 lbs GVWR", "k": [["26000", "26 000"]]}], "wrong": ["10,000 lbs", "18,000 lbs", "33,000 lbs"], "lesson": "A regular (Class D) license covers vehicles up to 26,000 lbs gross vehicle weight rating. Anything heavier needs a CDL."}, {"id": 86, "topic": "Licensing", "q": "Youth operators may only have one (1) nonfamily member with them while operating a vehicle for the first ___ months after their license is issued.", "blanks": [{"a": "6", "k": [["6"]]}], "wrong": ["3", "12", "9"], "lesson": "For the first 6 months, youth operators under 18 can carry only one passenger under 25 who isn't family, unless a supervising adult 25 or older is in the car."}, {"id": 87, "topic": "Licensing", "q": "What is the youngest age one may legally practice drive a vehicle in New Hampshire? ___", "blanks": [{"a": "15½", "k": [["15 1/2", "15.5", "15 and 1/2", "15 and a half"]]}], "wrong": ["15", "16", "14"], "lesson": "You can start practice driving at 15½, with a supervisor (question 88). You have to be 16 to get a license."}, {"id": 88, "topic": "Licensing", "q": "Someone who is practice driving must be accompanied by a person seated on the front seat who is at least ___ and holds a ___.", "blanks": [{"a": "25 years old", "k": [["25"]]}, {"a": "valid driver's license", "k": [["license", "licence"]]}], "wrong": ["18 / learner's permit", "21 / valid driver's license", "25 / CDL"], "lesson": "The supervisor sits in the front passenger seat, is at least 25, and has a valid driver's license."}, {"id": 89, "topic": "Safety Belts", "q": "Your safety belt will keep you from ___, thereby helping you to keep control of the vehicle.", "blanks": [{"a": "sliding or being thrown from the driver's seat", "k": [["slid", "thrown", "eject", "move", "seat", "fall", "fly", "position"]]}], "wrong": ["speeding", "getting distracted", "the airbag deploying"], "lesson": "A seat belt keeps you in the driver's seat during a sudden swerve or stop, so you stay in control of the car."}, {"id": 90, "topic": "Safety Belts", "q": "New Hampshire law requires people to wear a safety belt or be restrained in a safety seat until ___ years of age.", "blanks": [{"a": "18", "k": [["18"]]}], "wrong": ["12", "16", "21"], "lesson": "Everyone under 18 must wear a seat belt or ride in the right child safety seat. It's smart for everyone."}, {"id": 91, "topic": "Safety Belts", "q": "New Hampshire law requires operators and/or passengers on a motorcycle to wear an approved protective helmet until ___ years of age.", "blanks": [{"a": "18", "k": [["18"]]}], "wrong": ["16", "21", "25"], "lesson": "Motorcycle riders and passengers under 18 have to wear an approved helmet."}, {"id": 92, "topic": "Right-of-Way", "q": "A ___ directing traffic overrules any traffic light or sign and must be obeyed.", "blanks": [{"a": "police officer", "k": [["police", "officer", "cop", "trooper", "law enforcement"]]}], "wrong": ["pedestrian", "bus driver", "tow truck driver"], "lesson": "A police officer directing traffic overrides any light or sign. Do what the officer signals."}, {"id": 93, "topic": "Lane Markings", "q": "A yellow line on the left edge of a street or roadway indicates ___.", "blanks": [{"a": "the left edge of a divided highway or one-way road", "k": [["divided", "one way", "median", "left edge", "edge"]]}], "wrong": ["two-way traffic", "passing is allowed", "a bike lane"], "lesson": "A yellow edge line on your left means you're on a divided highway or one-way road, so the left side is the edge."}, {"id": 94, "topic": "Right-of-Way", "q": "A ___ has the right of way over all vehicles at intersections and crosswalks.", "blanks": [{"a": "pedestrian", "k": [["pedestrian", "walker", "person walking", "people walking", "someone walking"]]}], "wrong": ["motorcycle", "bus", "truck"], "lesson": "Pedestrians have the right of way at intersections and crosswalks. Always be ready to stop for them."}, {"id": 95, "topic": "Turning", "q": "When making a turn at an intersection, you should turn into the lane that is ___ to you.", "blanks": [{"a": "closest (nearest)", "k": [["closest", "nearest", "near", "close"]]}], "wrong": ["farthest", "in the center", "least crowded"], "lesson": "Turn into the lane closest to you: right turns into the right lane, left turns into the left lane. Don't swing wide."}, {"id": 96, "topic": "Signaling", "q": "You should signal before you change directions. Signals should be used before: (name all 5)", "blanks": [{"a": "turning", "k": [["turn"]]}, {"a": "changing lanes", "k": [["lane"]]}, {"a": "pulling away from the curb (or parking)", "k": [["curb", "park", "pull"]]}, {"a": "slowing down or stopping", "k": [["slow", "stop"]]}, {"a": "passing or merging", "k": [["pass", "merg"]]}], "wrong": ["Turning, speeding up, parking, honking, passing", "Accelerating, turning, reversing, entering a driveway, braking hard", "Changing lanes, speeding up, starting the engine, passing, honking"], "lesson": "Signal whenever other drivers need to know what you're about to do: turning, changing lanes, pulling away from the curb, slowing or stopping, and passing.", "anyOrder": true, "full": "Turning, changing lanes, pulling away from the curb, slowing/stopping, passing"}, {"id": 97, "topic": "Traffic Signals", "q": "What does a flashing red light mean? ___", "blanks": [{"a": "stop, then proceed when it's safe (like a stop sign)", "k": [["stop"]], "x": ["without stop", "wait", "green", "dont stop", "no stop", "not stop"]}], "wrong": ["slow down and proceed without stopping", "the signal is broken, so just yield", "stop and wait until it turns green"], "lesson": "A flashing red works like a stop sign: come to a full stop, then go when it's safe."}, {"id": 98, "topic": "Signs", "q": "What does an orange sign indicate? ___", "blanks": [{"a": "construction / road work zone", "k": [["construct", "work", "repair", "maintenance"]]}], "wrong": ["a school zone", "a recreation area", "a railroad crossing"], "lesson": "Orange means construction or a work zone. Slow down, follow the flaggers, and watch for workers. Fines are often doubled there."}, {"id": 99, "topic": "Stopping", "q": "When you double your speed, the stopping distance is nearly ___ times greater.", "blanks": [{"a": "4", "k": [["4"]]}], "wrong": ["2", "3", "8"], "lesson": "Stopping distance grows with the square of your speed, so doubling your speed makes it about 4 times longer."}, {"id": 100, "topic": "Safe Driving", "q": "Hydroplaning is when ___.", "blanks": [{"a": "your tires ride on a layer of water and lose contact with the road", "k": [["water"]]}], "wrong": ["your brakes overheat", "your tires skid on ice", "your engine floods"], "lesson": "In heavy rain, your tires can ride up on a layer of water and lose contact with the road. If that happens, ease off the gas, don't brake hard, and keep the wheel straight. Slowing down in rain prevents it."}];

/* ---------- storage (optional; works without it) ---------- */
const STORE_KEY = "nhq_missed_v1";
let missed = new Set();
try { missed = new Set(JSON.parse(localStorage.getItem(STORE_KEY) || "[]")); } catch (e) {}
function saveMissed() { try { localStorage.setItem(STORE_KEY, JSON.stringify([...missed])); } catch (e) {} }
function record(id, ok) {
  ok ? missed.delete(id) : missed.add(id); saveMissed();
  ok ? known.add(id) : known.delete(id); lsSet("nhq_known_v1", JSON.stringify([...known]));
}

/* ---------- helpers ---------- */
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const answerText = q => q.full || q.blanks.map(b => b.a).join(" / ");
const quizPrompt = q => q.q.replace(/___/g, "_______");
const blanksInline = q => q.q.split("___").length - 1 === q.blanks.length;

function ask(msg, okText = "OK", danger = false) {
  return new Promise(res => {
    const d = document.createElement("div");
    d.className = "modal-back";
    d.innerHTML = `<div class="modal" role="dialog"><p>${esc(msg)}</p><div class="mbtns">
      <button class="btn" data-m="0">Cancel</button>
      <button class="btn ${danger ? "danger" : "primary"}" data-m="1">${esc(okText)}</button></div></div>`;
    const close = v => { d.remove(); res(v); };
    d.addEventListener("click", e => {
      e.stopPropagation();
      const b = e.target.closest("[data-m]");
      if (b) close(b.dataset.m === "1"); else if (e.target === d) close(false);
    });
    d.addEventListener("keydown", e => {
      e.stopPropagation();
      if (e.key === "Escape") { e.preventDefault(); close(false); }
    });
    document.body.appendChild(d);
    d.querySelector('[data-m="1"]').focus();
  });
}

/* ---------- typed-answer grading ---------- */
const NUMW = { zero:"0", one:"1", two:"2", three:"3", four:"4", five:"5", six:"6", seven:"7", eight:"8", nine:"9", ten:"10",
  eleven:"11", twelve:"12", fifteen:"15", eighteen:"18", twenty:"20", thirty:"30", forty:"40", fifty:"50", sixty:"60", half:"1/2" };
const isD = c => c >= "0" && c <= "9";
function normalize(s) {
  s = s.toLowerCase().replace(/½/g, " 1/2 ").replace(/['’]/g, "");
  const ch = [...s], out = [];
  for (let i = 0; i < ch.length; i++) {
    const c = ch[i], prev = ch[i - 1] || "", next = ch[i + 1] || "";
    if (c === "," || c === "$") {
      if (c === "," && isD(prev) && isD(next)) continue;
      out.push(" ");
    } else if (c === ".") {
      out.push(isD(next) ? "." : " ");
    } else if (c === "/" || (c >= "a" && c <= "z") || isD(c)) {
      const last = out[out.length - 1];
      if (last && last !== " " && last !== "." && last !== "/" && c !== "/" && isD(last) !== isD(c)) out.push(" ");
      out.push(c);
    } else out.push(" ");
  }
  return out.join("").split(/\s+/).filter(Boolean).map(t => NUMW[t] || t);
}
const tokMatch = (inp, alt) => /\d/.test(alt) ? inp === alt : inp.startsWith(alt);
function phraseIn(alt, toks) {
  const at = normalize(alt);
  if (!at.length) return false;
  for (let i = 0; i + at.length <= toks.length; i++)
    if (at.every((a, j) => tokMatch(toks[i + j], a))) return true;
  return false;
}
function gradeBlank(text, b) {
  const toks = normalize(text || "");
  if (!toks.length) return false;
  if ((b.x || []).some(x => phraseIn(x, toks))) return false;
  return b.k.every(g => g.some(a => phraseIn(a, toks)));
}
function gradeTyped(inputs, q) {
  if (!q.anyOrder) return q.blanks.map((b, i) => gradeBlank(inputs[i], b));
  const used = new Set();
  return q.blanks.map(b => {
    for (let j = 0; j < inputs.length; j++) if (!used.has(j) && gradeBlank(inputs[j], b)) { used.add(j); return true; }
    return false;
  });
}

/* ---------- autofill ---------- */
const POOL = (() => {
  const seen = new Set(), out = [];
  QS.forEach(q => q.blanks.forEach(b => { const k = b.a.toLowerCase(); if (!seen.has(k)) { seen.add(k); out.push(b.a); } }));
  return out.sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
})();
const POOL_TOKS = POOL.map(p => normalize(p));
function suggest(text) {
  const t = text.trim().toLowerCase();
  if (!t) return [];
  const tt = normalize(t);
  const scored = [];
  POOL.forEach((p, i) => {
    const lp = p.toLowerCase();
    if (lp === t) return;
    const toks = POOL_TOKS[i];
    const wordMatch = tt.length && tt.every(w => toks.some(c => c.startsWith(w)));
    let score = -1;
    if (lp.startsWith(t)) score = 0;
    else if (wordMatch && toks[0] && toks[0].startsWith(tt[0])) score = 1;
    else if (wordMatch) score = 2;
    else if (lp.includes(t)) score = 3;
    if (score >= 0) scored.push([score, p]);
  });
  scored.sort((a, b) => a[0] - b[0] || a[1].localeCompare(b[1]));
  return scored.slice(0, 6).map(x => x[1]);
}

/* ---------- app state ---------- */
const S = {
  view: "learn",
  learn: { sel: 1, search: "", missedOnly: false },
  setup: { practice: { format: "mc", shuffle: true, missedOnly: false }, test: { format: "mc" } },
  session: { practice: null, test: null, roadtrip: null },
  trip: { sel: null, format: "mc" },
  gamesOpen: true,
};

function newSession(mode, format, qs) {
  return {
    mode, format, qs, idx: 0,
    choices: qs.map(q => shuffle([answerText(q), ...q.wrong])),
    typed: qs.map(q => q.blanks.map(() => "")),
    selected: qs.map(() => null),
    results: {}, overrides: new Set(), finished: false, resFilter: "all", openWhy: new Set(),
  };
}
const cur = () => S.session[S.view];
const hasInput = (s, i) => s.format === "mc" ? s.selected[i] !== null : s.typed[i].some(t => t.trim());
const isGraded = (s, i) => i in s.results;
const isCorrect = (s, i) => s.overrides.has(i) || (isGraded(s, i) && s.results[i].every(Boolean));
function grade(s, i) {
  const q = s.qs[i];
  s.results[i] = s.format === "mc" ? [s.selected[i] === answerText(q)] : gradeTyped(s.typed[i], q);
  return isCorrect(s, i);
}
const gradedIdx = s => Object.keys(s.results).map(Number).sort((a, b) => a - b);
const correctCount = s => gradedIdx(s).filter(i => isCorrect(s, i)).length;
const answeredCount = s => s.qs.filter((_, i) => hasInput(s, i)).length;
function yourAnswer(s, i) {
  if (s.format === "mc") return s.selected[i] ?? "—";
  const p = s.typed[i].map(t => t.trim());
  return p.every(x => !x) ? "—" : p.map(x => x || "—").join(" / ");
}

/* ---------- render: sidebar ---------- */
const NAV = [
  ["learn", "📖", "Learn", "All 100 questions, answered and explained"],
  ["practice", "✅", "Practice", "Find out right away if you're right"],
  ["test", "📝", "Test", "40 random questions, graded at the end"],
];
function renderSide() {
  const helpTip = id => { const g = GAME_INFO[id]; return `<span class="help" tabindex="0" aria-label="How to play ${g.name}">?
      <span class="tip" role="tooltip"><b>${g.ico} ${g.name}</b>${esc(g.what)}
        <span class="tip-h" style="display:block">How to play</span>
        <ul>${g.how.map(h => `<li>${esc(h)}</li>`).join("")}</ul></span></span>`; };
  $("#side").innerHTML = `
    <div class="brand">NH Driver Quiz<small>Section 12 · Test Your Knowledge</small></div>
    <div class="sec-h">Study</div>
    ${NAV.map(([id, ico, t, sub]) => `
      <button class="nav ${S.view === id ? "on" : ""}" data-nav="${id}">
        <span class="ico">${ico}</span><span><b>${t}</b><small>${sub}</small></span>
      </button>`).join("")}
    <button class="group-h ${S.gamesOpen ? "" : "closed"}" data-act="toggle-games" aria-expanded="${S.gamesOpen}">
      <span class="chev">▾</span> 🎮 Games
    </button>
    ${S.gamesOpen ? ["lane", "numbers", "roadtrip"].map(id => `
      <button class="nav game ${S.view === id ? "on" : ""}" data-nav="${id}">
        <span class="ico">${GAME_INFO[id].ico}</span><span class="lbl">${GAME_INFO[id].name}</span>${helpTip(id)}
      </button>`).join("") : ""}
    <div class="stats">
      <div><span style="color:var(--orange)">●</span> ${missed.size} missed question${missed.size === 1 ? "" : "s"}</div>
      ${missed.size ? `<button class="link" data-act="clear-missed">Clear missed list</button>` : ""}
    </div>`;
}

/* ---------- render: learn ---------- */
function learnFiltered() {
  const { search, missedOnly } = S.learn, t = search.trim().toLowerCase();
  return QS.filter(q => (!missedOnly || missed.has(q.id)) &&
    (!t || q.q.toLowerCase().includes(t) || answerText(q).toLowerCase().includes(t) || q.topic.toLowerCase().includes(t) || String(q.id) === t));
}
function renderLearnList() {
  const list = learnFiltered();
  $("#qitems").innerHTML = list.length ? list.map(q => `
    <button class="qi ${q.id === S.learn.sel ? "on" : ""}" data-sel="${q.id}">
      <span class="n">${q.id}</span>
      <span><span class="t">${esc(quizPrompt(q))}</span><span class="faint">${esc(q.topic)}</span></span>
      ${missed.has(q.id) ? `<span class="dot" title="Missed before"></span>` : "<span></span>"}
    </button>`).join("") : `<div class="note" style="padding:16px">No matches.</div>`;
}
function filledPrompt(q) {
  if (!blanksInline(q)) return esc(q.q.replace(/___/g, ""));
  const parts = q.q.split("___");
  return parts.map((p, i) => esc(p) + (i < q.blanks.length ? ` <span class="fill">${esc(q.blanks[i].a)}</span> ` : "")).join("");
}
function lessonCard(q) {
  return `
    <div class="scroll"><div class="wrap">
      <div class="meta"><span class="num">Question ${q.id} of ${QS.length}</span><span class="tag">${esc(q.topic)}</span>
        ${missed.has(q.id) ? `<span class="missed-badge">● Missed before</span>` : ""}</div>
      <div class="prompt">${filledPrompt(q)}</div>
      ${blanksInline(q) ? "" : `<ol class="fill" style="font-size:18px;margin-top:-8px">${q.blanks.map(b => `<li>${esc(b.a)}</li>`).join("")}</ol>`}
      <div class="box ans"><h4>✓ Answer</h4><p>${esc(answerText(q))}</p></div>
      <div class="box why"><h4>💡 Why</h4><p>${esc(q.lesson)}</p></div>
    </div></div>
    <div class="bar">
      <button class="btn" data-act="learn-prev" ${q.id <= 1 ? "disabled" : ""}>‹ Previous</button>
      <span class="grow kbd" style="text-align:center">← / → to move</span>
      <button class="btn" data-act="learn-next" ${q.id >= QS.length ? "disabled" : ""}>Next ›</button>
    </div>`;
}
function renderLearn() {
  const q = QS.find(x => x.id === S.learn.sel);
  $("#main").innerHTML = `
    <div class="learn">
      <div class="qlist">
        <div class="tools">
          <input class="search" id="lsearch" type="search" placeholder="Search questions or answers" value="${esc(S.learn.search)}">
          <label class="chk"><input type="checkbox" id="lmissed" ${S.learn.missedOnly ? "checked" : ""}> Missed only (${missed.size})</label>
        </div>
        <div class="items" id="qitems"></div>
      </div>
      <div class="learn-card" id="lcard">${q ? lessonCard(q) : `<div class="empty">Pick a question</div>`}</div>
    </div>`;
  renderLearnList();
  const on = $("#qitems .on"); if (on) on.scrollIntoView({ block: "nearest" });
}
function learnGo(id) {
  if (id < 1 || id > QS.length) return;
  S.learn.sel = id;
  $("#lcard").innerHTML = lessonCard(QS[id - 1]);
  renderLearnList();
  const on = $("#qitems .on"); if (on) on.scrollIntoView({ block: "nearest" });
}

/* ---------- render: setup ---------- */
function renderSetup(mode) {
  const st = S.setup[mode];
  const pool = mode === "practice" && st.missedOnly ? QS.filter(q => missed.has(q.id)) : QS;
  $("#main").innerHTML = `
    <div class="scroll"><div class="wrap" style="max-width:680px">
      <h1>${mode === "practice" ? "Practice" : "Practice Test"}</h1>
      <p class="muted">${mode === "practice"
        ? "Answer one question at a time. You find out right away whether you got it, with the correct answer and a short explanation."
        : "40 random questions out of the 100. You won't see any answers until you finish, then you get your score and every answer. To pass the real NH test you need 80% (32 of 40)."}</p>
      <h3 style="margin-top:22px">Format</h3>
      <div class="cards">
        <button class="fcard ${st.format === "mc" ? "on" : ""}" data-format="mc">
          <div class="top"><span>🔘</span><span class="radio"></span></div>
          <b>Multiple Choice</b><span>Pick from 4 options. Use keys 1–4.</span>
        </button>
        <button class="fcard ${st.format === "typed" ? "on" : ""}" data-format="typed">
          <div class="top"><span>⌨️</span><span class="radio"></span></div>
          <b>Open Note</b><span>Type the answer yourself. Suggestions appear as you type.</span>
        </button>
      </div>
      ${mode === "practice" ? `
        <h3>Questions</h3>
        <div class="opts" style="margin-top:10px">
          <label class="chk"><input type="checkbox" id="optShuffle" ${st.shuffle ? "checked" : ""}> Shuffle the order</label>
          <label class="chk"><input type="checkbox" id="optMissed" ${st.missedOnly ? "checked" : ""} ${missed.size ? "" : "disabled"}> Only questions I've missed (${missed.size})</label>
        </div>` : ""}
      <button class="btn primary start" data-act="start" ${pool.length ? "" : "disabled"}>
        ${mode === "practice" ? `Start practice (${pool.length} questions)` : "Start test (40 questions)"}
      </button>
      <p class="kbd" style="text-align:center">Press Return to start</p>
    </div></div>`;
}
function startSession() {
  const mode = S.view, st = S.setup[mode];
  let qs;
  if (mode === "practice") {
    const pool = st.missedOnly ? QS.filter(q => missed.has(q.id)) : QS;
    qs = st.shuffle ? shuffle(pool) : pool.slice();
  } else qs = shuffle(QS).slice(0, 40);
  S.session[mode] = newSession(mode, st.format, qs);
  render();
}

/* ---------- render: runner ---------- */
function renderRunner(s) {
  const i = s.idx, q = s.qs[i], practice = s.mode === "practice", graded = practice && isGraded(s, i);
  const fmt = s.format === "mc" ? "Multiple Choice" : "Open Note";
  let input;
  if (s.format === "mc") {
    input = s.choices[i].map((c, n) => {
      let cls = "";
      if (graded) cls = c === answerText(q) ? "good" : (s.selected[i] === c ? "bad" : "dim");
      else if (s.selected[i] === c) cls = "sel";
      const mark = cls === "good" ? `<span class="mark g">✓</span>` : cls === "bad" ? `<span class="mark r">✗</span>` : "";
      return `<button class="choice ${cls}" data-choice="${n}" ${graded ? "disabled" : ""}><span class="k">${n + 1}</span><span class="x">${esc(c)}</span>${mark}</button>`;
    }).join("");
  } else {
    input = q.blanks.map((b, n) => {
      const st = graded ? (s.results[i][n] ? "g" : "r") : "";
      return `<div class="field">
        <label>${q.blanks.length === 1 ? "Your answer" : "Blank " + (n + 1)}</label>
        <div class="inrow">
          <input type="text" class="${st}" data-blank="${n}" value="${esc(s.typed[i][n])}" placeholder="Type your answer…"
                 autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" ${graded ? "disabled" : ""}>
          ${st ? `<span class="mark ${st}">${st === "g" ? "✓" : "✗"}</span>` : ""}
        </div>
        <div class="sugg" hidden></div>
      </div>`;
    }).join("") + (q.anyOrder && q.blanks.length > 1 ? `<div class="note">These can go in any order.</div>` : "");
  }

  let feedback = "";
  if (graded) {
    const ok = isCorrect(s, i), over = s.overrides.has(i);
    feedback = `<div class="feedback ${ok ? "g" : "r"}">
      <div class="fb-top">
        <span class="big">${ok ? "✅" : "❌"}</span>
        <h2>${ok ? (over ? "Counted as correct" : "Correct!") : "Not quite"}
          ${!ok && s.format === "typed" ? `<small>Your answer: ${esc(yourAnswer(s, i))}</small>` : ""}</h2>
        ${!ok && s.format === "typed" ? `<button class="btn" data-act="override">I was right, count it</button>` : ""}
      </div>
      <div class="box ans"><h4>✓ Answer</h4><p>${esc(answerText(q))}</p></div>
      <div class="box why"><h4>💡 Why</h4><p>${esc(q.lesson)}</p></div>
    </div>`;
  }

  const primary = practice ? (!graded ? "Check answer" : (i === s.qs.length - 1 ? "See results" : "Next question"))
                           : (i === s.qs.length - 1 ? "Finish test" : "Next");
  const hint = s.format === "mc" ? "Press 1–4 to choose, Return to " + (practice ? (graded ? "continue" : "check") : "go on")
                                 : (graded ? "Press Return for the next question" : "Return to " + (practice ? "check" : "go on") + " · ↑↓ to pick a suggestion");

  $("#main").innerHTML = `
    <div class="head">
      <div class="row">
        <span class="title">${s.label || (practice ? "Practice" : "Test")} · ${fmt}</span>
        <span class="muted" style="font-variant-numeric:tabular-nums">${practice
          ? `✓ ${correctCount(s)} / ${gradedIdx(s).length} correct`
          : `${answeredCount(s)} of ${s.qs.length} answered`}</span>
        <button class="btn" data-act="quit">${practice ? "End practice" : "Quit"}</button>
      </div>
      <div class="progress"><i style="width:${((i + 1) / s.qs.length) * 100}%"></i></div>
    </div>
    <div class="scroll"><div class="wrap">
      <div class="meta"><span class="num">Question ${i + 1} of ${s.qs.length}</span><span class="tag">${esc(q.topic)}</span>
        <span class="faint">#${q.id} in the book</span></div>
      <div class="prompt">${esc(quizPrompt(q))}</div>
      <div id="answer">${input}</div>
      ${feedback}
    </div></div>
    <div class="bar">
      ${practice ? `<span class="grow kbd">${hint}</span>` : `
        <button class="btn" data-act="prev" ${i === 0 ? "disabled" : ""}>‹ Previous</button>
        <div class="grow strip" id="strip">${s.qs.map((_, n) =>
          `<button class="${hasInput(s, n) ? "ans" : ""} ${n === i ? "cur" : ""}" data-jump="${n}">${n + 1}</button>`).join("")}</div>`}
      <button class="btn primary" data-act="primary" id="primaryBtn" ${practice && !graded && !hasInput(s, i) ? "disabled" : ""}>${primary}</button>
    </div>`;

  const strip = $("#strip .cur"); if (strip) strip.scrollIntoView({ block: "nearest", inline: "center" });
  if (s.format === "typed" && !graded) { const f = $('#answer input[data-blank="0"]'); if (f) f.focus(); }
  if (s.format === "typed") wireFields(s);
}

function refreshPrimary(s) {
  const b = $("#primaryBtn"); if (!b) return;
  if (s.mode === "practice" && !isGraded(s, s.idx)) b.disabled = !hasInput(s, s.idx);
  const sb = $(`#strip [data-jump="${s.idx}"]`); if (sb) sb.classList.toggle("ans", hasInput(s, s.idx));
}

function primary() {
  const s = cur(); if (!s || s.finished) return;
  const i = s.idx, last = i === s.qs.length - 1;
  if (s.mode === "practice") {
    if (!isGraded(s, i)) {
      if (!hasInput(s, i)) return;
      record(s.qs[i].id, grade(s, i));
      renderSide();
    } else if (last) s.finished = true;
    else s.idx++;
  } else {
    if (last) {
      const left = s.qs.length - answeredCount(s);
      const finish = () => {
        s.qs.forEach((q, n) => { grade(s, n); record(q.id, isCorrect(s, n)); });
        s.finished = true;
        render();
      };
      if (left) ask(`You have ${left} unanswered question${left === 1 ? "" : "s"}. They'll count as wrong. Finish anyway?`, "Finish test").then(ok => ok && finish());
      else finish();
      return;
    } else s.idx++;
  }
  renderMain();
}

/* ---------- typed fields + suggestions ---------- */
function wireFields(s) {
  document.querySelectorAll("#answer input[data-blank]").forEach(inp => {
    const n = +inp.dataset.blank, box = inp.closest(".field").querySelector(".sugg");
    let list = [], hl = -1, dismissed = null;
    const draw = () => {
      list = (dismissed === inp.value || document.activeElement !== inp) ? [] : suggest(inp.value);
      if (hl >= list.length) hl = -1;
      box.hidden = !list.length;
      box.innerHTML = list.map((t, k) => `<button type="button" class="${k === hl ? "hl" : ""}" data-k="${k}">${esc(t)}</button>`).join("");
    };
    const pick = t => { inp.value = t; s.typed[s.idx][n] = t; dismissed = t; hl = -1; draw(); refreshPrimary(s); inp.focus(); };
    inp.addEventListener("input", () => { s.typed[s.idx][n] = inp.value; hl = -1; draw(); refreshPrimary(s); });
    inp.addEventListener("focus", draw);
    inp.addEventListener("blur", () => setTimeout(() => { box.hidden = true; }, 150));
    box.addEventListener("mousedown", e => {
      const b = e.target.closest("button[data-k]"); if (!b) return;
      e.preventDefault(); pick(list[+b.dataset.k]);
    });
    inp.addEventListener("keydown", e => {
      if (e.key === "ArrowDown" && list.length) { e.preventDefault(); hl = (hl + 1) % list.length; draw(); }
      else if (e.key === "ArrowUp" && list.length) { e.preventDefault(); hl = hl <= 0 ? list.length - 1 : hl - 1; draw(); }
      else if (e.key === "Escape" && list.length) { e.preventDefault(); dismissed = inp.value; hl = -1; draw(); }
      else if (e.key === "Tab" && hl >= 0 && list.length) { e.preventDefault(); pick(list[hl]); }
      else if (e.key === "Enter") {
        e.preventDefault(); e.stopPropagation();
        if (hl >= 0 && list[hl]) { pick(list[hl]); return; }
        dismissed = inp.value; draw();
        const nextF = document.querySelector(`#answer input[data-blank="${n + 1}"]`);
        if (nextF) nextF.focus(); else primary();
      }
    });
  });
}

/* ---------- render: results ---------- */
function renderResults(s) {
  finishLeg(s);
  const isLeg = s.leg !== undefined;
  const total = s.mode === "test" || isLeg ? s.qs.length : gradedIdx(s).length;
  const right = correctCount(s), pct = total ? right / total : 0, passed = pct >= 0.8;
  const wrongIdx = gradedIdx(s).filter(i => !isCorrect(s, i));
  const rows = (s.resFilter === "missed" ? wrongIdx : gradedIdx(s));
  const C = 2 * Math.PI * 46;
  $("#main").innerHTML = `
    <div class="res-head">
      <svg class="ring" viewBox="0 0 110 110">
        <circle cx="55" cy="55" r="46" fill="none" stroke="var(--line)" stroke-width="12"/>
        <circle cx="55" cy="55" r="46" fill="none" stroke="${passed ? "var(--green)" : "var(--orange)"}" stroke-width="12" stroke-linecap="round"
                stroke-dasharray="${C * pct} ${C}" transform="rotate(-90 55 55)"/>
        <text x="55" y="62" text-anchor="middle" font-size="22" font-weight="700" fill="var(--text)">${Math.round(pct * 100)}%</text>
      </svg>
      <div>
        <h1>${right} out of ${total} correct</h1>
        ${s.mode === "test"
          ? `<div class="pass" style="color:${passed ? "var(--green)" : "var(--orange)"}">${passed ? "✓ Pass" : "⚠ Not a pass yet"}</div>
             <div class="muted">The real NH knowledge test needs 80%, which is 32 of 40.</div>`
          : `<div class="muted">${esc(s.label || "Practice")} · ${s.format === "mc" ? "Multiple Choice" : "Open Note"}</div>`}
      </div>
      <div class="res-actions">
        ${wrongIdx.length ? `<button class="btn" data-act="retry-missed">Practice the ${wrongIdx.length} I missed</button>` : ""}
        ${s.mode === "test" ? `<button class="btn primary" data-act="new-test">New test</button>` : ""}
        <button class="btn ${isLeg ? "primary" : ""}" data-act="done">${isLeg ? "Back to map" : "Done"}</button>
      </div>
      ${isLeg ? `<div class="leg-banner ${s.legPassed ? "g" : "r"}">${s.legPassed
        ? (s.legNew ? `🏁 ${TOWNS[s.leg].name} mastered! ${s.leg < TOWNS.length - 1 ? `Next stop unlocked: ${TOWNS[s.leg + 1].name}.` : "Test Day is unlocked!"}` : `✓ ${TOWNS[s.leg].name} is still mastered. Nice drive.`)
        : (s.legComplete ? `You need 80% to master ${TOWNS[s.leg].name}. You got ${s.legPct}%. Review the misses and try again.` : `You left early, so this leg doesn't count. Finish all ${s.qs.length} questions to master ${TOWNS[s.leg].name}.`)}</div>` : ""}
    </div>
    <div class="scroll"><div class="wrap" style="padding-top:16px">
      <div style="display:flex;align-items:center;justify-content:space-between">
        <h3>Answers</h3>
        <div class="seg">
          <button class="${s.resFilter === "all" ? "on" : ""}" data-filter="all">All</button>
          <button class="${s.resFilter === "missed" ? "on" : ""}" data-filter="missed">Missed (${wrongIdx.length})</button>
        </div>
      </div>
      ${rows.length ? rows.map(i => {
        const q = s.qs[i], ok = isCorrect(s, i), autoOk = s.results[i].every(Boolean);
        return `<div class="rrow">
          <span class="mark ${ok ? "g" : "r"}">${ok ? "✓" : "✗"}</span>
          <div>
            <div class="q">${i + 1}. ${esc(quizPrompt(q))}</div>
            <div class="line"><span class="muted">You:</span> <span class="${ok ? "g-t" : "r-t"}">${esc(yourAnswer(s, i))}</span></div>
            ${!ok || s.overrides.has(i) ? `<div class="line"><span class="muted">Answer:</span> <b>${esc(answerText(q))}</b></div>` : ""}
            ${s.openWhy.has(i) ? `<div class="line muted">${esc(q.lesson)}</div>` : ""}
            <div class="actions">
              <button class="link" data-why="${i}">${s.openWhy.has(i) ? "Hide explanation" : "Why?"}</button>
              ${s.format === "typed" && !autoOk ? `<label class="chk"><input type="checkbox" data-ovr="${i}" ${s.overrides.has(i) ? "checked" : ""}> I was right, count it</label>` : ""}
            </div>
          </div>
        </div>`;
      }).join("") : `<p class="muted">Nothing here. Nice work.</p>`}
    </div></div>`;
}

/* ====================================================================
   GAMES
   ==================================================================== */
const lsGet = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };

let game = null;
function stopGame() { if (game) { try { game.stop(); } catch (e) {} game = null; } }

const GAME_INFO = {
  lane: {
    name: "Lane Runner", ico: "🏎️",
    what: "Drive down a 4-lane road. Each lane is one answer choice. Steer into the right lane before you reach the gate.",
    how: ["← / → (or A / D) to change lanes, or press 1–4 to jump to a lane",
          "Space locks in your lane early for bonus points",
          "Your streak makes the road faster and points bigger",
          "3 crashes ends the run. Wrong answers show the right one and come back later"],
  },
  numbers: {
    name: "Number Crunch", ico: "🔢",
    what: "10 rounds of just the number questions: feet, MPH, days, BAC. These are the ones people miss most.",
    how: ["Type the number or use the slider, then press Return",
          "Miss it and you get a hot/cold hint plus a second try",
          "100 points on the first try, 50 on the second",
          "Every round shows the answer and why"],
  },
  roadtrip: {
    name: "Road Trip", ico: "🗺️",
    what: "Drive across New Hampshire. Each town is a topic (Signs, Parking, Alcohol…). Make it to Test Day.",
    how: ["Click a town and pass its quiz with 80% to unlock the next one",
          "Right answers anywhere in the app fill each town's progress bar",
          "Master all 8 towns to reach Test Day"],
  },
};

/* ---------------- Lane Runner ---------------- */
const LANE_COLORS = ["#3b82f6", "#f59e0b", "#a855f7", "#14b8a6"];

function startLane() {
  stopGame();
  const best = +(lsGet("nhq_lane_best") || 0);
  $("#main").innerHTML = `
    <div class="lr" id="lrRoot">
      <div class="lr-top">
        <div class="lr-stats">
          <span>Score <b id="lrScore">0</b></span>
          <span>Streak <b id="lrStreak">0</b></span>
          <span id="lrLives"></span>
          <span class="muted">Best <b id="lrBest">${best}</b></span>
        </div>
        <div class="lr-q" id="lrQ">Get ready…</div>
        <div class="lr-choices" id="lrC"></div>
      </div>
      <div class="lr-stage" id="lrStage">
        <canvas id="lrc"></canvas>
        <div class="lr-toast" id="lrToast"></div>
        <div class="lr-overlay" id="lro"></div>
      </div>
    </div>`;

  const G = {
    view: "lane", queue: shuffle(QS), q: null, choices: [], correct: 0, lane: 1, carX: null,
    prog: 0, dur: 8, score: 0, streak: 0, lives: 3, phase: "ready", missed: [], answered: 0, right: 0,
    scroll: 0, best, flash: 0, flashRGB: "0,0,0", raf: 0, last: 0, rush: false, rushLeft: 0, toastT: 0,
  };
  game = G;
  const root = $("#lrRoot"), cv = $("#lrc"), ctx = cv.getContext("2d"), stage = $("#lrStage");
  let W = 0, H = 0;
  const resize = () => {
    const r = stage.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    W = r.width; H = r.height;
    cv.width = Math.max(1, W * dpr); cv.height = Math.max(1, H * dpr);
    cv.style.width = W + "px"; cv.style.height = H + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };
  const ro = new ResizeObserver(resize); ro.observe(stage); resize();
  const geom = () => { const rw = Math.min(W * 0.86, 620), x0 = (W - rw) / 2; return { rw, x0, lw: rw / 4, carY: H - 75 }; };
  const laneX = i => { const g = geom(); return g.x0 + g.lw * (i + 0.5); };

  const overlay = html => { const o = $("#lro"); o.innerHTML = html; o.hidden = !html; };
  const hud = () => {
    $("#lrScore").textContent = G.score;
    $("#lrStreak").textContent = G.streak + (G.streak >= 3 ? " 🔥" : "");
    $("#lrLives").innerHTML = "❤️".repeat(G.lives) + `<span style="opacity:.25">${"❤️".repeat(3 - G.lives)}</span>`;
    root.querySelectorAll(".lr-ch").forEach((b, i) => b.classList.toggle("on", i === G.lane));
  };
  const toast = (txt, ok) => {
    const t = $("#lrToast"); t.textContent = txt; t.className = "lr-toast show " + (ok ? "g" : "r");
    clearTimeout(G.toastT); G.toastT = setTimeout(() => { t.className = "lr-toast"; }, 1600);
  };

  function next() {
    G.q = G.queue.shift();
    if (!G.q) { G.queue = shuffle(QS); G.q = G.queue.shift(); }
    G.choices = shuffle([answerText(G.q), ...G.q.wrong]);
    G.correct = G.choices.indexOf(answerText(G.q));
    G.prog = 0; G.rush = false;
    G.dur = Math.max(4.5, 10 - G.streak * 0.35) + Math.min(4, G.q.q.length / 70);
    $("#lrQ").textContent = quizPrompt(G.q);
    $("#lrC").innerHTML = G.choices.map((c, i) =>
      `<button class="lr-ch" data-lane="${i}" style="--c:${LANE_COLORS[i]}"><span>${i + 1}</span><em>${esc(c)}</em></button>`).join("");
    hud();
  }

  function resolve() {
    const q = G.q, ok = G.lane === G.correct;
    G.answered++; record(q.id, ok); renderSide();
    if (ok) {
      G.right++;
      const bonus = G.rush ? Math.round(G.rushLeft * 15) : 0;
      const pts = 100 + G.streak * 10 + bonus;
      G.score += pts; G.streak++;
      G.flash = 1; G.flashRGB = "31,157,85";
      toast(`✓ +${pts}${bonus ? " (early bonus)" : ""} · ${answerText(q)}`, true);
      next();
    } else {
      G.lives--; G.streak = 0; G.flash = 1; G.flashRGB = "217,54,54";
      if (!G.missed.includes(q)) G.missed.push(q);
      G.queue.splice(Math.min(4, G.queue.length), 0, q);
      G.phase = "crash"; hud();
      overlay(`<div class="lr-card">
        <h2>💥 Wrong lane</h2>
        <div class="muted">You picked: ${esc(G.choices[G.lane])}</div>
        <div class="box ans"><h4>✓ Answer</h4><p>${esc(answerText(q))}</p></div>
        <div class="box why"><h4>💡 Why</h4><p>${esc(q.lesson)}</p></div>
        <button class="btn primary" data-lr="cont" style="margin-top:16px">${G.lives > 0 ? "Keep driving" : "See results"}</button>
        <div class="kbd" style="margin-top:6px">or press Space</div>
      </div>`);
    }
  }

  function begin() { G.phase = "run"; overlay(""); next(); }
  function cont() { if (G.lives <= 0) return over(); G.phase = "run"; overlay(""); next(); }
  function restart() {
    Object.assign(G, { queue: shuffle(QS), score: 0, streak: 0, lives: 3, missed: [], answered: 0, right: 0, lane: 1 });
    begin();
  }
  function over() {
    G.phase = "over";
    const newBest = G.score > G.best;
    if (newBest) { G.best = G.score; lsSet("nhq_lane_best", G.score); $("#lrBest").textContent = G.score; }
    const acc = G.answered ? Math.round(G.right / G.answered * 100) : 0;
    overlay(`<div class="lr-card">
      <h2>🏁 Run over</h2>
      <div class="lr-big">${G.score}</div>
      <div class="muted">${newBest ? "🎉 New best score!" : `Best: ${G.best}`} · ${G.right} of ${G.answered} right (${acc}%)</div>
      ${G.missed.length ? `<h4 style="margin:16px 0 6px">Study these</h4><div class="lr-missed">${G.missed.map(q =>
        `<div><b>${esc(quizPrompt(q))}</b><br><span class="g-t">${esc(answerText(q))}</span></div>`).join("")}</div>` : ""}
      <button class="btn primary" data-lr="again" style="margin-top:16px">Play again</button>
      <div class="kbd" style="margin-top:6px">or press Space</div>
    </div>`);
  }

  function draw() {
    const g = geom();
    ctx.clearRect(0, 0, W, H);
    // grass
    ctx.fillStyle = "#4a8f3f"; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#3f7d36";
    for (let y = (G.scroll * 2) % 120 - 120; y < H; y += 120) { ctx.fillRect(0, y, g.x0 - 18, 60); ctx.fillRect(g.x0 + g.rw + 18, y + 60, W, 60); }
    // trees
    for (let y = (G.scroll * 3) % 180 - 180; y < H; y += 180) {
      [[g.x0 - 50, y + 30], [g.x0 + g.rw + 50, y + 120]].forEach(([x, yy]) => {
        if (x < 10 || x > W - 10) return;
        ctx.fillStyle = "#2f6b2a"; ctx.beginPath(); ctx.arc(x, yy, 18, 0, 7); ctx.fill();
        ctx.fillStyle = "#3a7f33"; ctx.beginPath(); ctx.arc(x - 5, yy - 5, 10, 0, 7); ctx.fill();
      });
    }
    // road
    ctx.fillStyle = "#9aa0a6"; ctx.fillRect(g.x0 - 16, 0, g.rw + 32, H);
    ctx.fillStyle = "#3a3d42"; ctx.fillRect(g.x0, 0, g.rw, H);
    ctx.fillStyle = "#f5f5f5"; ctx.fillRect(g.x0 + 4, 0, 4, H); ctx.fillRect(g.x0 + g.rw - 8, 0, 4, H);
    for (let i = 1; i < 4; i++) {
      const x = g.x0 + g.lw * i - 2;
      for (let y = (G.scroll % 60) - 60; y < H; y += 60) ctx.fillRect(x, y, 4, 30);
    }
    // gate
    if (G.phase === "run" || G.phase === "crash") {
      const gy = -50 + (g.carY - 45 + 50) * G.prog;
      ctx.fillStyle = "rgba(0,0,0,.25)"; ctx.fillRect(g.x0 - 16, gy + 26, g.rw + 32, 8);
      ctx.fillStyle = "#555b63"; ctx.fillRect(g.x0 - 16, gy - 4, g.rw + 32, 8);
      for (let i = 0; i < 4; i++) {
        const cx = laneX(i), w = g.lw * 0.62, h = 38;
        let col = LANE_COLORS[i];
        if (G.phase === "crash") col = i === G.correct ? "#1f9d55" : (i === G.lane ? "#d93636" : "#6b7280");
        ctx.fillStyle = col;
        roundRect(ctx, cx - w / 2, gy - h / 2, w, h, 8); ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,.9)"; ctx.lineWidth = 2; roundRect(ctx, cx - w / 2 + 3, gy - h / 2 + 3, w - 6, h - 6, 6); ctx.stroke();
        ctx.fillStyle = "#fff"; ctx.font = "bold 20px -apple-system, sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
        ctx.fillText(G.phase === "crash" && i === G.correct ? "✓" : String(i + 1), cx, gy + 1);
      }
      // time-left bar
      ctx.fillStyle = "rgba(0,0,0,.35)"; ctx.fillRect(g.x0, 6, g.rw, 6);
      ctx.fillStyle = G.prog > 0.75 ? "#ef4444" : G.prog > 0.5 ? "#f59e0b" : "#22c55e";
      ctx.fillRect(g.x0, 6, g.rw * (1 - G.prog), 6);
    }
    // car
    const cx = G.carX, cy = g.carY;
    ctx.fillStyle = "rgba(0,0,0,.3)"; roundRect(ctx, cx - 22, cy - 30, 48, 76, 12); ctx.fill();
    ctx.fillStyle = "#111"; [[-25, -22], [19, -22], [-25, 18], [19, 18]].forEach(([dx, dy]) => { roundRect(ctx, cx + dx, cy + dy, 6, 16, 2); ctx.fill(); });
    ctx.fillStyle = "#e53e3e"; roundRect(ctx, cx - 21, cy - 36, 42, 74, 12); ctx.fill();
    ctx.fillStyle = "#9bd4ff"; roundRect(ctx, cx - 15, cy - 20, 30, 16, 4); ctx.fill();
    ctx.fillStyle = "#7fb8e0"; roundRect(ctx, cx - 14, cy + 14, 28, 10, 3); ctx.fill();
    ctx.fillStyle = "#fde68a"; ctx.fillRect(cx - 16, cy - 36, 8, 4); ctx.fillRect(cx + 8, cy - 36, 8, 4);
    // flash
    if (G.flash > 0) { ctx.fillStyle = `rgba(${G.flashRGB},${G.flash * 0.35})`; ctx.fillRect(0, 0, W, H); }
  }

  function frame(t) {
    const dt = Math.min(0.05, (t - (G.last || t)) / 1000); G.last = t;
    if (G.phase === "run") {
      G.prog += dt * (G.rush ? 6 : 1) / G.dur;
      if (G.prog >= 1) { G.prog = 1; resolve(); }
    }
    const spd = G.phase === "run" ? (220 + G.streak * 25) * (G.rush ? 3 : 1) : 50;
    G.scroll = (G.scroll + spd * dt) % 3600;
    const tx = laneX(G.lane); if (G.carX === null) G.carX = tx;
    G.carX += (tx - G.carX) * Math.min(1, dt * 14);
    G.flash = Math.max(0, G.flash - dt * 2);
    draw();
    G.raf = requestAnimationFrame(frame);
  }

  function setLane(i) { if (G.phase !== "run") return; G.lane = Math.max(0, Math.min(3, i)); hud(); }
  function onKey(e) {
    if (e.metaKey || e.ctrlKey || e.altKey || document.querySelector(".modal-back")) return;
    const k = e.key, go = k === " " || k === "Enter";
    if (G.phase === "ready") { if (go) { e.preventDefault(); begin(); } return; }
    if (G.phase === "over") { if (go) { e.preventDefault(); restart(); } return; }
    if (G.phase === "crash") { if (go) { e.preventDefault(); cont(); } return; }
    if (k === "ArrowLeft" || k === "a" || k === "A") { e.preventDefault(); setLane(G.lane - 1); }
    else if (k === "ArrowRight" || k === "d" || k === "D") { e.preventDefault(); setLane(G.lane + 1); }
    else if (/^[1-4]$/.test(k)) setLane(+k - 1);
    else if (go) { e.preventDefault(); if (!G.rush) { G.rush = true; G.rushLeft = (1 - G.prog) * G.dur; } }
  }
  function onClick(e) {
    const b = e.target.closest("[data-lane],[data-lr]");
    if (b && b.dataset.lane !== undefined) return setLane(+b.dataset.lane);
    if (b && b.dataset.lr) { const a = b.dataset.lr; return a === "start" ? begin() : a === "cont" ? cont() : restart(); }
    if (e.target === cv && G.phase === "run") {
      const g = geom(), x = e.offsetX;
      if (x >= g.x0 && x <= g.x0 + g.rw) setLane(Math.floor((x - g.x0) / g.lw));
    }
  }
  document.addEventListener("keydown", onKey);
  root.addEventListener("click", onClick);
  G.stop = () => { cancelAnimationFrame(G.raf); document.removeEventListener("keydown", onKey); ro.disconnect(); clearTimeout(G.toastT); };

  hud();
  overlay(`<div class="lr-card">
    <h2>🏎️ Lane Runner</h2>
    <p class="muted">${GAME_INFO.lane.what}</p>
    <ul class="lr-how">${GAME_INFO.lane.how.map(h => `<li>${esc(h)}</li>`).join("")}</ul>
    <button class="btn primary" data-lr="start">Start driving</button>
    <div class="kbd" style="margin-top:6px">or press Space</div>
  </div>`);
  G.raf = requestAnimationFrame(frame);
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

/* ---------------- Number Crunch ---------------- */
// [question id, blank index, answer, unit, min, max, step]
const NUMS = [
  [4, 0, 1999, "model year", 1980, 2015, 1], [6, 0, 10, "MPH below the posted limit", 0, 30, 5],
  [7, 0, 1000, "dollars", 0, 5000, 100], [7, 1, 15, "days", 0, 60, 1],
  [8, 0, 40, "(20/__ vision)", 10, 100, 10], [9, 0, 0.08, "% BAC", 0, 0.2, 0.01],
  [10, 1, 10, "days", 0, 60, 1], [12, 0, 20, "days", 0, 90, 5], [13, 0, 30, "MPH", 15, 65, 5],
  [21, 0, 500, "feet", 0, 1000, 50], [22, 0, 9, "months", 1, 24, 1], [23, 0, 35, "MPH", 15, 65, 5],
  [25, 0, 4, "seconds", 1, 10, 1], [27, 0, 0.02, "% BAC", 0, 0.2, 0.01],
  [29, 0, 100, "feet", 0, 1000, 25], [29, 1, 500, "feet", 0, 1000, 25], [34, 1, 150, "feet", 0, 1000, 25],
  [36, 0, 30, "(20/__ vision)", 10, 100, 10], [37, 0, 15, "feet", 0, 100, 5], [37, 1, 50, "feet", 0, 100, 5],
  [41, 0, 25, "feet", 0, 100, 5], [43, 0, 15, "feet", 0, 50, 5], [47, 0, 200, "feet", 0, 1000, 50],
  [54, 0, 5, "horsepower", 1, 20, 1], [66, 0, 20, "feet", 0, 50, 5], [70, 0, 60, "days", 0, 120, 10],
  [73, 0, 1, "a.m.", 0, 12, 1], [73, 1, 4, "a.m.", 0, 12, 1], [74, 0, 30, "feet", 0, 50, 5],
  [78, 0, 45, "MPH", 20, 70, 5], [85, 0, 26000, "lbs", 0, 50000, 1000], [86, 0, 6, "months", 1, 24, 1],
  [87, 0, 15.5, "years old", 14, 18, 0.5], [88, 0, 25, "years old", 16, 30, 1], [90, 0, 18, "years old", 10, 25, 1],
  [91, 0, 18, "years old", 10, 25, 1], [99, 0, 4, "times", 1, 10, 1],
];
const fmtNum = (v, step) => {
  const d = step < 1 ? String(step).split(".")[1].length : 0;
  return Number(v).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
};

function startNumbers() {
  stopGame();
  const G = {
    view: "numbers", rounds: shuffle(NUMS).slice(0, 10), i: 0, score: 0, tries: 0, phase: "ask",
    log: [], best: +(lsGet("nhq_num_best") || 0), hint: "", lastGuess: null,
  };
  game = G;

  const roundQ = r => QS[r[0] - 1];
  function promptHTML(r) {
    const q = roundQ(r), parts = q.q.split("___");
    return parts.map((p, i) => esc(p) + (i < parts.length - 1
      ? (i === r[1] ? ` <span class="nc-blank">?</span> ` : ` <span class="fill">${esc(q.blanks[i].a)}</span> `) : "")).join("");
  }

  function render() {
    if (G.phase === "done") return renderDone();
    const r = G.rounds[G.i], q = roundQ(r), [, , v, unit, min, max, step] = r;
    const reveal = G.phase === "reveal", last = G.log[G.log.length - 1];
    const startVal = G.lastGuess ?? min + Math.round((max - min) / 2 / step) * step;
    $("#main").innerHTML = `
      <div class="scroll" id="ncRoot"><div class="wrap">
        <div class="nc-top">
          <span class="num">Round ${G.i + 1} of ${G.rounds.length}</span>
          <div class="nc-dots">${G.rounds.map((_, k) => `<i class="${k < G.log.length ? (G.log[k].pts === 100 ? "g" : G.log[k].pts ? "y" : "r") : (k === G.i ? "cur" : "")}"></i>`).join("")}</div>
          <span>Score <b>${G.score}</b></span><span class="muted">Best ${G.best}</span>
        </div>
        <div class="meta" style="margin-top:18px"><span class="tag">${esc(q.topic)}</span><span class="faint">#${q.id} in the book</span></div>
        <div class="prompt">${promptHTML(r)}</div>
        <div class="nc-input ${reveal ? (last.ok ? "g" : "r") : ""}">
          <button class="nc-step" data-nc="minus" ${reveal ? "disabled" : ""}>−</button>
          <input id="ncVal" type="text" inputmode="decimal" autocomplete="off" value="${reveal ? esc(last.guess) : fmtNum(startVal, step)}" ${reveal ? "disabled" : ""}>
          <button class="nc-step" data-nc="plus" ${reveal ? "disabled" : ""}>+</button>
          <span class="nc-unit">${esc(unit)}</span>
        </div>
        <input id="ncRange" class="nc-range" type="range" min="${min}" max="${max}" step="${step}" value="${startVal}" ${reveal ? "disabled" : ""}>
        <div class="nc-scale"><span>${fmtNum(min, step)}</span><span>${fmtNum(max, step)}</span></div>
        ${!reveal ? `
          ${G.hint ? `<div class="nc-hint">${G.hint}</div>` : ""}
          <button class="btn primary start" data-nc="submit" style="margin-top:14px">${G.tries ? "Final answer" : "Lock it in"}</button>
          <p class="kbd" style="text-align:center">${G.tries ? "Last try. " : "Miss and you get a hint and one more try. "}Press Return to submit.</p>`
        : `
          <div class="feedback ${last.ok ? "g" : "r"}">
            <div class="fb-top"><span class="big">${last.ok ? (last.pts === 100 ? "🎯" : "✅") : "❌"}</span>
              <h2>${last.ok ? (last.pts === 100 ? "Nailed it! +100" : "Got it on try two. +50") : "Not this time"}
                <small>The answer is ${fmtNum(v, step)} ${esc(unit)}</small></h2></div>
            <div class="box why"><h4>💡 Why</h4><p>${esc(q.lesson)}</p></div>
          </div>
          <button class="btn primary start" data-nc="next" style="margin-top:16px" id="ncNext">${G.i === G.rounds.length - 1 ? "See results" : "Next round"}</button>
          <p class="kbd" style="text-align:center">Press Return to continue</p>`}
      </div></div>`;
    const inp = $("#ncVal"), rng = $("#ncRange");
    if (!reveal) {
      inp.focus(); inp.select();
      rng.addEventListener("input", () => { inp.value = fmtNum(rng.value, step); });
      inp.addEventListener("input", () => { const n = parseNum(inp.value); if (!isNaN(n)) rng.value = n; });
    } else { const nb = $("#ncNext"); if (nb) nb.focus(); }
  }

  function parseNum(s) { return parseFloat(String(s).replace(/[,$%\s]/g, "")); }

  function submit() {
    const r = G.rounds[G.i], q = roundQ(r), [, , v, , min, max, step] = r;
    const raw = $("#ncVal").value, n = parseNum(raw);
    if (isNaN(n)) { G.hint = "Type a number first."; return render(); }
    G.lastGuess = n;
    const ok = Math.abs(n - v) < step / 1000 + 1e-9;
    if (ok || G.tries >= 1) {
      const pts = ok ? (G.tries ? 50 : 100) : 0;
      G.score += pts;
      G.log.push({ r, ok, pts, guess: fmtNum(n, step) });
      record(q.id, ok); renderSide();
      G.phase = "reveal";
    } else {
      G.tries = 1;
      const rel = Math.abs(n - v) / (max - min);
      const heat = rel <= 0.08 ? "🔥 <b>Hot!</b> You're really close." : rel <= 0.25 ? "🌡️ <b>Warm.</b> You're in the neighborhood." : "🧊 <b>Cold.</b> Way off.";
      G.hint = `${heat} The answer is <b>${n < v ? "higher ⬆" : "lower ⬇"}</b> than ${fmtNum(n, step)}.`;
    }
    render();
  }

  function nextRound() {
    G.i++; G.tries = 0; G.hint = ""; G.lastGuess = null;
    if (G.i >= G.rounds.length) G.phase = "done"; else G.phase = "ask";
    render();
  }

  function renderDone() {
    const newBest = G.score > G.best;
    if (newBest) { G.best = G.score; lsSet("nhq_num_best", G.score); }
    const stars = G.score >= 900 ? 3 : G.score >= 600 ? 2 : G.score >= 300 ? 1 : 0;
    $("#main").innerHTML = `
      <div class="scroll"><div class="wrap" style="text-align:center">
        <div class="nc-stars">${"★".repeat(stars)}<span>${"★".repeat(3 - stars)}</span></div>
        <h1>${G.score} / ${G.rounds.length * 100}</h1>
        <p class="muted">${newBest ? "🎉 New best score!" : `Best: ${G.best}`} · ${G.log.filter(l => l.pts === 100).length} first-try, ${G.log.filter(l => l.pts === 50).length} second-try, ${G.log.filter(l => !l.ok).length} missed</p>
        <div style="text-align:left;margin-top:20px">
          ${G.log.map(l => { const q = roundQ(l.r); return `<div class="rrow">
            <span class="mark ${l.ok ? "g" : "r"}">${l.ok ? "✓" : "✗"}</span>
            <div><div class="q">${esc(quizPrompt(q))}</div>
              <div class="line"><span class="muted">You:</span> <span class="${l.ok ? "g-t" : "r-t"}">${esc(l.guess)}</span>
              · <span class="muted">Answer:</span> <b>${fmtNum(l.r[2], l.r[6])} ${esc(l.r[3])}</b> · ${l.pts} pts</div></div></div>`; }).join("")}
        </div>
        <button class="btn primary start" data-nc="again" style="margin-top:20px">Play again</button>
        <p class="kbd">Press Return to play again</p>
      </div></div>`;
  }

  function onClick(e) {
    const b = e.target.closest("[data-nc]"); if (!b || S.view !== "numbers") return;
    const a = b.dataset.nc, r = G.rounds[G.i];
    if (a === "submit") submit();
    else if (a === "next") nextRound();
    else if (a === "again") startNumbers();
    else if (a === "minus" || a === "plus") {
      const [, , , , min, max, step] = r, inp = $("#ncVal");
      let n = parseNum(inp.value); if (isNaN(n)) n = min;
      n = Math.min(max, Math.max(min, Math.round((n + (a === "plus" ? step : -step)) / step) * step));
      inp.value = fmtNum(n, step); $("#ncRange").value = n; inp.focus();
    }
  }
  function onKey(e) {
    if (e.key !== "Enter" || e.metaKey || e.ctrlKey || document.querySelector(".modal-back")) return;
    e.preventDefault();
    if (G.phase === "ask") submit(); else if (G.phase === "reveal") nextRound(); else startNumbers();
  }
  const main = $("#main");
  main.addEventListener("click", onClick);
  document.addEventListener("keydown", onKey);
  G.stop = () => { main.removeEventListener("click", onClick); document.removeEventListener("keydown", onKey); };
  render();
}

/* ---------------- Road Trip ---------------- */
const TOWNS = [
  { name: "Nashua", title: "Signs", topics: ["Signs"], x: 300, y: 700 },
  { name: "Manchester", title: "Signals & Lane Markings", topics: ["Traffic Signals", "Lane Markings"], x: 360, y: 610 },
  { name: "Concord", title: "Right-of-Way & Turning", topics: ["Right-of-Way", "Turning", "Signaling"], x: 280, y: 525 },
  { name: "Laconia", title: "Sharing the Road", topics: ["Pedestrians", "Bicycles", "School Buses", "Railroad", "Emergency Vehicles"], x: 380, y: 445 },
  { name: "Plymouth", title: "Speed & Stopping", topics: ["Speed", "Stopping", "Safe Driving", "Highway Driving"], x: 260, y: 365 },
  { name: "Lincoln", title: "Parking, Lights & Emergencies", topics: ["Parking", "Night Driving", "Lights", "Emergencies"], x: 330, y: 285 },
  { name: "North Conway", title: "Alcohol & Penalties", topics: ["Alcohol", "Penalties", "Crashes", "Safety Belts"], x: 440, y: 215 },
  { name: "Littleton", title: "Licensing & Ownership", topics: ["Licensing", "Vehicle Ownership"], x: 250, y: 150 },
];
const FINISH = { name: "Test Day", x: 350, y: 62 };
const townQs = i => QS.filter(q => TOWNS[i].topics.includes(q.topic));

let known = new Set();
try { known = new Set(JSON.parse(lsGet("nhq_known_v1") || "[]")); } catch (e) {}
let trip = { best: {}, mastered: [] };
try { trip = Object.assign(trip, JSON.parse(lsGet("nhq_trip_v1") || "{}")); } catch (e) {}
const saveTrip = () => lsSet("nhq_trip_v1", JSON.stringify(trip));
const isMastered = i => trip.mastered.includes(i);
const isUnlocked = i => i === 0 || isMastered(i - 1);
const allMastered = () => TOWNS.every((_, i) => isMastered(i));

function tripPath(pts) {
  let d = `M${pts[0].x},${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
    const c1x = p1.x + (p2.x - p0.x) / 6, c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6, c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C${c1x},${c1y} ${c2x},${c2y} ${p2.x},${p2.y}`;
  }
  return d;
}

function renderMap() {
  stopGame();
  if (S.trip.sel === null) {
    const firstOpen = TOWNS.findIndex((_, i) => isUnlocked(i) && !isMastered(i));
    S.trip.sel = firstOpen === -1 ? "finish" : firstOpen;
  }
  const pts = [...TOWNS, FINISH];
  const carAt = (() => { const i = TOWNS.findIndex((_, k) => !isMastered(k)); return i === -1 ? FINISH : TOWNS[i]; })();
  const nodes = TOWNS.map((t, i) => {
    const st = isMastered(i) ? "done" : isUnlocked(i) ? "open" : "locked";
    const kn = townQs(i).filter(q => known.has(q.id)).length, tot = townQs(i).length;
    const left = t.x < 320;
    return `<g class="town ${st} ${S.trip.sel === i ? "sel" : ""}" data-town="${i}">
      <circle cx="${t.x}" cy="${t.y}" r="26" class="halo"/>
      <circle cx="${t.x}" cy="${t.y}" r="20" class="dot"/>
      <text x="${t.x}" y="${t.y + 6}" text-anchor="middle" class="glyph">${st === "done" ? "✓" : st === "locked" ? "🔒" : i + 1}</text>
      <text x="${left ? t.x - 34 : t.x + 34}" y="${t.y - 2}" text-anchor="${left ? "end" : "start"}" class="tname">${t.name}</text>
      <text x="${left ? t.x - 34 : t.x + 34}" y="${t.y + 16}" text-anchor="${left ? "end" : "start"}" class="tsub">${esc(t.title)} · ${kn}/${tot}</text>
    </g>`;
  }).join("");
  const fin = allMastered() ? "open" : "locked";
  $("#main").innerHTML = `
    <div class="trip">
      <div class="trip-map">
        <svg viewBox="0 0 640 760" preserveAspectRatio="xMidYMid meet">
          <rect x="20" y="20" width="600" height="720" rx="28" class="land"/>
          ${[[90,120],[540,330],[120,610],[575,560],[160,300],[500,90],[110,450],[560,480]].map(([x, y]) => `<text x="${x}" y="${y}" class="tree">🌲</text>`).join("")}
          <text x="560" y="700" class="tree">🌊</text>
          <path d="${tripPath(pts)}" class="road"/>
          <path d="${tripPath(pts)}" class="road-line"/>
          ${nodes}
          <g class="town finish ${fin} ${S.trip.sel === "finish" ? "sel" : ""}" data-town="finish">
            <circle cx="${FINISH.x}" cy="${FINISH.y}" r="28" class="halo"/>
            <circle cx="${FINISH.x}" cy="${FINISH.y}" r="22" class="dot"/>
            <text x="${FINISH.x}" y="${FINISH.y + 7}" text-anchor="middle" class="glyph">🏁</text>
            <text x="${FINISH.x + 36}" y="${FINISH.y + 5}" class="tname">Test Day</text>
          </g>
          <text x="${carAt.x}" y="${carAt.y - 30}" text-anchor="middle" class="car">🚗</text>
        </svg>
      </div>
      <div class="trip-panel">${tripPanel()}</div>
    </div>`;
}

function tripPanel() {
  const done = trip.mastered.length;
  const head = `<div class="trip-progress"><b>${done} of ${TOWNS.length}</b> towns mastered
    <div class="progress"><i style="width:${done / TOWNS.length * 100}%"></i></div></div>`;
  if (S.trip.sel === "finish") {
    return head + `<h1>🏁 Test Day</h1>${allMastered()
      ? `<p>You mastered every town. You're ready to take a full practice test: 40 random questions, and you need 32 to pass.</p>
         <button class="btn primary start" data-act="goto-test">Take the practice test</button>`
      : `<p class="muted">Master all ${TOWNS.length} towns to unlock Test Day. ${TOWNS.length - done} to go.</p>`}
      <button class="link" data-act="trip-reset" style="margin-top:22px">Reset road trip progress</button>`;
  }
  const i = S.trip.sel, t = TOWNS[i], qs = townQs(i);
  const kn = qs.filter(q => known.has(q.id)).length, best = trip.best[i];
  const status = isMastered(i) ? `<span class="g-t">✓ Mastered</span>` : isUnlocked(i) ? `<span style="color:var(--accent)">● Open</span>` : `<span class="muted">🔒 Locked</span>`;
  return head + `
    <div class="meta">Stop ${i + 1} · ${status}</div>
    <h1>${t.name}</h1>
    <p class="muted" style="margin-top:0">${esc(t.title)} · ${qs.length} questions</p>
    <div class="trip-stat"><span>Questions you know</span><b>${kn} / ${qs.length}</b></div>
    <div class="progress"><i style="width:${kn / qs.length * 100}%;background:var(--green)"></i></div>
    <div class="trip-stat" style="margin-top:14px"><span>Best leg score</span><b>${best === undefined ? "—" : best + "%"}</b></div>
    ${isUnlocked(i) ? `
      <h3 style="margin-top:22px">Format</h3>
      <div class="seg" style="margin:8px 0 16px">
        <button class="${S.trip.format === "mc" ? "on" : ""}" data-act="trip-fmt" data-v="mc">Multiple Choice</button>
        <button class="${S.trip.format === "typed" ? "on" : ""}" data-act="trip-fmt" data-v="typed">Open Note</button>
      </div>
      <button class="btn primary start" data-act="start-leg">${isMastered(i) ? "Drive this leg again" : "Start this leg"}</button>
      <p class="kbd">Get 80% (${Math.ceil(qs.length * 0.8)} of ${qs.length}) to master ${t.name}${i < TOWNS.length - 1 ? " and unlock " + TOWNS[i + 1].name : ""}.</p>`
    : `<p class="muted" style="margin-top:20px">Master ${TOWNS[i - 1].name} first to unlock this town.</p>`}
    <h3 style="margin-top:22px">Topics</h3>
    <div class="trip-topics">${t.topics.map(x => `<span class="tag">${esc(x)}</span>`).join(" ")}</div>`;
}

function startLeg() {
  const i = S.trip.sel, t = TOWNS[i];
  const s = newSession("practice", S.trip.format, shuffle(townQs(i)));
  s.leg = i; s.label = `Road Trip · ${t.name}`;
  S.session.roadtrip = s;
  render();
}

function finishLeg(s) {
  if (s.leg === undefined || s.legDone) return;
  s.legDone = true;
  const i = s.leg, pct = Math.round(correctCount(s) / s.qs.length * 100);
  const complete = gradedIdx(s).length === s.qs.length;
  if (complete) trip.best[i] = Math.max(trip.best[i] || 0, pct);
  s.legPct = pct; s.legComplete = complete;
  s.legPassed = complete && pct >= 80;
  s.legNew = s.legPassed && !isMastered(i);
  if (s.legNew) trip.mastered.push(i);
  saveTrip();
}

/* ---------- top-level render ---------- */
function renderMain() {
  stopGame();
  if (S.view === "learn") return renderLearn();
  if (S.view === "lane") return startLane();
  if (S.view === "numbers") return startNumbers();
  if (S.view === "roadtrip") {
    const rs = S.session.roadtrip;
    if (!rs) return renderMap();
    return rs.finished ? renderResults(rs) : renderRunner(rs);
  }
  const s = cur();
  if (!s) return renderSetup(S.view);
  if (s.finished) return renderResults(s);
  renderRunner(s);
}
function render() { renderSide(); renderMain(); }

/* ---------- events ---------- */
document.addEventListener("click", e => {
  if (e.target.closest(".help")) { e.preventDefault(); return; }
  const t = e.target.closest("[data-nav],[data-act],[data-sel],[data-format],[data-choice],[data-jump],[data-filter],[data-why],[data-town]");
  if (!t) return;
  if (t.dataset.town !== undefined) { S.trip.sel = t.dataset.town === "finish" ? "finish" : +t.dataset.town; return renderMap(); }
  const s = cur();
  if (t.dataset.nav) { S.view = t.dataset.nav; if (S.view === "roadtrip" && !S.session.roadtrip) S.trip.sel = null; return render(); }
  if (t.dataset.sel) return learnGo(+t.dataset.sel);
  if (t.dataset.format) { S.setup[S.view].format = t.dataset.format; return renderSetup(S.view); }
  if (t.dataset.choice !== undefined && s) {
    s.selected[s.idx] = s.choices[s.idx][+t.dataset.choice];
    return renderRunner(s);
  }
  if (t.dataset.jump !== undefined && s) { s.idx = +t.dataset.jump; return renderRunner(s); }
  if (t.dataset.filter && s) { s.resFilter = t.dataset.filter; return renderResults(s); }
  if (t.dataset.why !== undefined && s) {
    const i = +t.dataset.why; s.openWhy.has(i) ? s.openWhy.delete(i) : s.openWhy.add(i); return renderResults(s);
  }
  switch (t.dataset.act) {
    case "toggle-games": S.gamesOpen = !S.gamesOpen; return renderSide();
    case "trip-fmt": S.trip.format = t.dataset.v; return renderMap();
    case "start-leg": return startLeg();
    case "goto-test": S.view = "test"; return render();
    case "trip-reset":
      ask("Reset your road trip? Towns will lock again.", "Reset", true).then(ok => {
        if (ok) { trip = { best: {}, mastered: [] }; saveTrip(); S.trip.sel = null; renderMap(); } });
      return;
    case "learn-prev": return learnGo(S.learn.sel - 1);
    case "learn-next": return learnGo(S.learn.sel + 1);
    case "start": return startSession();
    case "primary": return primary();
    case "prev": if (s && s.idx > 0) { s.idx--; renderRunner(s); } return;
    case "override":
      s.overrides.add(s.idx); record(s.qs[s.idx].id, true); renderSide(); return renderRunner(s);
    case "quit":
      if (s.mode === "practice" && gradedIdx(s).length) { s.finished = true; return renderResults(s); }
      ask(s.mode === "practice" ? "Quit this practice session?" : "Quit? This test won't be graded.", "Quit", true)
        .then(ok => { if (ok) { S.session[S.view] = null; render(); } });
      return;
    case "retry-missed": {
      const qs = shuffle(gradedIdx(s).filter(i => !isCorrect(s, i)).map(i => s.qs[i]));
      S.view = "practice"; S.session.practice = newSession("practice", s.format, qs); return render();
    }
    case "new-test": S.session.test = newSession("test", s.format, shuffle(QS).slice(0, 40)); return render();
    case "done": S.session[S.view] = null; if (S.view === "roadtrip") S.trip.sel = null; return render();
    case "clear-missed":
      ask("Clear your missed-questions list?", "Clear", true)
        .then(ok => { if (ok) { missed.clear(); saveMissed(); renderSide(); if (S.view !== "lane" && S.view !== "numbers") renderMain(); } });
      return;
  }
});

document.addEventListener("change", e => {
  const t = e.target;
  if (t.id === "lmissed") { S.learn.missedOnly = t.checked; renderLearnList(); }
  else if (t.id === "optShuffle") S.setup.practice.shuffle = t.checked;
  else if (t.id === "optMissed") { S.setup.practice.missedOnly = t.checked; renderSetup("practice"); }
  else if (t.dataset.ovr !== undefined) {
    const s = cur(), i = +t.dataset.ovr;
    t.checked ? s.overrides.add(i) : s.overrides.delete(i);
    record(s.qs[i].id, t.checked);
    renderSide(); renderResults(s);
  }
});

document.addEventListener("input", e => {
  if (e.target.id === "lsearch") { S.learn.search = e.target.value; renderLearnList(); }
});

document.addEventListener("keydown", e => {
  if (e.metaKey || e.ctrlKey || e.altKey || document.querySelector(".modal-back")) return;
  if (S.view === "lane" || S.view === "numbers") return;
  if (S.view === "roadtrip" && !S.session.roadtrip) return;
  const inField = e.target.matches("input[type=text], input[type=search]");
  if (S.view === "learn") {
    if (inField) return;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") { e.preventDefault(); learnGo(S.learn.sel + 1); }
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") { e.preventDefault(); learnGo(S.learn.sel - 1); }
    return;
  }
  const s = cur();
  if (!s) { if (e.key === "Enter" && !inField) { e.preventDefault(); startSession(); } return; }
  if (s.finished || inField) return;
  if (s.format === "mc" && /^[1-4]$/.test(e.key) && !(s.mode === "practice" && isGraded(s, s.idx))) {
    const c = s.choices[s.idx][+e.key - 1];
    if (c !== undefined) { s.selected[s.idx] = c; renderRunner(s); }
  } else if (e.key === "Enter") { e.preventDefault(); primary(); }
  else if (s.mode === "test" && e.key === "ArrowLeft" && s.idx > 0) { s.idx--; renderRunner(s); }
  else if (s.mode === "test" && e.key === "ArrowRight" && s.idx < s.qs.length - 1) { s.idx++; renderRunner(s); }
});

render();
</script>
</body>
</html>

__HTML_END__

cat > "$WORK/main.js" <<'__JS_END__'
// NH Driver Quiz: shows quiz.html in its own native window (WebKit). Compiled with osacompile as a stay-open applet.
ObjC.import('Cocoa');
ObjC.import('WebKit');

var win = null, web = null, winDelegate = null;

ObjC.registerSubclass({
  name: 'NHQuizWindowDelegate',
  superclass: 'NSObject',
  protocols: ['NSWindowDelegate'],
  methods: {
    'windowWillClose:': {
      types: ['void', ['id']],
      implementation: function (notification) {
        $.NSApplication.sharedApplication.terminate(null);
      }
    }
  }
});

function menuItem(title, action, key) {
  return $.NSMenuItem.alloc.initWithTitleActionKeyEquivalent(title, action, key);
}

function addMenu(mainMenu, title, items) {
  var top = menuItem(title, null, '');
  var sub = $.NSMenu.alloc.initWithTitle(title);
  items.forEach(function (it) {
    sub.addItem(it === '-' ? $.NSMenuItem.separatorItem : menuItem(it[0], it[1], it[2]));
  });
  top.setSubmenu(sub);
  mainMenu.addItem(top);
}

function buildMenus(app) {
  var mainMenu = $.NSMenu.alloc.initWithTitle('Main');
  addMenu(mainMenu, 'NH Driver Quiz', [
    ['Hide NH Driver Quiz', 'hide:', 'h'], '-',
    ['Quit NH Driver Quiz', 'terminate:', 'q']
  ]);
  addMenu(mainMenu, 'Edit', [
    ['Undo', 'undo:', 'z'], ['Redo', 'redo:', 'Z'], '-',
    ['Cut', 'cut:', 'x'], ['Copy', 'copy:', 'c'], ['Paste', 'paste:', 'v'], ['Select All', 'selectAll:', 'a']
  ]);
  addMenu(mainMenu, 'View', [
    ['Reload', 'reload:', 'r']
  ]);
  addMenu(mainMenu, 'Window', [
    ['Minimize', 'performMiniaturize:', 'm'], ['Close', 'performClose:', 'w']
  ]);
  app.setMainMenu(mainMenu);
}

function run() {
  var app = $.NSApplication.sharedApplication;
  app.setActivationPolicy(0); // regular app: Dock icon + menu bar
  buildMenus(app);

  var rect = $.NSMakeRect(0, 0, 1200, 820);
  // titled | closable | miniaturizable | resizable
  win = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(rect, 15, 2, false);
  win.setTitle('NH Driver Quiz');
  win.setMinSize($.NSMakeSize(900, 600));
  win.setReleasedWhenClosed(false);

  web = $.WKWebView.alloc.initWithFrameConfiguration(rect, $.WKWebViewConfiguration.alloc.init);
  web.setAutoresizingMask(18); // flexible width + height
  win.setContentView(web);

  var path = $.NSBundle.mainBundle.pathForResourceOfType('quiz', 'html');
  var url = $.NSURL.fileURLWithPath(path);
  web.loadFileURLAllowingReadAccessToURL(url, url.URLByDeletingLastPathComponent);

  winDelegate = $.NHQuizWindowDelegate.alloc.init;
  win.setDelegate(winDelegate);
  win.center;
  win.setFrameAutosaveName('NHQuizMainWindow');
  win.makeKeyAndOrderFront(null);
  win.makeFirstResponder(web);
  app.activateIgnoringOtherApps(true);
}

__JS_END__

cat > "$WORK/icon.b64" <<'__ICON_END__'
aWNucwABT7tpYzA3AAAXpIlQTkcNChoKAAAADUlIRFIAAACAAAAAgAgGAAAAwz5hywAAF2NJREFU
eF7tnQuUHFWZx//3VlX3TPc8M5OQFwkoIk6QDYII6hIeyisH8HCc+NiDgh5xXRFWVHCXg5PsynGV
p8Kysrruuq6vjIoJEgILhri6YhbCKw8IkEASyCQzmVe/u6vu3fPd6up0xumk6zHTPTP1y+lM0j1V
XXW///3u9333VhUQEhISEhISEhISEhISEhISEhISMv1htTtFydADhm1g6KrlcdSQJZDYColVkACT
NTySSUKS0Tfo6JbaJH3j1IHapEfq6Onhk3nQ+qR8WY/kWAIGxiwApvrO+6XRuWv0eKuAtzJemCcs
LAAHh5iUI6oxAkwz3pCC72ca3xkvDO3cexfLlA6KxNBFnoFNeGtM7BBAPX4FOHqV4dH0d6OzdZNd
wCAugbDOgJTHsUhMBycdTuyh1B8SEBZkPknufze49jQYfwRW4eGhOzv2qOOljkNMoBAmrtVJxUXD
t3/p4MmS69cyKa5gRny2OikzC2nlYbcCtcYMhFH7Mw1aBExvABiHyCdHGecPMuDewW+1PqlaZbXU
sMLuREEzAQKQDN12r2+/Ye+x4M09kPJKFolHZD4JiIJzIvTd1AATcAxTChK/BCS9AKZrLNoMWUgD
kv0SVrpn6O55W5U3WAkJFmywGGzj00EW3VXrDQNXMc24jemxTpkdovOjsV8Dm/EGPwqS/CGN/Zw1
tDFpZjJSWj0jd3TcVhoWAhwSghOAY/zuLZG2RQvvZZHYZ1SPtwomGKOoP7jvmilIYYFpGmtsh8gl
1iA9evXIvyweKh9e/RKMUYrGb7rmxU69ae5qFm0+V6YHTEBqYDyY75ixkEeQFmvs0GU+uUWK0ctH
7l68E92rNfSu8B0X+DdO0fgtX9w9i7Om3zEjvkRmhwpgzJixNgscBkjLZJEWXYrCPpEZPXv0vkWv
BCECn0UHaVfyemSEyegDzIgdMv7MjOsnBooPGddlbtRk3JjHG5rWNn9+bwdWdwu/hSN/Auh5QqV6
bcP77+MNnWfLzHAB4EbJ+MX4Nvxpx/meXwRtzzRbBEbTOzRN/4nKCJasJPfg2ZN73tDJTduuffMT
LN7xQ5kl48OwjzRk4iCTiQJr7DRkev/Xhr+z8B/91Am8CUBVqFaiceDauRFdbmOMN8MqUErvz6OE
VImUYJoANyQK+dOH753zPLp7uZeg0JvBaNxftUpEeeHrPNraCqsgQuNPJoxBmGBaRAc371IziV3d
nlyvew9gR/2y+fr+EzXGXoCwNECEFb1aQOlhJK6JfOq8kXvmbfBSH3A/G0izeoDQrMINrHGWITOD
VOjRgx77qXowXWqGqshrF3qDhXYKDiatrwLYoGYQXeLSA1C0yWTrV4fbWSr9KrjRDlGgHMXlfsaH
9qIxwBRAtiBhWhPQaDXA0ICoztRPqyiGgLANznXTMuXJiX+es6O8HF8N7jxADzSsgsmS6eUs2tYu
s0MWGA9kcYfGgbwpMZSVaI1xvGOejgVtNHUwdWvITnfsGxHY2W9iICEQizLEIkyJOwAYzbGwaLOh
FQZXAPi6cgmoflWFOwHQEiab5bZTU7NYvs9D58BQWmBeq4YbL2rCh97VgLfPNVSPmQ4ICbx6wMRD
z2fx3SdS2NFnYlYThxXEcg8mGawc9ZKLbQGsdLVXN66bflfimqeMNn3eS8xoOF6aWd/RP/X8waTA
ZUsb8J2/asOiWYesTg03HSifDTmYEripdxQ/+H0Ks2JcDQn+oJRQZ1KYSYuztyTvmd9vF4aqmzau
Pg3ssatNzeyY48D5ImnmqDTFPFe3JKAz2/hXnhXDr7/QoYxPrpEMr8IbNj1edC50ThTbdMQ5vn9V
G266qFmdO8U8ftoQkjFYpuB6rEkT1hIlJlqPUSVV/6LK/QHoGt4GI6ZJSEtCMpq89vKHM4lETuC0
4wx876o2NaCQS9Q12+huXFO9Q+dC50RDnSOEb3y4BcuXNmA4LcC5lxYs3wZCahFIaCeptuh6ourm
q14AxZ0KyefRug6I4kIujzVuJzW68yOtiOhMuUIaDqY75eK+66OtaG4oCwg9tqUdjjFIIefb7XdO
1c3oosntnUom59PaNT/BHzVCIivx3hOi+MsTo6pXUO+YKZDQydudMEfH8lMakchIeyjwDM0HCfp7
gb2LJ6rek+tml5LW9HuWqhIOuX/TFLhwSbQ0Ps40VEtI4JJTopDKeP7a1LaJcJ03uUsDydHYw74f
B0BiVb3glGMNZ2XojMOpdC6Zb/ivCxyyh+ucwrUHCAIV4XOmxr+ZTryBIaLZ/b8WuPYAqsjkRHBe
UakPLXXzuoPpg92UVE334VWd8cRDe9bEA3g50GmPB+MFQW0EEFI3uB8CqNLsMwhU1EjxdYnftnDs
4WoWwMa9AErWC+KopwfqUh4h1DiuhnPGoLlaHee3LZ0e5X4/HgUQ4iAk1TUYNGdWvJjYkCjUtZ91
jjcBhEOAQkgBzjhG8yk88Or/4IWBnYgbDVi2YCnOO/Zd1Zk+qLZ03/m9DgFBBgEej7oOsCTN5HG8
PLwXV67/OrYNvgada2oI+PYzv8DVXRfj9rM/bxe6GD+CLwhCAd6DKvcegOzvaMAPQeyjRlDPJ+Pv
Sx3EinU92JvoxzGxWep9Gv/pz/0vrMWshhbc8p5PlsRSEb/9oLyK7JIwDXSJ4/aHsgl8/OF/wBuJ
frRG4ygIUxnaFJZ6zY614UcvPoqBzIgSS73eA8O9B1AZnDMX7A1bsH5lP/k4gV3GzOHTj30Tzw68
go6GFmXwcuj3yOgjuRR2DO9BZ2OrCha1Cmtn7Zl9v6jJINc78SSAQIYt/2c8qahUT0X8HH/z2zvx
+J6nMaexXfX8SpAI4nTrl6Phty3G1gGqnw0Oh4BqUH1L9WCOL268B7969XdHND79XqqQxXGtc3HS
rMUlj1CPuPcAVPDwOxmkxhG/sp88hLSgMQ23bvpP/Me2dZjd2Fax51MASLEABYOrzvwUoppRCg4r
B4E+28KZDPIwBIRB4FGg8Z2M/68vrMW3nvopOhpa/2zMd7BTPoaRXBLfWXY9PrjodCUGGjbqlfo9
sjqAjE+5/eodG3DT77+LDhXMVQ60yNAHMyP45vv/GitOPLconvpuYvdDgOO+fbutYK+RChrH+I+8
vgnXbfw2WqNNat6+krMmoQxkhnHj6R/DNe+8DJa0xVMVftvSsYn7JCD0AONBbpuMt6lvOz77+O0w
uK56dyXz0+f9mWFc1XUJbj7jE0W3X6Xxa4x7DxBkJdgF1Puo+uDMsqlAC0xNxASJU+J9hUq8j9yK
vDDRqEXU++NBxj+QGcIVbz0bdy37QtH4LqeBfMaAtgfw1gr1PUAVoRRs7BQrCYGMf6Qx2S3lJd7u
dT0YzSePaHzl9rMjOP/Y03DfeTeozIaOyaX5a4p7DzDJLsCZbqW6+73P/QpP739J9bKTO9+Cz73z
cpzYfuzRa+1VMF6JtyUarxjxk/FHcyks7TwB//aBm9Co0/UNQt3w3D0eu+9heJtU8iCAyVsR5Bif
Ztw+sq4HLw+/YVfWGLBp/3Y8uPMP+PFFt+A9c7tKQZsXqi3xOtiFngwWNM/GTy7+GtobmksC8kQQ
9vc4ueZFrpMGje5Uar12w914bbQP8+IdiBlRxPSoqsRRTf5jD6/Cn/q2qR45tiZfDU6Jl65zdUq8
nUfI9cn4GSuPlkgTei9ZpY6p3nP9I+FeACoWKp9/9PPvyjjVtM0HdmBz/w41tZq3Csor0IuE0aBF
kLMKnkXgtsRLmQAFhRGu40cX3owT2hb6H35U7/fThuXbus8D3QsgyOM9IrZfpJ5vWWLcVJlE4kcE
domXV13ipTGehHf/+V/GGXPfEVyhp3b29yiAScFO78jFcs4r3oXIqwj8lHgvXHyGr5ijnnDtAQRl
4+qqHr8vmlSq3BRO4eXdx5yEE9sXqnV3eoXiilsRBFHirbrKd1T8tuOh7d0PAHXsAeyrx6RKr769
7Do0GY3IWLmKy62rFYGXEu/B7Ii3Eu8UwLUHmEzIC9C4S17gpxf3qKnVrJX3LIKZVOKtFvcCUPmm
c+dDnz+rSIBJBNRrKdf3IwLKICjgKy/xUjRfqZIYSIm3Wvy2Y/n2LnEvgBrg5PheRfC/+7YgohnY
m+yfMSXeavEmgKDSFhd4FUHWzOOqR7+BX7/6e1zz+G3YPbofcaOx4uTOeCXeCb/KJ6j29BAFehBA
+XSg3yN3hycR6BFkzRyuefxbeK7/FTWvX6liGHiJt2r8tqO3eQDCgwBqi1sR2Is5NTQZMTUMVBrz
p1uJt1rcC6B2DqCEWxHY9X67fjEeE1LidUPtHIAHAdQJbkVQCZq7n7AS7xTAvQcgAktb/LWQXxGM
XcVbsxJvUO1JS/Zd4k0AdYQfEYy3ije4Eu/UYMoLgPAiAtpmOpd4q6V6ATjXmzlXBlHk4td1BYgb
EdTVKl7nqh6/bakC3Bk4BJQznggyZr60rJtSvQg30Jce9LeKdxpRvQcop4Zpy9EYK4KmSCP2pweR
yKcxkk/hzVQ/lh9/lr2KV923uA5W8QbVnh6Cak+LQu0rZDx8WxH7fP3t40iQCGjmj+YO/vuKO/Ff
2x/B1oOvqfWEyxacio+//QPQuH2hRz0s4Q6mJeiqCfd4EsBUgNw9VQEXNx+jrtYZS70Yv9a4F0CN
rgzygn3hiF0FpH/bPYTcvlYXPb+El67754r2EgN6EMCEKIBaINhLvBzI8GTw+iYoBbjfj7cgMAi8
T2BNP9zbLTDcDwG2F61mMc9RCfi6zimJ82BM31eIexSRNwH4VABd6EmZRCbn8ainEZk8XWsgA3hm
0mQVggKYDlYrfvMSW/dkA7nd0FRECPuBGS/tzSGboZtJ0J2mA7hIyCU1iQHUHbV1hkefSSoXSI+P
mWko18+AR55Jeoreg6ImArCERLyR43fPJ/Hcrox6gBK9N1OgU6XsZN9QAWv+OIJGeoSs/2fIesKD
AMpuE+djAoOek5crCNzw/X32gUv7qZrTHfWEVItueAHc9O996B8qIEoPjfLRliU7uJ8L8iKAYKAe
3xzX8NtnEvjKD/ZB0yhfB0x6IO00FIIyfFHhhs5w95oB/OjxQbQ26zBrqHz3WUBQlUAAlinR2qTh
9l8cQCJt4fZPz0dTo+2UqMGoijflxaAegG2Lm+4VTAJf9ZP9uPXnB9Ac01Qw6DWFOwyPnca9AMDJ
NMEUAkgEAkoE9z80gD9sS+FLV8zGxae14Jh2veLNlaciQ0kLjz2bwF2/7scft6TQ0kzPFvAzpTYW
pQDXMnAhgNKKkD77e4KL3Mk1tjXrKiW6+o7dmN8ZwcnHNWDxHCPwu4DVgr0DBWzZncXrfTlwjaGt
JWi3X7SHINsQ1T88unoBzDlHqYtJSXdsICcQ6EwqucbGCEMsqmMwYeLRpxN2VOha03WIxhCNMLTG
dTULSecaLMx2yoy9ae+3+tuFVy+ArqKP0a1XpJmSYPQQ6WBdgWoXKaHrQItR+aYQUw0nnjE9rNqt
Cim5FHlIYe1Qvz+nv2qFVS+AVUztNBkb2RkbaX+DaZGFEIVgx4IiKmKeFl1/MqCbKGpcmqmsFGKL
+sberVULwE0dQKJ7tYYfnpsFY08xLUr1PA+Z58RCkYmusdJr7ISTxu3PyquPnB/aZuzv0+85+6vL
ySsaU3iUzntrZu1pbwKSAauqtkv1HoA4MNuO/CR7GOAfqmkNcxzo4EwBJJOHnuLRGNdU0ak4umA0
Ydr/0RmaGriKZZNpAWnanSbaqMHQimMbg0pPUfysoVGDXvysbmAQjBtcWuxRdUzLntCwEZUfYzIG
dwLY+IStLIOvFfnROxnjMUgauWvfN2zjS7Q36bj0vFnFp3hKVWpNpOkBDkDUYOi+oAMNEY7XD+Sx
4bmEsvT5S5vx1nlRdWrrnxpF31ABEZ0hn5e44NRmHD/X/mzd/43gwLCpCjn1U5+QmiykhRRitTrI
c84R2Fi9PN0JgFxL92ot3XtyX+zyZx5kRutHZWGU1OZyP8FDBs6ZEvM6DNx/3bGlL1g0uw+3/OBN
xJs0xBs4vnf9ImXARzePYv3To6p3f255J654X5va5vy/f0WJIxblSCQsfP7S2bjszFa7c92YxZ7+
AiJGnQhAwmJGnAsz9WR6zanPokdyrHI3LLuJAQ5DSnGHNDNUquN+5gSC3Ja8AN1TsGDZqVbBlLj2
stk4fkEUuZztvCjFpM+UV6A3aAjICPWeKkMLCY1T1Q7QNCCVPfSZSVUrIoi6vd99OMcBzqTEber/
29wXZ9wLoHeFRV4gs/a0p6SVWcuMZhLA4c9NqxUUEJcFgdTT2+IavvLhOTDTdFNIlAWBhwxZHgQm
MxashInhlKl+0rBSCgJLjV4HCGExPabJ/MjmzJqla1Tv72Wu7eDNdXd1U4WGafy5G4WVuQiMMneK
lGofCygb0YO8ObDppTS6Fjfg6gs6cfcDB3AwYSljV4I65Xu7mhCPamhu5EikLCzoMOrA2uPAuCok
M8FuoPIctq1235k9j900znRLLdG7dEf80s03s2j77TI3VABDbVuruKLGovv2g2H9UyN4bmcan7m4
EzetmIvr7tujlqOVKF+Bo+YlJO7+7MI/a+1SsWPsip1aIYXJorN0kT94b+o3p28kW3jp/YQn1Sh6
mcCyDXrqwXfdIfODv2HRVoMOLJh1TX7XRtlEdYZ/+lmfigk+fm473rckjpFUuZc8XAEkjdf357F9
dxYv7c2qn6OUBh6G32Pzub20LGY06zI/tDmdb/myqs30elkJYONdAGRpSgt7erjO+JWikNzGdCp2
y6pz0ImGplt3bk/iZxsGVep388fmqWnZStCahE/evgtdn9mKs65/EV2f2oJ1m0bcR1YThbq7dYMm
rVyfKfMfxvoTc/ZwbFdpveBHALArTisxsubUYQtiubQK+5QIhDT9Ct3X9kVorp1FOL758z4VzZ/9
zibML47pdkA3zgRq8T2V549tVp+d19/20oQW1SBZWpjZy3MPnrlL9X6Xad9YfAqANEDxwGott+bU
17iVXCZEYSuLtJInKByazpu8lqNvclI6SttkI8PWXWl8/+F+de65gp3u2atz7Bf929mGYIyyCVq2
JZWISiliSRWTdz7F+zAUmN6kQ4p9Ipc4P/PQuzfZ4/4K11F/8AIgiqlh4qGzXubWwDnSzKxjkTZD
laXJbU1Se5F9dMbQGOEqdWtq0IACEG/UcNvqPpXvUzGIPlNTs3RcAmhRJd5izZ8zlUXQMVNyS8OI
85lRqikHsHy7mn2otpOC2lJauU2mlX1/Zv2ZT/oJ+sbiLQ0cj6IIkr3nDgBYHrv02VsYj9DLkIWE
3aRMPUYzuJUkZVB7koEOjBTwjz9+U+X7f9qeghFh6v2+gwVcfdsunPq2mNrqxT1ZVe6VnOHnGwex
fU9Wvb/7QE7VD6jmY0Q5fvrbQbywK6M+2zuQn5wysISlmovyfLrFXT55T9p84ytYf0kuSOMrb+cl
cDgy1O3VrmVs+dOnMW7cCq5dCKZBmkk6LwoSaXqGJvwD/X5nMiinIn0JRLjq8TQNT4JIqomdYjVP
52ppOkHxAQr2+5EYTQbZpV6SayotSttEi97Ac8RVGfum/2p2VepMj6uSihSFJ5mVvSX10BmPqU09
lHqPRqAGOIyy3DR+6eYPCmh/y6T8INPjhgoPrBwgTJqlqXrqslrIZRM0fpcvuKUSr6M5am+nskvF
IecBlLRku9zAR/osEKiUzjWupnR5BNJM0UFulFLek/nN0l+q71CpXjeVtwLX3sQJoKTYlcVsAWi6
bEuXkNaHIOVFkOIUaJFWOmnbEQV+bnWOfc5SUGfIpsA0WsXxGLj1AJXZSwevjO8/2KvExArAgU6C
8tWylCV+6fPHMImTLFgnQYr5kGIhGLf99UyAa2+AsX0MeFmafFtm/V/sPXTakqG7l0+k4WsDjWHL
Nuj2qpWQMTDVNtRGk0gNDVFUubPKaKZCq617V0o3y7hCQkJCQkJCQkJCQkJCQkJCQkJCQtzx/2CZ
Vxk+6IAeAAAAAElFTkSuQmCCaWMwOAAAKvyJUE5HDQoaCgAAAA1JSERSAAABAAAAAQAIBgAAAFxy
qGYAACq7SURBVHhe7Z0JlFxVtff/59xbc4/pjBBmgUeAoBBAVGRyeIDDpxJA1PceLr6IKCAoC4f1
mbTP8YHIIA7gkqeCYFoRGQQkSMKgBA2QECJDmMlAhp6ruoZ77/nWPrdup9Lp7nTSdW/dqrt/rLJN
d1Xd6Zz/2WefvfcBGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZh
GIZhGIZhGIZhGIZhGIZhGIZhGIYJBhHMYeoJJaAAfWfoJ9MYeM9TCH6qFURUAJTAQggcCoFnIbAG
CnPK3b1TOI3R4pnRKT/7NRCYQ+1/KbBms0LXfAeInjhERACUwPwuiTnz3c7eJeyxukf75d2tjpAS
Q0qh2B+R+xMB4i0KqTbR933RM+bVLlQSgHTbCCIhCI3dwOcvNjBnmkDnSVblQ5+1UKULQwP7AMYh
cEqHK6e0D2R8XzhFCSEOBWBAsaXYcAgDCvaLQhhZOHaPMFOrAPt1YRdXW5b5Yt817b3bXfNiZaAL
aGQxaDwBUEqgCxJnVij4YmV0PJk7UlnFdyul3guIowB7TxFvNiBNwLEB5RoFyirw5L+BEUYCEAIQ
EvrZKxuqmKMHvwUKqwTwsBCJRyDz/9h6xbSB4VtBYvAsVKNNERtHAIY7/jbzvv3SvncpQ31MOOp0
IY1DEEsByoGy8oBdpI5uQ9HcnxqEcu+FgtzmMGrgnhA1PMcuyMdTtu70s4eAgISMCWEmARnTbcOx
i28K4AElxB29+bfux3UH0cgAzFeG9hc1iK+o/ps4dfxFSw3PzM9ctHFGPJn+iHKc/5JCvAuxDGAN
QZWG6GHTME+9nR46XXv9Xz9THZRSEHDKoiBhxqUw0+6AYReeE0LcJiz8butVLc81khDUdwcgs6w8
4uuOn0h9HsD5IpaeAbsEVRz0Oj3N7cnBwzATQ9EUkl6OFLGUhJmCKmULUPgtlH1Vzw87Vusv0m2w
fh2G9SkA5K1dBEVrupkvb5geR/oCCJwv4pkZqjhAJpztjvLc6ZkqoBRNGxSEYYhkK1QxS/PHW7YT
ApoajLO6FFbqTwAqbvSUS3s+q4T4b5Fo3kMV+gG7RN5+A4K8PAxTdRSU40BIQyTbXCEQxv+gf9OV
PTcc0FeP1kAddRRay4cklW2+9M2DDNl8rYxlPkgjvrKL3PGZICkLgWHI1BQ4xYEXHKdwUf9VM+7X
J0EWap04CetDACpuaOulW8+TRuJKSKNVFfotQBkQsj6ug2kwlIJStoilTVpWVFbh6t4Vqy7DspOs
epkShL/jlE3+KRc+3uIkDvmhMJPnqeIg4JRsMsUarEUx9Yj2EQAi3SFVYfAxuzRw7sC1e71YDyIQ
bs/4QmVqk/+iNw50EgcvEfGm81S+x4ZjKe78TGggZ7MQUuW2WMJMvNuINT3ecvG6D2qnILXhEBNe
C4BuXKewWi5af7SMN90npDFFFQYsCArfYpiQohwbRtwQZgpOYWBB3zXTb3QtgXAuFYbTAqAbRp3/
wg1nyljT/QKKOr8NYXDnZ8INTUvtkqOKWUfGUje0XbploWsJ0GBbjjYNEeETgLLZ33rxuv9rpNt/
B1VqV6UhvfSi4zI4SZ8JNRRZTvEnllBWzpapjkVtX3rrBr0qsBBG2EQgXFOAstnfeuEbZ8j0tC5V
HLDg2BzFx9QpOuegKNIz4mpw49W91866xGvjYbmg8AhA2duv5/yxzP1QdqtO2OFoPqauobxyqZcK
nWLfgr5r9rwxTCIQDgEor/O3fnHDfjKeWgGgXVna7A/fFIVhdhkdRuxQ+rkztHl+33V7/T4sIhAC
AXAj/GbsvTFZcOJLhZGYp4rk8OM1fqaBoFgBGYMwYn3I507ouX7mM2GIGKz9CEuOkS5hF4rqOpFo
pc5PS30c4MM0FjSVdYoK0mhHzLxlxpc3ZHRdwhqvDNRWAMrLfa0XbThXpDvOpUAKXudnGhYhDR2+
nmg9nAY8vTxI+S01pHZTgPK8v+XCtw6QsfhKKCepa/Lpek0M08AoZYlUu2nntpzVf93sxbUMGa5d
ZyuXVmrr3vgXkWg5RRX7bIBNfyYKkD8gQfVGthSLA0fkpu27CZ103cGXpK+N+VFe8mvr2fAZkZpy
ipvVx52fiQpCws7TqsD0mJH8vg4SWlybwbgGFgBtzLBING+5tN0wi6shjOlwqMBKjcSIYWqHLcyU
UKXsyb3X7bGsFlOB4C2AxZDo7HSkHLxQJFtnwi5QfG/w58EwNYdihExq+4v0qXi7UwVIwBaAu+9e
8xf7pxhm4XkIOQVOieY+AZ8Hw4QGihI0HCt7Ut81s5YGbQUEm11Ho78Qtrxw3YUi3tGhhraWA354
Fx4mqpS3JrCdhaCNCgO2AgIced1UyKYF6zvMpPkcj/4MU0YpR8Qz0rFzgVsBwc29dSqkUEbc+JhI
tHTALtLmiwEKEMOEFh0mDEct0Gc4P7jzDK4Dujuvom3r+sdFvGmeKmVJADjkl2HcZCGqdZEtyvxB
uav33eCGCPu/XXkwPgA35NduvnjDscJMHaWKOdrUoy47P9Uf1ntLBiedzASgpFuaTeufdedSEgKO
TdGBTbG88ykAV2qLuRO+1w0IRgDmuJaGYeMMJNMSVt6CokKKE3iytaS8oSR1enpZNpArKpRswHbK
LY6pPfR8pAAtqCVjAjFq1Yos6rIY1Ec7E7SdnVDqDED90N2WzH8CujVK4MIX42120yrEUwdBl/gK
/7ZdhnQb0ECeOr1CW1riwBkm9mw3cNTeMcSowBPvMFpTvMH+2fUWXt9q4/mNFjZRNjmA5qTUz8gK
pCtNFt2SFKRZspziEYM/3vM5gKbN/oYH+28BeEk/zvrDRSzxNmVp85+61mTvmG+QeW8IoCendAN6
78FxfHhuEh84LImDZphaGJhw8ka3jaXPF3D3yjwe/FcBWwYdtGdcY5MsglCjHFvEm+JGvudUAM9h
IQXN+WsJ+C8AbpSfI6DeA9pllcx/Echxdwvq3LTDYE/ewWlzk/jyB5pw8iGUuLENaki6MYW9QUUF
8snQFFMCe00x8Jnj0vr1rw0Wrl0yiF/9Lactuaak0NO40EJb1isbQjnvBfAjrPG/hfkvAOWLEBAn
UBKUvsiQYhpAX8419X86vw3nn5jRZ0qNx6aozbLzz/MJMOFjeN4P4JBZJn76mTacMS+FS27rwzNv
ljC1WYZZBKSy8rTt9dHTLljdtPknYtDv1QCfjVklqOjBrAXr0kqpeXRxdHWhazYK2oHUM+jgyL1j
WPKVDt35HYecfa7Hn/6uBSB0J89UQs+ILAF6kRjQiH/KIQk8fPlUbRVsHXC2TeFCZ8EJAaugpJmc
WRTtB+nr0vsJ+IffFgCdvBqUai/DTEyDVaKi6TJsN55G/p5BhXcdmMDdF09BC81UbOjfM/WLttQM
V8TJqvv1ee1oS0lct2QQU1vKlkDYREDBgZE0UBqaC+BJbwrt11Pw1wKY76qXkDhCGMkE9JgaLmik
6M8pHLVfDHdd5HZ+ajDc+RsHzxqg53rtp1px/skZbOl3wvqMyUlOZufRQTwBfy2A8vq/lPJgJU0o
RRFPQVzWxKD7XLSB5pTATZ9tR2va7fzs5W88yBqg0YeGoKvOasVTr5fw1GtF7RikZx4ahBJwLDJM
Di6fk69n568FUHYAOsreH8qiZc4QdX93Tj8w5OAH81swZw9Tm/3c+RsXet5k8afiAjf+ZxsSZrnz
h6pV0iIApchj1uxLXk9hEZ2yf/3GXwHwUhsVDtArACG609TRyeN/2twUPnt8RgeLsNnf+NBzJ6E/
fHYMl5/WjL6sAzNkAgDbIqWaPZBXSQh/8wH8FQCNTmpw3EDt8LxIj+jBf+30Ji1L4WoDjJ94PoHP
n5TBftNM5GkHOt1UQ/LS7VHYtu3/kOSjAChBxQ5bL361VQCHKqtA1+Xj8SYONQAK7z3+4ATec2BC
Lxex6R8dyPdDvoApGYlPvyuNbL5iabDmCMoJcISZaDNNMUefjo97B/jfIYtSKCXMMIXNUQOwLIUP
vz2p72/41iYYv6E2QAM+tYFkQsAOW4SgMIRyqN/4i/8CoCv+eQma4Vh0tSygNSNx6uGuAJBziIkW
nsV3xOwYDt0jhlxJIRxb0Xp9hCLQLN87TCAC4OJdS20nWlIoDJUc/NtME/tONfTZhOPBM0FDll/c
FDjubXEUSw7cCLVavyr7iv/4bmIMX09IkmfI9KNkn73aDcQMoef/XNwjmnh26f7TzG3Z976PuRMg
wL4SoAUQDvTcz1GYu3dMnxDP/6OLJ/xz9zJhmiKSbSFyAuBBph/DEFFuC5EVgPqrG8f4RZTbQmQF
gGEYBOQE1J62kJRr9UrHhsLbw4SC4XLCIanyFGBpY7YAGCbCsAAwTIRhAWCYCMMCwDARJnKRgNtF
ejKMR2UEcK3xziWABKVgBCBUd5cIQ7wnEy7C1CaCW47gKQDDRBgWAIaJMAFNARhm4ij6T9H/ukhB
20lx7oYfBCMAYXSwMKHDUW7pSIN2jh+Ro02CQH+lv/lCRNtoMAIQNsLk72E01PlluXP3F3N4pX8D
BopZxI0YDmjdEx3JFhi0d2b54bFFUB2iKQBMaHDD8JXu/I+tfwa3vvAgHn5zJboL/chbRcSkibZE
E46YegDOOPBE/XIFgz7D04LJEpAAhMm+0tsVjihRxg2pFnhzfer8ncv/F9evvB2WYyNjJhGTBuJx
2p1ZYbA0hAffeBL3vrYct7/0MH568pfRGs9UUQSCW3abGMGdj08TKoYZn8rO/9VHf44r/nkrmmJp
TEm2wKRt5MrTAhrpTWGgJZ7G9FQ77n757zjn3k70FgbLlX15PjcZghGAWtdZHOv4TE2gx2E77pz/
q4/9HD9Z9UfMynRAKUdbANv8/y70b1s5KDkWZqbb8dj61Tj3L99z36tXC6ogAmFsowEQjAAwTAXU
cU1p4JfP3oMfP307pqen6M49kW5cdCxMT7VhyRv/xA3P3KVFhByIzO7BAsAECnV+mt/f9sKDevSf
nm6H7Vi7dA6WsvV04dbnH0TWykPqgt4TkQ9mJCwATGB4I/8f1i7DF/76I6TN5HYBPxOF/AIpM4EX
el/Hmq2v6JgB+h2z6wSyCuDA0Su4YUjCcZsJN5agoTk8mf2rtryEyx75CdKx5KTMd+r0JcfGM1te
xtEzDtFCMpnFHM+TEI6W4fWVXbOMdge2ABjfoc5PEXzU+c/880IU7BLi0pzU3J0Wbmnu350f8P38
Gxn/LYA+AOkRS++1JByGSGTwOv+bg5tw1p8Xoq+QRdpM6N9PFrICaCowaUauANSaANsoWwCMb9C8
nEb+/mIWC5ZcgS35fmRiyap0frL46bsP69hXn//I3AFmYrAAML7gOuWUDtj55L3fwuMb1+joPXIE
ThbKAyg6JczOTMOcjv3013FY8O7BAsBUHdeh5sb3f+GhH+GRdavQkWytSucnaBmxr5jFafsdh2mp
NtiOzclBuwkLAFNVvBBfMs+/+ujPcO+ryzE93aYDfaqBIajz57B/yyxccuR8Nx+gEfd3D2g5wn8n
IHkBVTOlfLmvWuOmn4XjXBoML8SXlvvcEN87MC3VXrWRn0QlbxfQnmzCrz/4DZ0bQCsBohrjmG4T
IVkh9tpndTRzXNgCYKrGaCG+tpr8nN+d40sdBpwwYlh8WifmTj1AOxO9GgLM7sECwFSFaoT4jgU5
/Wikz5XyuOL4C3Tnp+P5Vh0oQrAAMJOmWiG+o0EBP7TEl7PyuP7kS/CJt50wfDxm8rAAMJNirBDf
aiXnGNLEplwPvv/uz+Hsg07R4b/kY2CqQwBOwIoowBD4AEPj6GkARgvxTRrxqgT6EOTx35Trxhff
/nF89tDT/R35w1S0KkBnZDACEKq76ykSMxn8DPElaJSnOP8L5v4fPfqTD8CQcjL5PjshDKOTR3AK
wFMAZpfxM8SXoEKgm3K9OHXfY/H995yvxYb8AFwJuPqwADC7hJ8hvt7IvzXfh+P3nIvrT7qkvM7P
nd8vWACYCeN3iC+Z/RTi+86Zc3Drqd/U5cApyZ/j/P0jGB9AGB0sYZry1QH+h/hKZEt5TE224Ib3
XYaWeGbYz+A7EU4HDkYAIgh1GG0uKzWcqupGIbspsvWUvhpMiG8RrYkMfndaJ2Y3TQ+u80ecgAQg
TCYA4a+X1fOQG7Rzzcg9R8r/1jHsdeLY8qL8vCq+MzMdsKqU3DNWiG+wUX7+toddJ7jzCUgAwoZ/
9j+N/NR4aTeb+197Ais3r8WLvW9qUaCRbc6UfXD6fsfpOviuFKlQe7eDCvEls98L8a1NoA+1iejt
EBVRAag+lTvd3PTsn3Htyj/gjYFN2wWv6N1vlcIP/vlbnHnQyfj60Z9CJpbabmPMMDEyxLc5nt6t
Kr6j4YX4ZktDHOJbQ4IRgDDNAHywrry5vd7p5tGf48crb9cebKqAQ2a+rlhbhv5dtEu45ukuPL35
Re3tJodX5e64YaDaVXxHQiG+G7Nbce2JFw2H+FKhj5rR4G10LHgZsArQllbU+b9W3uaK5shxw9Sd
iEZR+um96N+0rLVHugN/27Aan7y3U9fMC9MON35U8a0k0BBfZlxYACaJl5P+63/dh2uf/gNmpKdo
B9l4G1XQYEO57VOTrfj7hmdxdohEYLQQ32rG99P8vqcQZIgvMx4sAJPArXvnpqpe/WQX2hPNuj7d
RKEyWVQr7/GQiACH+EaPgARgZKRFGP49eXSMOgT+8to/8NrgW0iYcTi7uMIQFhHgEN8wtMmR5+B/
TbBgBCCM97YaK4Hl71ix6QW93fXuLiLVWgQ4xLeiFmCY2qr//T8gAWhQvBj1tb3r9Ny20tu/q9RK
BGoV4svx/eEgGAugwanGNldE0CLghfjq5ctyFV/yY1Rj8w7CreLLIb5hhgVgEngj/uymaeXQ3kl8
WZkgRaAWVXyDDfFldgYLwCTw3Ahzp+5fdv5VQQECsgSCCvHlKr7hJhABoJEyTC/K0KtG0UoqUUVQ
5ZppyTaUbKtqcf1+WgJcxXdHwtQ+vXMJwAcYjAA0KrQESPN/Cv755MGnYGuhv6rhrH6IAFfxZSoJ
xAJoZMibTXH8l8/7FE7c8+3YnO/TNe2qRTVFgEN8mZGwAEwSXa1OCL3v/S2nfhPvmnWormkXNhHg
EF9mNFgAqoC3dRVl/9166kK8M2QiwCG+zFgEIwBhiq7yKe3Ty+aj1N7bQiQCHOI7ASLQPmsrABEh
bCLAIb7MzgjGAgilxPpDWESAQ3x3lTCaAf4TkABEizCIACUncYgvszNYAHyiliJQsEs6Ocmr4js9
PQW2mnidgvEIRxVfploEIwDRtK4CFwEqL9ZbGETCiOG3zz+gE3ymp9thV6mEt7fakSvlGy/EN6pt
tFpKwoxOkJbAo+ufwYIHr8AvVt+NLy37MVJmoupVfKn60fUnX4JPvO0Ef7frZgKBBSAAghIBqjH4
yLpVuPzRnyFjJiAhq5LzQFAV3025Hr1V99kHnYKSY9eofj9TTQISgDDaV9UoCTRxghABivZLmXFd
kty949W5xsav4hvd9hmQADBEECJAgT/VKlBCcBXfxoYFIGCCEIFqQfkMm3K9Ot35++853y2CWif7
GTITIxgBiK6FNSr1IAI08lNS0/F7zsX1J13iVjwq/9eQhLGNBlAQIBgBYHYgzCJAnb+vmMU7Z87R
W5eRT4E2zuRCno0HC0ANCaMIUM2+bCmPqckWvWMvJTe5ux9Vp9wZEy4CEoAw2lfhIEwiEO0qvmFs
o/7PAQISAGY8wiACHOIbTYIRgDCKa8iopQg0dIjvRIloGw1GAJgJUQsRoJk9Le1xiG80YQEIGUGL
AIf4RhsWgBASlAg0fogvszNYAEKK3yLAIb4MEYwAOErvxhO6V8jxSwQ4xHcE2gEYzfYZjAAwu021
RSByIb7MuLAA1AHVEgEO8WVGwgJQJ0xWBExhcIgvU0MBqE5tiuoQpnPZBUaKwHGzDsXmoV49px8r
Vp+CfOjvg6UhtCYyWHxaJ2Y3TR/eKowpU6dtYrIEYwFENMrKDypFgLYhO3H227Ex1428VdSx/LS0
R6Y+vejftBX4pqEezMi0o+u0Thw+9QDu/KMR0TZavW1sx8EtTeW9aosr9PUt964IKJ2p9/sP/Teu
f/p2/H7tMjzf/TpKyobjuIU7SABmN03D2QefjMvmfRLTU+3c+cfo/d4uSuFoGcH1lUAEgKk+ZPJT
o6W5/cXvmI/PH/ExPPnW81jT/Sq68wO6IvChHfvisI79MTXVqk/A2ySUYTxYAOoYmt8TlK8fl6be
lZheI/Hy+TmnnxkJC0ADQKY+WQM0wisKaClD0wAJdyrAMKMRjACExwWw/T6lDQRZAwZV7eHCPbtH
GNuo//VAAloFYBgmlLBtyDARJpgpQKjsKyK4ZRYmzFA78OZMYWoTwZ0LWwAME2GCsQDC6GBhmEoi
2kbZAmCYCBNZAQhHyCcTBqLcFiIrAAavlzNlotwWgvEBhGiCpQPlDGD1a3n9+ClajokmXtDks68X
oCza/kzCCYU94Dkk/I8ECkYAQuRgoYcuJfDqphJsR3F8PIOXNhbDNEYFukoduSkAxconYwLPvVnA
pj4LZABUhM8zEcKQQj/75S/kIE2ha9dGjQgKABCLSWzpKeGhlVndAMgSYKIFJU6R+K/dUMBTLw0h
lRRwItgOIicAGh0AJvDH5f26EbAfIHo4jnvN960YxEC/jZgRza4Qyasm9c+kJR54ahAvri9CCkRS
/aMK6T/VRihaCr96qAexRDTNf8J/AegrD7kh2nhBOQoxCfT1lfDDP27WVkAErb/IYttKO4J//1gf
Vvwri3RSwrGd8G0OEgD+C0BIsWyF5mYDv/xLN5atzsI0BPsCIgAJPTn/tvRb+PqvNiCZkiG1/oLx
S0VWAAhv7n/B9W+iN2vrohpsCTQu1KVo9CeL70s3rsdrG4tIxmWkV4EiLQDk9c2kJNa8mscXfrpO
m4U0PWARaEwsSyFmCvzknq245YEetLWY2hKMMpEWAIIaQFurid/+tQdf/Nk6GIbQTkFeGmwc9FKv
7Xb+/13Sg4t+tg4tLYb+XdSJvABoEbAUWptNXH/HFiy47k1k846eJ5I4cJBQ/ULdm54hmfwk7D++
awvOu+YNpBKu2c/PFgGGApcXA8IKjQZkCdx4z1asfHkI118wG/MOTA1bCbRsRMV1OXMg/NAUjqZ3
5Nil18YeC1/5xXrcsqRHj/w6Mt0b/MNoBASXChCQAIQpGWAc3OmAgX+uzeHEr67FVz4xDRecPhXT
W7elTNDUgBoP5xCFC69De1M4abjr/Lct68WiWzbilQ0FtLXVy5w/uJJgvicDqZIUSDp1M9XQy4Mp
Q3f0zl9vxE0PdOOcE9vx0WNbcfSBKd3AmHDzrzfyuH/FAG5e2oMVz+WQSMk6dPhRiCq5pf3F39a8
UEkshcxMXfU3aaSPVlaONq3z/aKqAd0Y6uz5ooP8kIN4QmLO3kkce3Aa+8+M46gDU4gZtD0XTwtq
iTfyU3r3K28Vsfz5HFa+MoSBARtGXKApZejpQP3M9ylJwaRtXgbjJRza86fD3wAUTT7LwcvVxXcL
AMuEJT6+Mqsn0LR9jb+SUzW0A4mWjQyBZIupLYLVrw3h6RdzekYjTN6EI0woi7x6gIwJ7eSjJT4K
+bbp93XS5oZRtPGj4yDb1F/+nW+eCv8FwM296RGq/BR8uxR/oJHDWytOxyVkwu341LiY8ODte6i3
R3O2PTNNfT0qilMm07JPposUn+yrfPkrAEv1MiMVWXkGMvYxuBZz3aK9y9zxQ0k4KvlUAQUlZAzK
yb+y9c5DBvQ0utMf85/wVwDKCOANpSwqxuFtaMswzGjQIEmbvSq8of+8xt8JjL8OuROhHReOY/xT
OXkqv+Pv8Rim7nHXmIWQy/WlbKpnAeh0Tf5ENv+Ksgu9EDEuwMUw46EglV1QwpFP67dN93fa7POI
LBTNYXqW3DUAB88IGSePgDtd4xffA24DI9oALQHGpLLyPbDyz2kB6HKtaL/wWQAA1xHY6QghHoY0
yYNe145AhvENBUcYCUpJfXrw7nlbtAOQBlEf8V8Ahk0Y42Hl6PLL/h+TYeoRGhxljOb/j+rTd1fR
fMX3A3gmTHwgvwJWbiMkFePSuVi+XljjMJH7NNp7dva5yr/vynsr2d3PMTuiu4RU9pAjlbhP/316
185u8KQJYBlQKMxXRk+X6Mt89Kn7RSL1H6pUst0lSN+vryHQK0NjhINsy2wbXQSotsFItsnvts+M
dYzR3lvJ7n6OGYGCAyMhlTX0/EDsxRU6AKhLUD/xlQAEYBtSostRzn/CcaQODWYmhOUo5Iuji2U8
JhA33Q0uRuvog0Vnh78lYm6abCVjHWO091bjc8wOT8sRRlIqO383us4s4gRlYpn/e4MFIwBdFMmk
RKv59792F8VL0kjtr5wCeTdZBcaBwltzeQfH/Fsa3zt3j+3SkL2U5K/dtB5PPJdFppzBSJC1QOHL
LWkDi7++H5pSOg9DL7/Qd175h024d3kf0ilDv3+0Y1DEI733ujs3445HepHJuBmSHu652Tj+8CYs
+vQsHSWpy6uXP1d5DI6enAjCUFbOEgZu0u9e5q/33yMYAaDmd8JS882uk4YyH33qZpjJhSjmbcp3
nMitiSrUkanTdTSbOOHwplFvw7c+Mwsf/PraHSYAJBBUAusDRzXrhKZKblvao5NkvGnFeMf40+N9
273XQ5+bpTC9LTbquW13DJ7pjY+CLWIZ6ZSyj+T+9I5n/Q7/rSS4DrhsqV7PNIT9G8fKFgBJww83
jQlAozl10pLl/vReJVvhfe9oxqnHtGAga+syZpWQCPRlbf1++o6i5ej/T4UyRsaXjTzG8HtL42TT
CQyfE32n+91jH4MZC4e6gxBwfqHfsXRpYP0ysANRLAA5A/vvmPeSsAu/E7Fmmrj6GuTQKOiadlLs
8PL6+zfPman9AKOZ2qN9bjSH4ljH2Fnlo939HFNG0dw/LZ1i//PZ3r7bQfkyy07y3fkX9BTAZY5b
P0Mq+7uOlTsLEDG9XW/9ZWwHg3bxk0aObihR56ZR95iDMzjj+Db8dslWtJZrF4xb9bJylyZinGPs
sKPTcMMtF9bbrrhehQUycicoZnSo/RsxiVLue1h2Uh5nKrKMAxOAAC0AMgIEWQFy4M5jnoejrQCp
Cx8wu4V2BJbl4RufnIlM2nCr4O7WtzHB43r+afTPlTbepuf+2mEeHMEKwLAVoLQVoOx8kcofsS9g
9yDzm2pHUMkrKlf2H+/vQHbQrmrdQrIyvOq6o/0c6XdgdgkHZpKmwt/FfacVyqm/gfrFghcAbQXA
tQLs/JUi3moAKjCTp97xWgc59555dWibRa6Ar545A1PaTe2Q29ncfaL052xYPSVs7S2hr+LV3VvS
v+/NWhP9KqYSpWxhNptOoe+RXGLtLeQfCyLwZyRBLQNuD2U4LVQysXz5D/Ki7ywpk/srO183BUNr
SoXH5Lu3bsQvL91H729HvoC9p8dx/unT8N2bNyDT5K7x7y5eia35x7djn6lxJGgH3RFxAIWig0P2
SepDeO9nJgJl/RlQTqkUM+SX0HWm7Sb+BE9tBIDCg9cslt33ndmf+dCKzykjuQSQNlRtbkJoqUyX
HQEF+fxtTRa/XtKNz50+ddjn9qWPTcevHtiKTd0liMw4IuCZEmMcw7MgTj26Rb92xqgWR+UxmEps
kWg1VX7rt/vuOupJPfp3+h/2Oxo1UR0Nqd58ZWTvPupBVRy8WsRbTCinbE9yoviOxQK2h5b8UnGB
HyzegKGCM7y9+bRWU4tAaYjiAsbrdaPd4x0hp2KhNPaLYhPGhp/jDpviKMcWZsZU+e7l2fXqO67p
H0zUX7gEQIsAHMxfbORSL31FFXqXi1gTiQD7AyYArZ1kkhKvvDyEX9y3RY/A3src+adPxX77JHWI
72jJQLsCOf4oH2CsF0UbMhPFpnRf6TilHtOxzsGKeSV3adzfnP/xqNEUwEMozFGKSoeZp//jnJIq
PiFkrB1Oif0BE4Dm/TJl4Ko/vIVPnTwF7U3u1le0GcZl82fiyze8udsC4OUavLAuj3WbS3plgbZ1
GH5yEHo/xWltJg7bN8Xbpe0cBZgWjHhMFnoX9N3zzpdrafp71FgAhmMDjL6uY17OnP7E2Ui2PoCS
7VBaCe/ANz463j8u8Or6Aq7702Ys/PQs1xJQwH99oAO/W9qN/iEbzelddwjSFIOCU6/segs3dr0F
s3X7ffV0ENKghdNOaMc93z5w+P3MWChbJKfE1NBbnYP3vPP3OtuvS9R8CaV2PoBKKO/5hIfM7D3H
LFGlgQWQtH+zdgq6gw6/xsS2gXTawPV/2oR1W0vD0YGpuMQ3zpnlBvmNZKz7OQrJuIBMSTSP8qLf
pxNjNCF+ZhXtVlnCbDHV0JYbs3cdvYjaOu2YFQaxDIcAEMtOskgVc3fOuxGlbKdIdNAGaaUw3KSa
Mp6PTUfjKiRMgc1bSrhi8UZtAXge+fcf2YI9p8X16Y8bFzDOMciaIH/DmK+dnF/kUaok4u2mUxpc
kr3ryAV6uW/ZiaHxc4VHALQIkCWgzOw9R3eqwpYbRbIjTqmSFbu5M6NAxTzSzQZuum8LXlyX12vy
1GE5yaLWKEsk2mOqNPAPwyie7ab5LiI5Do1shksAqM0u0x0epJZOsftqYSYNQDpuzkBU7cox55Wu
naloE1Ogf9DSwUHuisB4OQETWwLcxnj3fSfnFslnRvMuxxJmk6lKg/ebdv8HB+44dqvb+TsDjfXf
GWETgG3qOF8ZuTuPvAROboEw0wakSfslhcZ0Chvk/afov9se2oqn1uaGfQFMwCjai1zYIjHVVFb2
xuydc/+9757je4CFujx+wGezU0IoAGUR0I5BZQ7eOe9GZfWeBWH2CDNjQG8yGDHHYEXm7XaZvCPu
A3nt83kH37p5vfvgXeNgx8zcMQyACb93xOd393MN9xwdZUPGBYyUgWL3ouE5f0g7PxFSAShDnlJa
Hbjr2MWqkDtFKfspEWsztSXg1hGIBJ5jz6DJEG0VIdxyXyNDcGhdvrnJxF1/68WyVQN67d77LP2k
oJ5KJ2EllceofO/OAom8z3nfPd4xGhdarVKWiFEChuiGkztr8M4jO905P8lc+EZ+j9rHAewMvTrw
kJm775inOj7y6Al5u+0qEW85T9lDgFOyUM4nblSog1G4be+g7UZGVBT9pGiJkSKg6wNQk/vNenT9
vwN0BxblJQC7vLZPob2VqwIjj0Gf8d5L1YjHWkGg31PmIZ2b9/6xjtGw0GAkhBSJNjL5H5N29tyB
e457Ua/zd4ZjqW886ieOc/5iQ+cPAMh85OmzIYwfCpnaQxX7yDlIrXTXo13qAK+4p1fZd/iJKegg
n1HLqVAHtpWODCSLYXg5oLwsQCHClSIw6jG89xYcFMYQAfoclSLLlKsOD1cnEW6l4ZFC01BQOTsB
Rzv6nKIFZX8nu/6J72DF50ruOv9JoVjn3xn1IwDupFZgIQTVFEi979E9ZKrp2xDyXMg4VGmAxkNy
fTecEFBHqyzJPWy+jaj2O9Kkt6zK4N1tUBTfyFF9rGOM9t5KdvdzdQtt4EGF+2h1Siag7MKDyip8
Y+jP89ztvLXZH2xVn8lQZwJQpqJ4QuZDK05xpHm5gPF+MgKUNUjl70kIpLZ9PU9BfV7p8Og92unr
Sxttsb/8u7EueYfPjfP+MY9RcexdOrd6wru3ro66O6yYSUMYcThWfrUQ1o9ydx71S31J7qhPFmpd
+abqtVu41sB8UA01d1rw4VXvd5S6TEjz/UKaUFaWil3SigF5y8gQruNrZWqCNvP1aG4KMw1dxMPO
r4ajfpRLv3Cz3sGnwiqtyTlOkvrvFOQbmPOsQqfraSUhANRnlFIfFWa6RTklgByGgKVLLrsesXCv
fjA1grz5gub2tHhqwEgKIZM0mNAmNn+FUjfn0uZt6DqsqE+wRmW8qkn9C8DwtICchPNdPwCA1L+v
nC1MdTaU+jigjhGxZpJvKKcAOEUy6kjdywFzJAzevRg3ap6pe7zlY/3syT50TXaqRiVNKYwkoC3I
ITIA1kgh/gyI32TvmrtqW1vT9fvGrtdeRzSOAFQKAVFeMSCaPvLkHFsZHxDKOR4K8yDl3vpB0+Xr
kAKLIjfdb1D2jrtpMo2DpDpJtDZK+9PGy7vTCSinSOZ9N4CnhDAfcSD/kk8d/sS2Qp3elJOcgOGJ
5Z8sjScAwyiBE5YabuZVxQP70Lp0Sm06TEg5BxBvV451OBx7ljCMmcqxpDBSrbxlYSNCA70ErFwO
QhSg1ABkbK2Ceh3KWqmEfCqeij/T33UYicA2yLl34olOPXn2d4UGFoAKaGmG9lubvllVWgaVVkNr
7tgWJ7ZRloo41EDcCHBzFiYwErCtobWJWHKwTxQLuHtebodDb99WGsLMH49oCMB2kCnXJbFpmnvt
DazuzE6gzr4GApuWCndw2OZDigoRFIBRKZfUJM9uF68QNDJdzypgUXmtvnHm8gzDMAzDMAzDMAzD
MAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDhJ3/
D4Nao1HyUkOoAAAAAElFTkSuQmCCaWMwOQAATmSJUE5HDQoaCgAAAA1JSERSAAACAAAAAgAIBgAA
APR41PoAAE4jSURBVHhe7d0JnF1lffj/73POudusmQlhM+2/tS4IWoUA4gooYRUQarCote3Pl0tb
tLhV7U+F1LZq1baCK4r8fv+qKGkRhLCWJahgK4HK5kapIBAgyewzdz3n+b2+z7l3MkkmM3f2e8/5
vO00IZnM3Hvm3vN8n+/zfb6PCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgEZhF+BpINMtrBGhb
xrbtQ8eS4+aeevUBXm8T79wa7HY5DlpnZaOppf4SAe3sHXdndj38dSKDEskmiXb9GUFCWhEApIo1
bqC/UHzZttXIJUdWZ3v6a/786a7Q9z2RARHpn+3TAbQAk7fWduxnBjaakVkfzgU2kG1idg8MCArS
gAAguYzoaL9hkyd9Gzy5xEw72PdfYHvMxA5bDnO5wFTeLibIisSTfhPZnBjzdmu8rNgwuVcKSBgj
JpKg4Nla8S4xcpcNrW98U/Xyq71aaeddQVl+HHq+l61Watu/dMDYXk/fBQVbjXx1XS0eJQgIkogA
IFGskQ3iSZ9MO+DrYF8tj2T8Svld4gWBhOHLTKbwMqkVIysm8Ap9XWK8KVfEii2PiFiWEYH2o+/q
gkiQrz90K8YYiYpDYqPqiIhvjInKEslXTaGvWivt/HFQ9e/STx64eL/dMwe7BQQEA0lBAND26oP+
oWL2XK/XAb828szLg8Lql0alwZeaoPAKW5sQL9/fI54vUiuKrRbFDfo6yEc1jfatuJeFDvqaRLDB
5H8CaB/x3V3X+qP4Pa1va317m4x4QeP3YnI9YjxPouKgWGtHTBRVxPe+ZkM7WjPZrxVKxdJeWQIN
CDZKSGagvREAtKsN1t9z0Nf1+lLBvCqT6z86Kg0cY4KOl0tY6vE6VoutFMXWdLA3ImFjoBed7k+Z
8utfAki+KWk9K2E98M+4iYEuIOR6XdwQlYbHTBSWxPe/ZsPaaK1n/6+NbTQ7drs+WmR4yboawUD7
4YbfVqyRC8SfGnmv/l/bu6v95mV+pvc4KQ29TfzM/l6hd9eAb3UCYHX9f8pgz0APYDrWxsk/UxNr
jVsqNPWAwIZia6UxG1Z/JFF1S7Vn/0vHN5pnJr+KZgUeEiubDAVDbYIAoB1MM9vv//DYidbk4kE/
yOyvEbstDYlErtavWs/re/XUHz9nAPOwZ0DgBybTIbqEYMPyqK2V7hSRLbVK5etjFx+8Pf4Ge09U
0JoYGFrZhit82bRB1+9cFV7Xu59cE2Sybxcjr/YyHSeJnxdbHo4HfWtrYowf5/gBYElY0bSi5gka
wYCfE1vcuV2yq74mUfmOwX/ounHyO1Mr0NIYLFqRDvxXbIikXm3b91djJ4mXe7VUht5uCqvXSFjW
6nwNCkIGfQArZFcw4GcCVzcQliSqTtwoVu6oSfmSsX98VlwvQCDQkggAWsk0A78xwfki4ckSFOLZ
fljVSn0jorN9AGgFulTgmoX4JtdjXFagNDAQRfZiK5mLRv5plXYSIxBoMQQArWDagd87X8SerFv0
mO0DaB9aLSg2zgr0iC0NDlgrF0U2uJhAoLUQAKyoxkE78Rq/pvrNngO/MVoDwGwfQJtxBYThjIGA
q3M6h10DK4QAYEVYI+/YGjR68fe9b+wkk/HOFztlxt8Y+Bs9eQCgnTRGF+t6DuwKBIqDA5G1F9uR
4kUjl/72gNs1oC3LCQSWHQHActMtffV9st1/8fjqIJu9zGR7TtfOe3Gq32jxHzN+AMkyNRDIdmtP
gZ02Cv906HO917gn6hoKzX5AGRYPAcByeofNxIfybPD73n/Jx8RG55lMYbUtj1kxrl0nAz+AZNNA
wJia8TJxS2IvuLFWHPrcyEUH3iwXWE8eEkMzoeVBALAc4kY+VjaaqOc9T633Cj0f9DKF9XZiQAtn
48pZ14uTQ3cApIGeMxLpNkIxhX5jSyM16/l/N/zYzZ9wSwGTkyUspalHv2EpHHtb4KLZhzaZVR8Y
usDz/euN8ddHY09Xra3piO9m/Qz+ANLDHUpkxHjGFgdCkcjzC6suWPXs112vkySXKb3gAj2ljEnq
EuLiLiVNZ7lZ/xPrvUKfm/VH49sjF/kad+oGAMDNgqKqyfdlbHkkFON/Yqi77+/cCadT6qawuAgA
lsIV1pcH45T/qg+OvU4kusr4Wd+WhqpivMxSfEsAaHs2CjUr4HWv8cLRHZvtyNNvHbn0hQMUCC4N
AoDF1ohWN1zh9/7Wa7/nZQqn2+pEJFGNWT8AzMrVQlVNpiNjrRkw1dG3Dv7zQZvjjKpbO6BYapFQ
A7CYLrBZXe/vPe/xE3Qty8t1n27LI5HY0CPlDwDN0HmpydjqhNYG9FsTXNX7/p0Xyu236+mm1p0r
gEVBBmBRuOMvjab8+87fdprNdF1t/MDXylYxhhcrAMxHXC9l3ZLA2ODm4X/8/BkiGyPqAhYHAcBC
1Qv9tNp/1VEv/t8Shh/VYzLjQ3sY/AFgYdxuwYop9GVtVLvZjg/8w/AX1v47dQELRwCwEDr4y4Ui
D11oetfuvNrvWn1aNOqq/N32loV8aQDAFDYKTb7Xt7VqZKpjpw9edPB1BAELwyA1X5PFftbvXTt4
tZfvPc0Wd5RFJCdcVgBYfNbWxMt44gfWlMbPHPzCQZtZDpg/igDnoz7497ztgf7etTsag39VxDD4
A8BS0WXVqCIS1YzNdV616v3Dp7tGa5qNtTQNmisyAHNVP7Ci7z1PnmpzPf9irO23Na1WpY8/ACwL
LQ70AmsyHV5ULV4zfM99Z8txt0duSXajHqGOZhAAzEVj8D/vN6fZfO/VYiNfwjKDPwAsO9cOIDSF
/fyoNLh5+PFbz5RDH7QEAc0jAGjWhit8PaQiHvx7rtYUlIQVEeOxjAIAK8ZWTWG/TFQaioMAPUzI
nSFAw6DZEAA0o36aX9/wU6fYoIPBHwBaSiMIGNyc92pvfHr0iYpcsq5GEDAzZq+z0eKSTSY8aNs1
+chkrojT/sz8AaB1mIzuwvK79jutXLUfkEuOrMq7f5VtncfXmsgAzGRyn/9hpnfta64yfu5UqY1r
L2pO8gOAlmK1MLAmXrZiSsNvHPzCb22mT8DMCAD2qb6GpIf6rH3N1V5+le7zp+APAFqV7g7wc0Y8
PzSlkTNdEFCv32rVh7ySCACmZY28Y2twQPezsqVa8F2v0KeDv+7z5yhfAGhlNorEz4rbJlieOHNw
9YHXy0NiXL8A7IYagOm8+/qsriGVy/YDfvd+9Q5/DP4A0PJ0Z5bWadnIj4LMFVq/FQ/+2rodU5EB
2FO9y1/feb8+zWb7vyu2kpWoFogYrhUAtA0bStBpbFi+brj3/rPcw954nC7jugYCEDIAuzn2tkAj
xb73PPFKm199tdhqp4RVBn8AaDvG16Jtr9D/ut7B518pG4+vyQVCAfcUzGonWRO/OG6X3qEX3epl
O15lyyMc6QsA7cyYqsl0ZezY9jOGvvz/XcPhQbuwJtKgg/9GU9NI0cv3vMqWh0N38AQAoH3ZKLDV
Yk06Vl+p2V1XD6DZXpABcOrr/qv+7NHTTdea79vKaE1EeIEAQBJYWzO5niCqTPxgeNX9rxE5TmSj
pL4egAxAo+hPI8OO/itdpCiWdSIASApjAs3qana3d/AFV2q2VzZsSv34l/IagKn7/b3rvWwX6/4A
kFw1k+0O7MTgmUNffNY1skFcq/fkPt2ZpTsCesfWIN7vH37A69xf1/2rrPsDQFJZz9ZKkc1kLz/o
gicLcqieKXxBasfB9K5za+r/ElN1W/6yvR+wE9rpzwviI6YBAIljjDYJCk2mszAxULtcLjZnxq2C
E/dMm5LSyEf7/G+SA96/rTMy2b83xu+SsKbXIuVLIgCQYG6CZ3ypFiMv13vGqr94/AzZdE7ogoAU
SmcAoKn/TRuiUkU+6HXs9ypbGtTUfypfAACQPpGxtXJk/czlPe99rF8O3WDFTQzTJYUBwAWefHVd
Tdd/jAnebYsD7PcHgFQxnkSV0MuvKng17zzZaCI3MUyZ9AUAGw4zYoydGDCXS7bQL1FVU0Kpi/wA
IN1sYMsjkWRXfXDVeU+8SieGrjYsRdIVALg9/xuiVe9+8lgv33eGVMZ1+0eqfuAAAGWM2Jo1ftBl
xfuETgy1NixN0hUAuB+usdbajWJDXfOh5h8AUssEtjQUermuY3ViKJveGKYpC5CeNQ83+/dC/SGb
bPextjKms//0PH8AwDSsiPHiiaHY49KUBUhRBkBn/1bcD9l4OvvnrQAAqWd8WxmNvFxP6rIA6ZgB
7zX7H9VDIFj7BwC4yWGcBTCpygKkIwCYMvs3Wujhlv618J8sAACknhHflkcmawGGLn7WlsZBcUm+
NskPAKbO/jNdx9qyzv618p/BHwDQmAu6iaG1UZSaLEAKagDqa/8Ra/8AgH2ZUgvwl0++Om4RnOy+
AMnOALjZvwl73v3EiW72z9o/AGCftBbAWBuaT8iGB9aLbEr0EkCyMwB9W93z8yI52QQFze9EvPIB
APvg2eqEGGOO6d5/VbfLAiT4jIAEt8DVgx2M7Xr3k2sC6z0ovr9GoqoL73jpAwCmZaVmCquMLQ5+
Yujpg/5WDhUjG00tiVcruRkAd7CDNb54bzYdq9dIVKsy+AMAZmSsb6sTuk38vEMPfdCXjSaxWYDk
BgCDj0SaAZCodoqEJS3zTO5zBQAsEmMkqoaS7ep5cmffS90egQ3JHCuTmQ6fUvznZ3putFU99CfZ
1ZwAgMViQ5Pr9aPSyB3DlSdOcBNKVw+QLMmcFWvx3wbre+KdLEFO2/5S/AcAaJZnK2OuGHD/fF9/
UosBExgAWCOXHFmVQ283NoreZMsjRsQme7tjG9GUEx9cA14D078G0Cr0qOCoagr9fiXs/EP3qFxd
WbIk7gm5tZpNEvbseN7xJtPZL2E5dLWAWHaN/Ra+t6vxcrlKD0ZgXwJPJOMbPbbMdSyPIt4vK8d6
Uiv7YqLT5B13fymuK0uW5AUAcfpfPPPUqSbbmbETxWrc+hfLQWd2nhvwjZRrViIrMl6q38WMyLP6
ffGSWXkCzJsO9howD01YGXJnlYlkMkbyWSO+/t43Uovqx5hgubieAGK943UZ4JlN5zwd9wQwiekj
n7AAQNP/pioX3BbY7c89V0pD2vsniOefWDpmcpZfCa2MFq3UQpGDV/lSyIj88Sk9EvgiuUDkj1/R
IVm9owGYpIGyBsY/+Z+K3PGLinTkjfz4vyvyo19VpFSzsn0olK5OTzKece+lmsbUbhhKzFjUiuJl
gI5+rzIhugzwebcMcInopDIRknUn3nCFr8Uafec9eYoNCldLreSLRPUENJaCpvf1RjRS0kHfypou
T17xvJy86rlZ+aOXdUhH1khnLlkvM2C5DE9EsvXRqtzyUFmu2FqUbUOhjE9YFwzkA5FQS5yJAZaQ
DU2227eV8Zu7MtUzH3/8xxXZtCHeYp4ACcsAHKqpfn1PHG1y3RlbK1ZETDYBP6eW0xj4h4vWVZK+
7sV5N+i/+ZgOOaBn99rSxmxFwwD9dwCmp5kA/dD3is70ezs8ec0Lcu7jI6/rlv94pCK3/aws3/lJ
Uf776Zp0FTzJZ0RC3ejMRV0Knq0Vxdro2J6ekTBpuwESNDWzRi4Qs3bkN7nRSubfTLbjFHH7/1n/
X0zuxhQYGRyP3Nrk+kNz8p4TumT9Ybndvo0uATQGe5ovA3PXyPBrQKC/1wLBBn3/fXXLuHxly4Q8
ur0mvW55IF4awGLS/Ipnxc+XTVQ8e/Dig29oZJoX87uslGTNxzaayEVpEr2W7n+Lz92AjMj2gZqc
eGhOrnnParnmL1e7wV/fJrvWJePZiw78DP7A/LitkiYOpPW9p0FAGIkLrvs6Pfnwqd1y78fXyCff
0OPqB3aOW8kGWn6LxaM/AVsz+Z6CtaJdAUXiTHMiJCcA2LDJPZdtA/2vMUFHKJFuoMFi0QFdbzDq
787pnRz4XcpSV8RMfJNiwAeWRmMJTd+LLuCeEghc+ef9cvJhOXlmoOaCdHbaLCpfmwJZa1669r2P
FeTQw2pJOSEwOQFAPSrTKE2jNY3aGI4WrjED2TkauRuM3mj++rRu94V1NqI3Gt32B2D5uIBbAwER
qYYixx2Sk2vPX+2Ccw0UJiqWeptFY704oxy91mWYN5rETC4Tcuu2RqOy57z7lzmN0jRaY+1/4XRw
1xn+SNHKG44suBuM3mj0hqN/R0EfsLJ0sM/4cTCu0YAG55e/s1/6OjwZKxMELJooikymM9y2o+94
9zXrGed2l5AAQESjssF8mDViT5BaSXNknguP+ZjXNdABvloTiWpWrjqvX674s373dfRGozccAK3D
ddvUIsBQ5MTDcvKzv9tfznhxXnYOR/H7lfvgAq6BawscmkxXIYrMce6n3vfsRIydiXgSDeVhk7Ni
Jmj8szCa0tdZfhRZ+bfzVsupv5+P1/k9Zv1Aq2psHdQgvbfguUzAG44uyPahSDIJ2/C9/DQdWtPU
Z2LW/1UyAoD6IQ2B3/NOL7+qR6JalfX/+Zkc/EMr33tPXOHvUv60UwLagmYDGp0Fv/NnU4IAMncL
YANbGdUw4F19H3qkxx0459oCt7dkBAB1RqMzL2j7H8pK0cIinT1YHfzfvdrt8deUIjcOoL3oEp5m
/fUG/916EKCFvFo4iPnSsxjC3ODg4MR8v0KrSUYAcNC6UFwBoD1eqsXkZDaWmQYA4yUr/3rerpk/
NwygPTWCAPWdd/XLCYflZHjc8p6eF42otA6gM9vv/1ZiCgETEABYowWAvd54wRp5TVSb0DjNc8dp
8r9Zr4DOE/R/vi8yMBbJhqPyctILmfkDSeCCgCiu3dn4+h6XzauGVoyJ3/eN9//sd4q0f4YYa8PI
ZLtyNVN9rXttJKAQMAEBQCxbzdSsteNxGyy6YjdLr5QO/kNjkZz4wpz8/2/v362NL4D2pu9vXdo7
5veycuV7+mWsFE3eIblTNiu+Uta6QxdGmv1XrS4xAUAxH+TFGFa45kjjJa3w7ykY2Xhmz2Q3Pzr6
AcmhGQCt5znpsLycc3SHFOkRME+aX/Y6klAAqNo/AKjvAPCK3W/38qu6JArZATAHQSAyNBTJh07r
djOEqYf4AEiOxu6Ar/9Jn6zqMFKu0jJ4bmxgyyPi2egdqz/4864k7ARo/wCgzhrJ6zaAuf1A001v
CCPjVk46Ii/nvaaLwR9IMHesjRUpZI1c9rZ+CUObgI1sy02vmcnbkp6F2v4S0x5CWzWxsNWk+ktX
bwZ6zT5+eo905oxbJyT1DySXywJEIqe8KC+vPSwnN91flu4OI2EiDrddJpFESZk6JyYDoEvZ7sdP
VcvsrIjGr6MT1hX+vfw5WTf409sfSD4X91uRj5za4+YCbiKA5tSvlR9WEnEgUEICAGus8fKM/s3T
V68RKx8+rYeYCUgRDfR10H/Fc7Oy/oU5twxI8D8HxhhXdJ4AbR4AWKOFGFqQ4UXRO7RAQ8QmZllj
qeibfWzCyulHFNxNoLFPGEA6NLIAf31ajxQyIiFZgCYYo0XmWmyuRefuH9SL0NtVmwcAMS3IsGLI
ADTJFQNFVl77grybCWjfcADpoeXSeh848tlZOXi1707+pP6nScYzrug8ARIRANQlYk1mqembvFwT
6e3y5A1HFdx/k/4D0kXf927LrxE5+4iCTExE3AfmwBWdJ0CSAgA0QSP/csXKq5+Xk74OLz7mNxEb
WgDMRSP4P/GwvHR1GKklYkjDXBAApIyL/GtW1h+Wd33BSf8D6dTomvKq5+fkwFUsA6RRggKA+qZ2
fq3vhdz7Vz0ApFy1cmCfJxuOKrjXO+l/IJ3iZQDrtgK++ZiCTBTD+v2Ae+ns40gyJCgAQDN0xq+d
wDqy5P0BxJOA3g6PpcAUSk4AQNA6c9Cqb3RjpFiM5E9e0eECABf9EwcAqeXX1wHe+vJOObjfl1I1
zghwP53lGiSkXiI5AQBmVt/qp7WrGd8w8AOYlMvo3mA6qaYNAUDKeF4cAABAg/YD0SCAliDpQgCQ
Eprq1/Tegf2+/MkrO92zbqT/AKRToxCwK2/kj1/R4ZYIuS+kBwFAyuiSX17TfQBQp3cEvS9wMFC6
EACkEHv/AeyJ+0L6EAAAAJBCBAAAAKQQAQAAAClEAAAAQAoRAAAAkEJBYp6z7l9pfGB6rtOXbvjR
37AVEMAU7v7AfXRWbq9kMnoBkwEAACCFCAAAAEghAgAAAFKIAAAAgBQiAAAAIIUIAAAASCECAAAA
UogAAACAFCIAAAAghRLUCbDe4E5/xfQa1wgApsN9dHbaBDAZjQDJAAAAkEbJyQAQujaJFAmA2ab/
3Cf2LTnXhhoAAABSiAAAAIAUIgAAACCFCAAAAEghAgAAAFKIAAAAgBQiAAAAIIWS0QdgQEQ66QQ4
KzoBAtiXqV0Ak7PVffEl6NokIwAAgCVk63f9yFqxdu8RwPfiZKoRs4SPYhkkaHDD7AgAAGAfdOAP
o0gCz3ef4Rujo/w+6fgZ2Ug847V7KIAUIAAAgD3oIG6MzueNG/zHqkW3xnjPM7+SO598QDoyuTgb
IFayXkbedMgJbtDvzXaKb+JsQGhD8YxPIICWRQAAAFPUonByxr+jOCzf+vlN8o2HrnN/PlKZkIHS
yOQgrzN+zxj58n1XSSWqykvWPFfOe/FZcsT+z5euTKEeCESTnw+0kgQFAJxj2RwW+YDpuHV+K27w
/+GT98lF9/6r3LP9V27A7wjyLiOgs/uDO/ebrAloGK6Mu2zBLY9tdRmCNYVeecsLTpT3HfFG92/C
tgkCuI/Ozi30zP5pbSBBAQAAzI+m83UmH0okn7/nCrn4p1fKcHlMujMd0pfrcUsCSoOEalTb65sE
xnd/tyrX5b7WjtKIfOzOS+WubQ/Kew8/R15x8It2yyygnSVnEkUfAACppgO21vXpIP+2mz8lH/nR
Je566MCvs35dy49X+/d942/8nc709fcaEKzt2l9uf/xeecPmj7tfNbOgywhAqyAAAJBajcFfB+0/
vflTcuXDd8jv9BwoYq0b+OdLv57WBKzKdUvG8+VN1/8NQQBaDgEAgFTac/D/3sN3yAEd/VIOq4uW
5I0LCgM3+58aBDSWFICVlJwAYM8uVvy3K2ia9gNIOZ2h65p/Y+bfGPynW99fKB3sNQjwPV/efP0n
5Nbf3OMKBlsyCOC+ue/7ZqP2Lzk1gAkKAACgCY3mPhO1krzt5k8v6eDfoIN91gtEjJV33fI5KYUV
FwTMVFcALLXkZAAAoAnVMN7n/7UHrpVv/eJmOahz9ZLM/PekBYJ5Py/DlTH5y9svcgWG03QVBpYN
AQCA1NA1+awfuIK8f75nkzyra41Uwr239S0VLSzszOTl3x7eInc88dN462F9iyGw3AgAAKRCo8Of
Dv5akKfr/br9b7nT8NoyWL/3lsf/y1336Q4XApYDAQCAxNtz8NclgKyfcTsBlpseLtSb63S1B4Pl
UfdYljsIARQBAIBE0xS7DrK3P/5fbuavv9eq/JWqwtfBPudn5eHhJ+SbP7vZXXsNCoDlRgAAILF0
zV178d/99M/l3OsvXPHBfypN/Qcet2CsnMScBRCn0BofmE58dZY/5QmshLjRj+dm+p/8yTfduntn
ptAS7Xj1sRUyOXdWwNsOO81lJPS9qVsDl1vjjjD1Hsp9YibJuYcSfgJInEaXP6Utfm99/B7XlrdV
evHr7D8fZN3JgeWo6nYDtIbkDG6YHQEAgETZvcXvJ12x3X75VS0z+DdoENCRya3IrB9QiVkCYAWg
CayQIOEaLX417a8z/6Vs8bsYVmIXwj7t2QYYe0vYPTQ5AQCAVGu0+NVT+P7i1n9q+cFftVQAgNRh
CQBAIqxUi9/5ircDZlag7A+IEQAAaHsr3eJ3rnzPk9FKUd5yyHrpqO9MWIkdAEg3AgAAba1VWvzO
ldYpaJOiVqn/R/pQAwCgbU3X4nclu/w1Swf/vJ+Tlx54qPsnejIgsNzIAABoS63W4rdZ2plwtDIh
p/7OMXLs2pe4YED/DFhuvOoAtJ1WbvE7G236o0cQv3rti10hIDsBsFIIAAC0lela/MYn+7X+gTqe
GCmGFTmoc7W8/vdepcl/VxAIrAReeQDaRqu3+J2N8YyUahX5wvHny+p8j1hXBMj6P1ZGcooA9Vzv
xgem57pY0esb7Wn3Fr+t3+VvTxkvkKcmdsofPu+1csJvH+kyFl6rrf1zH51Z4x6akOObyQAAaHmN
Fr/6azu0+J1u8H96YkD+4DnHylde+/54+x+V/1hhyckAAEikdmzxO5XO/HXwP+s5r5ZvrP9wnPJ3
/0fqHyuLDACAltZuLX6nCjxfdpSG3OB/2fqPuEFfs8gM/mgFBAAAWla7tfjdc/AfKo/Ka9YeIZet
/7D7Kx38dRsg0AoIAAC0pHZt8au0uK8SVl36/yNHvcX9txUt+mPwR+ugBgBAy2nXFr+Nwb8W1dxz
uPyUC+XIAw5xRX++8VvuOiPdyAAAaCnt2uJ3z8H/26d8XI5b+xIXCNDqF62IDACAlhG3+PXl7qd/
Ludef6FLobfD4T7x4K8tfqtuf388+B8+mckAWhEZAAAtoZ1b/Daq+zVgYfBHu0hOBsB1aKp/YHpc
H7SoXV3+xDX6ufXxe2R1vtfNoNtB1g/kf0a2yWde9edu5q+H/eiftZWp91AahqbiHpqsDAAvWqDt
7N7i95PyvYfvkP3yq9pm8NdZ/7bxnfLm56+Xt7/wde5xZ3wK/tD62ixEBZAkjRa/um7ezi1+tdHP
pes/VN/uZ2n0g7aQoACANYDZxT3IgFaQpBa/2uhH6wA0m9G+e/1ZA2hOclLNyVoCANA2ktjit30H
f6QRAQCAZUeLX2DlEQAAWFa0+AVaQ4JqAAC0Olr8Aq2DDACAZUGLX6C1kAEAsORo8Qu0nuQEAI2d
GcnZobH46ASIFTBdi9/OTKEtGv1MbfF72YkfTn5/f3ZTz6xxfaIVeCMtAZYAACyZRpc/1WjxuyrX
3RaDv9J2vk+MbZfzj9gw2eI38Ojyh2QgAACwJGjxC7S25CwBAGgZtPgFWh8BAIBFRYtfoD0kKACg
emV2yaoC1IFGaarZ2r2rP30vXuHSQi4sH23xq2vnX7zve/KtX9wsv9tzkJTD6vI9gAXQ9f0dpSF3
uM9l6z/iXjn6ykpPi1/uo7PTa5SMKsAEBQBIi8YMs1GM5Rsz4xlH7u1qI3dSG6HA0qLFL9A+CADQ
NnQQN0bn88YN/mPVopuf3fPMr+TOJx+QjkwuzgaIlayXkTcdcoIb9HuzneKbOBug+9E94xMILIE9
u/zptddMQNQGe3P1sVbCqmS8QD5y1Fvcfzd6FwBJRQCAttAYXNSO4rB86+c3yTceus79+UhlQgZK
I5ODfCNl++X7rpJKVJWXrHmunPfis+SI/Z8vXZlCPRCIJj8fC0eLX6D9EACgpbl1fituxv/DJ++T
i+79V7ln+6/cgN8R5F1GQGf3B3fuN1kT0DBcGXfZglse2+oyBGsKvfKWF5wo7zvije7faGvaRmYA
85fEFr/s9UcaEACgZWk6X4uvQonk8/dcIRf/9EoZLo9Jd6ZD+nI9bklAaZBQjWp7PY/A+O7vVuW6
3NfaURqRj915qdy17UF57+HnyCsOftFumQXMHS1+gfaVnACAVsCza6Nr1Ggio4P8227+lFz+i1vk
4K793MCvg45+zKaxS0BnqEoDgrVd+8vtj98rP3ryAbn8lI8nv7XrEqLFb8JM3QBAS/XpJWsjFZ0A
0Xp27yD3Kbny4Tvkd3oOFLG2qYF/XzQg0JoAbUWb8Xx50/V/44IBTffqGjaaR4tfoP3RChgtpdFB
Tn/V3vHfe/gOOaCj3+0jX6xJSVywFriBnyBg7mjxCyQDAQBaRmN//0StJG+7+dOTg/906/sLpUsL
BAFzt68AbSl+RktBt/k9PTHgGv1cuv5DrpBUG0bRLAppRACAlhFGOij78vUHrnUd5A7qXL2kAwtB
wNwsZ4C2FKYO/pet/7Ab9ONsBu2hkE4EAGgJja1kP3n65/KP91wha7vWSCXcu7J/sREENE9b/GqA
9rVlCtAW094tfk3KWvwCeyMAQEvQOZimkT+z9XIZcfv3vb329S8VgoDZ0eIXSJ4EBQB77mHhv+Nj
TKb7aC3xurLnWvve8/QvpSfbMbnHf7kQBOzbnl3+NFCLD8lZrLLMpTNdi18rei4Eaf+9cc/c9z0z
mXskExQAoF3p2r8OJv/3oRtkoDwivhc38FluBAF7m67Fb9bPuLXzVqeDfy2quedw+SkXypEHHFLv
/ui3+kMHlgUBAFaUDvTuYJ9KUS578DrpCHISRSs3uBAE7JLEFr+0fgZ2SU4AQPaqrbNXBT3JT6zr
7b/SCALiUxN1sLz76Z/Luddf6II03TbZaL/cyjS9ryf76cz/23R7nBvuo83dR+Pmom0vOQEA2pKt
p5L1sJ6h8pj4LZKeTXMQMF2L3zjt3/p3Pd3Sp2OYbvlj8AdmRgCAFdVYS9YAYLA04lr0rsT6/3TS
GATQ4hdIDwIAtISOTM6lnFdu9X96aQoCaPELpAsBAFqCDj6tNvg3pCEIoMUvkD4EAGgJrb6tLMlB
AC1+gXQiAEBLyPmZlm/OktQggBa/QDoRAGBF6Uls6k2HnCBru/aXclhp6cNZkhYE0OIXSC8CALSE
rBe4w3/aoUVrUoIAWvwC6UYAgBWnA6ru237JmufIWLVEELAMaPELIEjKJYgbyliRNuhRvlL0GjUa
77QKdya7WNdo5gNH/qH86Mn7JWqTNluNTIB60/V/0zaNZ5LY4lc7FWKB3C00vke02n2iZdSvUbvc
o2ZDBgArrpH2P3zNc+XAzn43O9XAoB2023IALX4BNBAAYMXpYK+DvjYCevMhJ8rO4ohk/PaZ0bVL
EECLXwBTEQCgJTR2A7zr98+UU3/3GBkojbRVWrfVgwBa/ALYEwEAWkLjEBc9DvhDR77ZFQXqiW56
pnu7aNUggBa/AKbTPndXJJ4uAWiB2lEHHCKXn3KhWxaoRbo1sH1epq0WBNDiF8C+tM+dFamgQYAO
/MetfYmrqicImD9a/AKYCQEAWo5u6YqDgMMJAhaAFr8ACADQdggCFoYWvwBmQwYALYsgYH5o8Qug
GckJAOqNAPk1bog440cbIQiYG1r8YkFmu3fw9/G9NVrQVW4ZyQkAkFgEAc1JYotfLQoFsDR4d6Et
EATMjBa/AOYqQQGA5mTITzV3DdoTQcD0aPGLxcH9s7n7p16nZEhQAIA0IAjYHS1+AcwXAQDaDkFA
jBa/ABaCAABtKe1BAC1+ASwUAQDaVlqDAFr8AlgMBABoa2kMAmjxC2AxEACg7aUpCKDFL4DFkpwA
gB0sadvBsps0BAG0+MWS4h6auntocgIApF6Sg4BSreKe3+2P3ytvuv5v3O+zfsbtBGh1njviueYC
mMtPuVCOPOAQ17XQN36rP3Qg0QgAkCjJCwI+Ibc8tlXyQdb9+qbrP+GeY+AFEtnWb0g+dfD/9ikf
l+PWvsQFArT4BVYeAQASJ0lBgDEi77z1s/L3//kv7lf97/YZ/I1Uwqob8OPB//DJZQwAK48AAImU
lCBA0/zVqCaf3vpt92uc9m/9mb8R45aUM17A4A+0KAIAJFYSggBrrXhiZE1hlftV/7sdZP1Anhjb
LucfscHN/Cthzf08ALSOBAUAlLCmroS1CYkIAkRc6rw9hv541r9tfKe8+fnr5e0vfJ177Bmfwb89
cB9t7j7a+lm4ZiQoAACml4QgoF3o4P/0xICc9ZxXy6XrPyQdQV58T3MXpl2eApAaBABIBYKApTd1
8L9s/YfdoB8fWMTgD7QiAgCkBkHA0tFru6M05Gb+l63/yGQRoKfbFgC0JAIApApBwOLTazpUHpXX
rD3CzfyVriQz+AOtLTkBgNZkUL8y8zVoXKOUIwhYPNroR/f6a/r/I0e9xf23lYjBv11xD519HNH7
aDJqABMUAABzQBCwcLT4BdpbcjIAwBwRBMwfLX6B9kcAgFQjCJg7XdunxS/Q/ggAkHoEAc2jxS+Q
HAQAgOgBO77rWKdta/XgGv29HmGrqW7sQotfIDm4uwF1BAEzo8UvkCwJCgDYvzL7/pXGNcK+EARM
jxa/acA9NG330AQFAMDiIAjYHS1+gWQiAACmQRAQo8UvkFzJCQDIXqUte7Xk0h4E0OI3ZfQeSkfV
5u6jCZGcAABYAmkNAmjxCyQfAQAwi7QFAbT4BdKBAABoQlqCAFr8AulBAAA0KelBAC1+gXQhAADm
IKlBAC1+gfQhAADmKIlBAC1+gfQhAADmIUlBAC1+gXQiAADmKQlBAC1+gfQiAAAWoJ2DAFr8AumW
nADAWuGjyWuARdWOQQAtfjGtZu8haf+8SFsmtr/kBADACmqnIIAWvwAUAQCwSNohCKDFL4AGAgBg
EbVyEECLXwBTEQAAi6wVgwBa/ALYEwEAsARaKQigxS+A6RAAAEukFYIAWvwC2BcCAGAJrXQQQItf
AAQAwApZqSCAFr8AZkIGAFgGyx0E0OIXwGySEwBYET6avAZYEfsKAnyzuG9DWvxiXpq9f/B5ibG4
dx4AM5ouCCiGZfGNv+ArZ4xxwcTTEwNy1nNeLZet//BkEaDuBACAqQgAgGW2ZxDQnemQseqEG6T1
77Ryfy500M94vlTDmoxUxuUPnnOsfIPBH8Asgtk+oT0MiJWeKflvTMfW/4eVpwN9aCM5bu3h8p/n
XiLv2/IFufqRH0glDKU31yk5P+MeZGStWKsHj+weFPie5/5Ev8ZIZUKqUVUO7Fwt3zjuw3Libx/l
/p1i5o9m6f1B11G5T8wmfm8lQUICAKD96MxdB/DebKdcuv5D8kePnyg/eOI++d5/3yEPDz3hnlDO
z0ohyLoBPc7iG7HWykB5wv1Z3s/Kyb9ztLz0wEPlLYecKKtyXe4GzsAPYDYEAMAK0iBAB2xN+2s2
QD/e/ZI/kH/52Y1Ss6Hc+8zDcue2+6UjyEmkpz1LJFkvI+cfsUHCKJSjDzxUjl97+OQziGzk2v4C
wGwIAIAV1ljz12yAzu51Fq9BQIOu68eBgrLiiScdmfxuj7oWhW5ZgMEfQLMIAIAW4bYDmngVNox0
3V9crUBPtnOvR6gDvmpU/uvnAcBcEAAALUYzAlMH9Lg4a3cM+AAWigAAaHFz3RYIAM2gWggAgBRK
TgZgantKTK9xjQBgOtxHZ9a4PnGJTtsjAwAAQAoRAAAAkEIEAAAApBABAAAAKZScIkCqV5pAFSCA
mVAFODutAExGFSAZAAAAUogAAACAFCIAAAAghQgAAABIoeQUAVK7MjtqAAHsy9R76N7nT0El7B5K
BgAAgBQiAAAAIIUIAAAASCECAAAAUogAAACAFCIASKGICl8Ae+C+kD4EACmi477niXTm+LED2J27
LzA5SJXk9AGgEcCMrBXJ+CLDIzW5/YExOeHFXRJZK74xqXrBA9hF7wueESlXrWx5YEyCrLj7ApHA
TJITJTEVTJFsYGRsNJTb7htzz5qUHwDfM1KsRLLlwTHJ5Ew9AEAaJCcDQCfAmRlx0b7+uv+q5PzY
ASxcV96X7oIvxXJNxCcBsE+NcSYZpwGTAUgNKxJFVoKs5zIAxYp1qT8XFABIpUYW8Nb7x2RouCYZ
34hNyOCG2bEEkCL6Zg8yRn7w0IT4nrjUH4D0CuszgLt/NSGjwzW3TIj0IABImcA3UqtE8sOHxt0z
jwt+AKRR4BmphlbufrgoQcGXkMKgVCEASBEd67O+kZGRUG68Z1TCiEJAIK0aOwAGx0K59adjkslq
AWBar0Y6EQCkTDWykuv05d/uHKlvDTTUAQApVKuP9pt+OCxjIzXJZzzuBSlDAJAyLgsQGHlqR1Xu
eLCxHZCwH0gbLQGq1qzcdO+oiM/sP40IAFJIK33Hx8P4jU8/ACB1NObXIuDRYiRbHhiXbM6jHiiF
CABSSJcBCl2+fOeOYbf+57b+kAQAUqOR/v/qjTtlfDSUXED6P40IAFJIB/tc1pNHnyzLl6/f6a5A
44YAINn0/a+7gQbHQ/nS5p0S5LzJ7YBIl+S0hNNXdeMDszBuu0++4MmXN++UPztltfR2+u7ycTQA
kGwa7Ov2vy9ft1Me31aRvlWBywo6ZAJn5joB6v9LRrckMgCpZMXqMkDWk8e3leWrNwy4giCyAECy
6Tgf9/638qVrd0i+w4vf95z/k0oEACmmb/yunkA+/Z2n5M6fT7haABqBAMnV2Pv/vz7/mDy1syq5
DPU/aUYAkGKNtcDhiUgu/OZTMl6K3AyBgkAgeTS410zfdXePyqY7hqSjQzv/Je95onkEAClXC630
9QZy84+H5aJrdrgsAEsBQLI0Uv+lqpU//sfHXBEwXf9BAADXDKSnLyOf2fSM3LB11BUIsRQAJINm
9PT9rBm+P/rcYzIyFko2o/v+k/H8MH8EAIgLfz2RsXIkb/nsY26WoIVCEelBoO1VQusye5rh+7eb
dkqnS/0z+sPd9gFxg31HwZexiVDe8tlH47VBw2FBQDvTk/5ygZEb7x11Gb6eNVmW+DCJAACTwtBK
Pu/LlVuG5JxP/nqyGJDJAtB+dPDXmf9N947JWRv/R0q1eNZPkS8aCACwG00N9vVn5Mo7hmTDJ389
+XdaLAigPZSruwb/1298RIxvJJPhwB/sjgAAe9GiQA0CvnfHkLzh73/tugNq61DNEABoXTq714yd
7u+/8Z7RycE/CKjpwd6SEQDE7ex3dbNqdLXi13lfk2rVSt+qjHzvh8Nyyv9+RG67f0x8PTI0sqQQ
gRakAboG65G18nffeUbO+eSjYo1xwXsUzv9ewH10mmuXkALpZAQAWBK6hriqJ3AFRKd97H/kup+M
iucZd5OhihhoDY0jUDRAHxoP5Y2fekw++pUn3IPLMPPHDJJzGNBuYSoWh5FaGMmqbt/NLk6/8BE5
+5W9csm7f0v6uuLDg+IGI4vz3QA0T99/2rRLC/3UdT8Zkbf9029k+2gofQdmpFbTu6JOX/XvWb5b
PMm5lty6MYP4he4KAI1IZ4cnV945LIe942ey+T9HXCZAB38XCETcYoDl4Ab+erpfB//BsdAV7GqA
PlwMpavguTqeePBXyRmwsLgSlAHAUmpsHeou+DJYjOTsT/yPnHB4t/zl69fIiUd0Tx4j3LgxeSZe
KgCwcI1ufprmbxTl6sD/5et2uCO9n9hZla4O330jlufQrCQFAAkpy2htenPRdUWTMXL91lH593tH
XSBw/tlr5KXP65Ce+k1INbYOalfBBoICYGaNYFuX17SgT2f5jUFfbR+uyddvHJAvbt4hTzxVlnyH
Lz0dHgf7LBt3fHIixptEBAC2FhgR00mqa3k0io56On2XZrzu7hG55b4xOXh1Rs595So5/vAuOeb5
nS4VuScNCkhIArtrrNI3BnulS/t+/ciep4dq8s1bB2XLA2PyowfGZGA0lFzek1WrMi4o51S/5aLL
ob7uruhcru+4lNo8ADBWLrDe4H9cX+qUtbeKXzhJquORGIlzYVhSjVRjb1fgtgduG6jK33/7Kfnc
1b4c2B/IW1/T72Ymf3rCaskE4nYQdOUpOwFmoql9DQTu/Pm43PXguPz00ZJs+emoG/T1PN8OHfh7
Avf+o0HXctKpj+fZ6kTZRnKr+86Dj7R1JqD9V2nfcXdGLjmy2nX2T//KFFZ/2hYHqmIks5wvC8Qa
aUq9KWkRUmk8dH944P4Z99bJZ4z86fo4GACwi6b7daXsP385IT+8f8y15B4YrUlxJBST9ySf81xP
/7jglizayrBW1z5tVB0+5NEfr9m69Z1VEavZ57ZNaibmVmyN12locr2i9PLrwK+0TiDfF8dhwxoI
iMiQFbnw/zy5oo8RaGlZTwpZT8YrNdfAp2+/jBvwdZcNs/1WoEsAnnl47dGdslWGWuERLURiAgAT
2Vq8OL2Qy4HF0tijrIIpRYCFVZkEpJ2AxdXYra9Ff+4Ybi+e7WtHTrQYayO/XG7r1H9DYgIALcow
Rpf+G28ltIqpiRlmMUATGPdbk7uZmc648Lz9tX9FVr0IQ4sybG2iLMart6YBAGCR6Na/IK9L/rcO
Bs+UtAC9ndf/VfsHAJs2uFTMC35z5222NlEU47MDAACwyExk/Lx41twiN5xalm1b236saf8AoM4V
ZYgJKAIAACwNq3UaPUvztZdfYmoAAjseVqW7ZES62CQDAFhcRsRG1hqZWNyvu3ISkAEwVnsB7Pz+
K8astV+RTJduzayt3CUFACSLteJ5magyPOJVKl9zz+2SdW0/ziQgAGjQZgw2EE+TGpTQAgAWk44r
tiPndZYX86uupGQEAPWdAMaY2211THcC+PEhtQAALJA1kfh5HVVu7av4lXgHQPtLxJOY3AnwaO1W
G05U4q2AAAAsisgEBW0CeNvDNzyvvgOgfVsANySmCFA90icdIl5ZxHSzCgAAWDRRzUpoEzVmJmSm
HBcCDv77uhEbRl83mW4KAQEAi0APAfIyUXlk3KtVv+q+YAIKAFVCAoAGY43nD+lWjUX4qQMAUB8q
bbEwOlpK0uVITgBQj8i8Yu0bUWVkXLdsUAgIAFgQa2om61aVL92+5bhxdwR9Atb/E5gBECkUh4si
tpi45AYAYGXYyJrIDCVl4G9ITgagXgegEZpGahqx0RAIADB/jQZAI+NeufYN93USsv6fyAyABgIm
ioZEbCicPA8AWBBtAWwn4uxysiQoA7ArMjMTE5dF5WErRqgDAADMj1v/79WJ5beStv6vErWn0S0D
bLjCH38kN9jRGd1mMp3rbXUsEiNtf2wjAGC5Gc/WJqomrF3vxpdB646fT4pkZQBU37M92Xpk1YrZ
LH5WlwES9QMDACwHXf/3/ag2PnDkyPBt7jtukkSNJ2Y5LuPyskYjtc7T7zvABvZx47IckRVrEvhc
AQBLpGry/ZmoNPDPE5lffkAeiSeXS/S9VkTClgBUYxmgMtC5NrjVZDpOtNVxlgGw5PQECt8Y14W6
2WizprHpAtpWBb5p6ntpa6ywyf5Yc3kec/m6++J7Rjyts2riui3G9wOaYzxbLVZMGF0nV50TJvGU
2QQGAHooQBypRWt/er3v50+U2oSmbagDwJLR/NJYMRJbnluGMNvhSzZj5hUEaOAwPFRt7r4UGOns
mP0tMOfn4Rvp7Jz96+6Lfr+RiVCk0uR1a/J5AAuj6f+Mb8OJwaNGhm/bEn+xJl+k7aPZiUqbiZcB
uk6+Z02U9x80xlsjtmbF3W6AxaWz11Ipktcc0S2vfmGXm6XqnzXjW7cNysNPlCWX9SSaQypAPzef
8eS809dIPrvvrEPjsfzyibJ8945BN9vel7k8D32o+m56bHtV/uWWgXm9s/Tfl8uRnPrSXjn6eR0z
Xre5PA9gEWj1v4kqw5+YyPzyb+WZDUa2mNoifN2WkswMgC4DrLs7M3bDEds7Xv9f3zTZnvNteVB/
eJmWuvpIBB1Uq6VITlrXI+89a/85PaffOygn537y15LPSXMzeU2Ta7o8EslljfzNWw9q6vvd8cCY
fPv2QQn8fTfIns/zeODRkgsA3ONq/ik4njFSrVh5/ctXyZ+c0L9ozwNYGA1vPT+qjFR9KX9BNrn0
f5MhfXtJ3i6Ahmevq6dr7A02LOsUKbnPFSuvvgRQDa2UKpH7dcaPmhX9OPuVq+QVL+qS8WIoXrNp
gzq9Te0YrrnvU9GvN833LFXjxzI41uTkpcnnUa7G329gtMmvuy/1JYDZrtucnwcwX1Yik+nUMPvH
o5lHR3VredJaADckd1DcZEL9wU1cdfhNUXXsJpPp9MVqd0BgaWjxXMY3rjBPf53xIzBuwNfP+cg5
B8Qp9HkUAzb1vXwzY+p/T3N5HjMtKTRLv0az120xvh8wI+OJjaKKZ81HZdM5FZENib1gyQ0AlBYD
utSNf734Oc2dJq6IA+3L90SiSOSUo3rkxHU9MjYRuj8DsFLivf82HB/57az/H25lK2F7/6dK9u1m
67qa/vz8cvitqDw4ICagNTBaSmPr21//4QGSyRhX7AZgpZiaCbrEWu+LD8lDoay7O0hq+l8lOwCI
iwEDLQYUsReZbJcGdAtctAQWj8sCWCuvOLRL/uCVq2RsPBTfT2S9EdDirBXjB1FleCBTHL/IFf+5
SWRyJTwAEKn/AE0wMXFxVB4e0B/wvuuggRVQn/V/+JwDpLvTl1pIGgBYfqZmMt1a/HfRyE0vH9Cd
ZEme/auEbgOcKt4SOHLTkQMdZ9xzkcn1XGgrrnsKWwKxOHS81pL8eY7bWgwYRVZ+/3cL8ubj++Qr
398uvT3BzIGArhXMoW/Abo9xX49zXs9jjo9jqsnvN4cLN/UxzuGfATPT2X8QROWhgaA4cbFb+0/4
7F8lPwMwNQtQKl2s6R2yAGhFOg5+4A0HyH59GanocVat+CCBRKrP/m3UmP0neu2/IR0BQL0WwKV1
bHRRnOahFgCtw2UBrLjGQG87ebUU59EXAMB87Fr710liWmb/6ckAkAVAG3Ad/qzIX561v6w9IOuy
AHPsDQRgztI5+09XALBnFiBgRwBWznTL3jrYaxbgoL6M/MXpa6RUmnt3QABz4Wb/vi4Np232n7IA
oLEjwBpXC1AdKWrRRxJPeELrc7P9aR5mIwvwrtetkef+dl6Kpch15gOwJGom1+/ZKLy4XvmfirX/
hpTdWowV2eTpD9rayrniBXpGALXEWFbjpUh+8Xhp2iK/OAtgZVWnL+87a3+pVCIxLX6IpT68hXwA
K8La0PhdflTc8YOekv8Z1/M/BZX/U6UsAFDnuDMCit8/+vu2NrHFZHv0MPNEN3tAa2hEmtro55+v
fEZ2jNTi3YN7hKB6Sp7+2R+vXy0veV6HTLRwQaA+zsbBRvP5VU/ppvshVoRGrZ7neRJ+9OmbXzIu
z6xxx8ivyGNZISkMANQGkQsu8DxjP2aj2pgYfwGbmYG5yWeM3PNwUb5+ww53D9IZ/1SNPyvkPPmr
DQdIGMZH7bYiPYyoryuY90dPd+CuB7Cs9GA4v+BF5aHvj31/3R1u9r/l+NRNBFPQCGgaelLgursz
Y1uP/EHH6/7zs17nwRfa4tNVMYbmQFgWhZyRz3/vGXnnqWtcul9nwVMr/htZgDe8sk++9KIdctcD
Y9LR4buGQa2gUZdw1PM65FeXHTrvh6SxTz4bz0M0mACWno3EyxgblYu9Vs6dkAs82fRga7yxllk6
AwClaz3r7s50l4PPjno7Xutlel9lKyOhGKNLAkDzXHe65j9d6ez+qd+U5UvXbJf/fe6B7lTAqdN8
zQLozF+PDf7IGw+UMx94WEQ/p/F95vE9J//NjJ0A5/Y89Hje7sIyv2Uaz32OjxWIeVb8nG9rQ+du
u/aoomxY57lJYQqldAlAGSvPXhfp2o8X1f7aRuGYeH40t/6qwPxEmtYv+PKVa7fL4zuqcfHfHodV
+/6u44LXH9krY0U9Lrj1ZsmNOob5/gosG5f6z3u2OvZ9rQOTDZtSO/i7UGjZLnwraiwFXHvkD211
+LMmv78uAUxZB5o61eD3u08huR7TX4/m6OYTP2Pk8e0V+ecrn97ntsDJ44LPPUAywZ71AnOdAs/l
Z9a8hewAmN8Gh7k8Dz6X9+1k2ixyM3+X+o/OlQtsalP/DekOAJQuBRx7W9Bdzn42LD51rfj5QKzO
z+Z6cwXmJooi6Sp4ctmNO+SXj5fduvqea/yN44JfeViXnO2OC665P+P1CcxFpA1/NO82LlH1jduu
XVeUhzYZkY175N3ShQBAlwK23O6WAlZFv3mjjapFjRJFC0WAJaQhZiZjZGC4Jv+w6al9V/rXY1Gt
BejuqB8X3HorAUArq5n8moyNJj4zcc2R18q6rYFsOieV6/5TEQA4GyPZYP1t124taXQo4o2LCTQL
QBoAS0oL/To6ffnO7Tvlnl9NTB4NvNubtHFc8LM75E2v7Zfx8dapBXB9AEI7/w/6AGCpxVv+grD4
9LXdxeCzWvydtoY/+0IA0ODqAU73NTrUKFGjRRGpLPVrE+mmtQCBZ2S8GMmnvvtUfDH2MbvXwfaD
bzjQHResA6dpgTSAruFnfDP/j8Bw4BGWkK77Z33N7GqG1zX82XqNLgUwudOtt0t45dtPY2tgMfjs
iHnmKD/Te5qtDIVivGXe54Q0CSMrXR2BXH3nkNx+36gc9/vdEkZSX+uPaRZA/+z3Do6PC/70N7eJ
17tyb18NRnTwf+yZivzLLTvnFYpoi+NyJZJTX9orRz+/09U/6PMEFoce9JOJxPiRhOU3blu3tSQF
66d1y990Vu4O0pKMla229rSYqmy44syO8vNu8zLdr7K1sZqI4Vphyei4p7P6T37nKXn1C7unHVB1
aNSB9/yzDpD/e/NOKVftPKvoF64RADyyrSwf/crj82tVqI1/RmrS1fm7cQCgzZAW/tCARthcEz+f
iSpDZxSvPfpayTP474n3216M1V0BWiASaX8A3RFgAk8sRYFYOnEWwJdb7hmRa/9j2O0I0PqAqdwu
AStyYH9G/vz0/WWsBY4LzmaM9PZnZFV/Rvrqv+rvm/lY3ZeRzOqMdOa5DWGx2arJ9WVsdeSa4rVH
X+PW/VPa7GcmvPOmoz2hN1i/pP0BysNnimSseIFuDIjXjdhazDXY12ugWXv++yk+9d1tUqlpOnzv
MtTGccF/fvoaOfS3CjJRbnKzylxfs01a6GFA1ap1TZGaNtfnween673q7s+2arL9GVsa3jwxMnq2
m9Cl7JS/ZhEA7Eu9SdDEdcdsttWRM+O1pGwolp0BWCRTy5Bs3AOgM+/LXQ+OyXdvH5z2oCBdKtBX
4OqeQN73Bwe4ZQMAdVEUmkxvxpZHNo/nf3GmbvGWLcdR9LcPBAAz2XpkVVNHGgREpbGzXZMg8VJ3
YhSWjw7nQWDkM5u2yXgpmjwUaKpGZuAPj+uTg/rj86vm11EPSBJbM5luP6pO/MAN/ps2WJEL47bv
mBYBwGzqQUDxhqOvsZWRa0y2LyNiq7P9M2A+NAvQkffl/oeL8o0bpz8uuDHg6+l5cVdAIOW0RssE
no2iMLKVv3ZNfo693RMxTa6RpRO3j2bU2wVPjI2ebSvDm3V9iSAAS0VLTbI5Tz5/5TOyc7TmsgAt
cgow0Hp08NcaLZOxtjp8ptZuaQ2Xq+XCjAgAmqLtgo8LdT1JU0txEKCZgKi89/msVB2lq+povmfT
7vt1Elnrjgv+79+U5Evf3z5Z+Lcwc3ldNmOPAoY5ff3pHkuz5vI8+NyF/1xa+RqqqBYP/oG1tfEz
dLmWiv/mEQA0TdeRLhTZ9KAdz//yTFsZ2WzyB+b0FSgSssaERaUHBeULRr5yzTPyxI7KtMcFA6lm
w9AEXYEYX2xt5IyJzUddF7f5PZIl2iYRAMyJridpEHBOOD4y+HopD1zo1phM1tAnAItJU/7ZjCdP
PlORf7rymX0eFwykVNVkV/mRtf8utZGTJja/jMF/HuhuN2caBFgjWyQaE7Ox49S77zbZ3FUi1pOo
GonRGm1g4bQgsNDhy2U3bpd3nLZGnntwjna5gDb50X3+lZHNE9e85AyXhdU1/02Gmf8cMVjNiy4H
mEhO/mVu4rojN9vK6Ou1AEX8nHYMnEtbE2CfdF1JO+0NDNXkM1c8xVY/pJzVJhhhY/DXpVhX4+A6
txruu/NAALAQNzyv3OgToGtQIsGABAXfBQGNqoBWrqHhsS1ujdRcNHPtRaQWWndc8OW37pB7H57+
uOCmNfM951PN0uzXna774XJ+v/k+Tv7d4r5P5nI9G1wrdj+SoMuPKsPXuCXYTQ/Grx6q/eeNAGCh
tOBkwxW+rkH5xceeG9VKuk2wHgTM5+6GtrQUP+r6jbJxXPAnL98WX5qlPDBvKZ4HMF/6eoxsKF7W
026ska2eMXHN4WfIluO0HivOxGLeCAAWgzad2GD9kZtOHiiOjrw+qg5fI5kuX4wXiR4mBCxAGNaP
C/7RkGy5b9T1BdCjgYFkc9Fo1WVVTTBga2OvL179omvcer8b+Onwt1AEAIvFrUFd4GlkqhGqlerp
YrJWW1OKWBpSpIQmfZr5mKvGccF/f/m2+Cje+tHAzXwv9zlz/IZNf925fuFpuERHk9dtEb4d2oE7
eM1EpnBAJgpLmzW76vb4b7hCi/2YVC0SAoBFtVGj0kgusN7EVS+6VsKJkyMrN5tMbyA20t0D3L8S
TAdp7cmfCYz7dc+Pxt83/nwuJo8L3rrruODpvseef6btgvXPdBmhWbM9D/16fuPr+s1/3X3RdsYz
XTf3+OfxPNC2ahIU9B0U6VZrzapqdjWu9D+HwX8RsQ1wKWw0kVamjm8++t9FNtzWcfpHv2cy3ae7
xoFhNRRj/KX4tlg5OkiVKlZGJ0KpRXbaAVejv8ZwqcV9cx466/9AawFe9oJOt0NAzfR1QmvFN0bG
is3dN5t5Hkq7FepSxGiTX3df9PsVy9GM103N9XmgHdUnSH4hEGsGbBS9dfza39/stljr1mtm/otu
zvcgzIGLWPW+b6KO19//OhN5/0eMrJawWM8EcIZbUuitK5c1ksvovWqWUVlEJkqRCxTm+gbUV4wG
Dz0dvnjubOBZvlf97/Xf6EA7m6afR/3ran3CRBNfd1/0++WzxjU9mvG5zPF5oM3ozik/44uXE1ud
uMYv7fzT0VvW76Sz39Ka6/0H82I1nWW7X3vz6jC/+jKT6YizAVFNG1doFoafQwLoqqU272mG78Wp
+floBAFzWVDS2XqzLarm8jyMWfiJhLo4phmFZszleaAN6MBvxBO/YMTKTutFf+KWT5Vb7yflv5Tm
eQvCnMWdqlwetnDm/acbay4zfm61VEd0i2soxnOrqZYyp7ZjRO9dOpvXOK/Jh+8K8+IMQHNDX73w
z/06h+/T0MT3W8jzUHN5LvHnL891Q6upl7BaqZlMR0bEE1sdu8YvDcazfjdhcq+QZt8amKdmb1dY
FLte2C4bUOg7T8R8zGS6fFsZjre1UB8AILFcqicU4wcm1y9SLd5kTe1zE1e96Cb3lKdMlLD0CABW
wpTUVufpP1kvfuf7xUYnuVOtqqNxcwsCAQCJ0Rj4g8BkuiSqjOwUE3yheM3ffkJkU8isf2UQAKwY
a2Td1qBxdGXHmT87yYg9X6w9WRd5bXWMQABAm9tr4B8wxl4UVCoXj9z08oF41s9a/0ohAFhpF1hP
NrqdAm69ywUC1p4vslcgoD0b+HkBaANNDPx6iM+W47UuirX+FcKA0ipcFLxhsr3lXoFArajvk5qI
a4PJzw1Aq7Hu0B6t6vcyxgSdmurfe8bvBv7jQor8Vh4DSavZMxA47f6TTBCcb23t5cbL9tiwKBJV
tYBc6wTICgBYYa45tQ7ogQ76Nizp7r4dIvLFTLV80WSqn4G/5RAAtKo9AoGuc5/YLxre9hfWmPOM
8fczfl5sbTzOCsQ70AgGACwTq5MQ3cPvu9m+XxAbVUaM+HfZcOKfJsLaXXLDMSPuwTDwtywCgFa3
RyAgJ/+4p8MPXmb8jvdaCV/msgI2FAlLIjaaGgwofr4AFkG9U1M86AdiAjHZXrEV7WMS7jDWfsHr
PeiLY5c/S2f+MQb+lscA0TaskWNv92XL8ZMnC3aetW1/W3nibdZ6xxo/83LjZ7unBANaWqOdBr16
doCAAECTGq0Zjd5vjO7bdzeQyUG/+owX9F5qw/HbJ0Yzd8qWF47FX9ga2bDJm1rPhNZFANB2Gm+w
N+re2clHPxkMiDnO+NljJKz0aKMNG06IhGXNDsQBgXHNiOqHEVFMCKB+wLSrKxI9MKI+4BvRPfuu
Z2VlZMxKNOEF3ZfasHj7hDd+l3z/laOT147ZflsiAGhrmhUQX7a4KH1S/5t39JQGH325ZHtfaquD
xxi/8HKJyj0m2x+XDFRd7YCILh24oKDxT+00p0MSJADtbepBC+4AqcZAr+qDvRXx82K8nJ71GA/4
1pbEM18z1o56putrY4VaSTY1Zvr1FP/+2y2z/fZFAJAYuzcW2isg2PnrYyS/6mW2OpAR671LjMkY
Y3pMti8OBDQkqGoWb48tuTbU4IJ9ukC7iQ+OyGiH0V0aA302LhGykdjq8IgO/rZWvMt4/l0S2Zrn
2a+OjeZLu1L7dcfaQPbfxKCfEAQAyROfEavrcI8822t0GtzNyT/u6ReRUhAcY/3el5vacGhtWBBr
3i6en3XLBfHtwTPZ3i4tIwDQTnRnni+2MqRFeiPxTiEbGr/g2bB0lxF7lxXfN9YW/Vx4Sabz96oD
39ovrtqfSlP7Y91Gtq6rZxk5oCdJCACSb/eAoGvUTi0k3OPN3tVfKEyO9pUgyEahvF2MThd2W2UA
0MqMF0mmx5PSyF15qf04LOa8oHc8tN2HmGkH+oZ1d2eka52VLRKnBRnwE40AIJXqpxI2sgRqpsAA
QLLoQN/A7D61CAAwReO44in0wCIA7enZj0Rxkd5UpPEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AFhE/w87w+TeYUPergAAAABJRU5ErkJggmljMTAAADHwiVBORw0KGgoAAAANSUhEUgAABAAAAAQA
CAYAAAB/HSuDAAAxr0lEQVR4Xu3de6xlV30f8HVn7mBn7MEz2NgzDlIdI2hUEQNxkNI0aVUokcrD
iOA4EEyI+INUMZRXKiWWgh+IgoLaQHFIgcpJHAzBJjjE4BAiUYmmLaRxUxGH0FYqFuAZj2ewx4/x
2z7VsX3t6/s85+zHevw+H2n+m3vuXvvsx/p+zzr7pgQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABEthR58EA3+95zdNLtFQCARdzx704zjwfm5sIB
rCPYA0AbFAXAagoACErIB4DYlAMQjwIAAtj37iOW6gMA27rj3z9bPoCGOcGhMcI+ANAnpQC0QwEA
lRP4AYAxKQSgXgoAqIzADwCURCEA9VAAQOEEfgCgJgoBKJcCAAok9AMALVAGQFkUAFAIoR8AaJky
APJTAEBGQj8AEJEyAPJQAMDIhH4AgKcoA2A8CgAYieAPALA5RQAMTwEAAxL6AQDmpwyAYSgAYACC
PwBAd4oA6JcCAHoi9AMADEcZAN0pAKAjwR8AYDyKAFicAgAWJPgDAOSjCID5KQBgToI/AEA5FAEw
OwUAzEjwBwAolyIAtqcAgG0I/gAA9VAEwOYUALAJwR8AoF6KAFhPAQBrCP4AAO1QBMBTFADwhH3v
OjKxMwAA2nTHbz9b9iE8JwHhCf4AAHEoAohsR+TBg/APABCL+R+RWQFASC78AABYDUA0CgBCEfwB
AFhLEUAUvgJAGMI/AAAbMU8kCisAaN7ed93m6f4AAMzk2G+fLiPRLCsAaJrwDwDAPMwfaZl2iya5
cAMA0JXVALTGCgCaI/wDANAH80paYwUAzXCBBgBgKFYD0AIrAGiC8A8AwJDMN2mBAoDquRgDADAG
805q5ysAVMsFGACAXHwlgBpZAUCVhH8AAHIyH6VGCgCq42ILAEAJzEupja8AUA0XWAAASuUrAdTA
CgCqIPwDAFAy81VqoACgeC6mAADUwLyV0ikAKJqLKAAANTF/pWSeAUCRXDgBAKid5wJQGgUAxdn7
ztsmxW0UAAAs4NiHT5e5KIavAFAU4R8AgJaY31ISBQDFcHEEAKBF5rmUQgFAEVwUAQBomfkuJVAA
kJ2LIQAAEZj3kpsCgKxcBAEAiMT8l5w8kZIsXPgAAIjOXwhgbFYAMDrhHwAAknkxo1MAMCrhHwAA
nmJ+zJgUAIzGxQ0AANYzT2YsngHAKPa+8/BklF8EAACVOvbhM+QzBmUFAIMT/gEAYHvmzQxNAcCg
XMQAAGB25s8MSQHAYFy8AABgfubRDEUBwCBctAAAYHHm0wxBAQAAAAABKADonbYSAAC6M6+mbwoA
euUiBQAA/TG/pk8KAHrj4gQAAP0zz6YvCgB64aIEAADDMd+mD0t9vAix7X3H4UnsPQAAAOM49pEz
ZDgWZgUAnQj/AAAwHvNvulAAsDAXHwAAGJ95OItSAAAAAEAACgAWonUEAIB8zMdZhAKAubnYAABA
fublzEsBwFxcZAAAoBzm58xDAcDMXFwAAKA85unMSgEAAAAAASgAmIlWEQAAymW+ziwUAGzLxQQA
AMpn3s52FABsyUUEAADqYf7OVhQAAAAAEIACgE1pDwEAoD7m8WxGAcCGXDQAAKBe5vNsRAHAOi4W
AABQP/N61lq2S1hvYqcAAAA0xgoAnmbvO26V/gEAoBHm96ymAOBJLg4AANAe83xWKAAAAAAgAAUA
j9EKAgBAu8z3mVqyG9j7r33vHwAAIjj2H/bLgIFZAQAAAAABKACC8+k/AADEYf4fmwIgMCc/AADE
IwfEpQAAAACAABQAQWn9AAAgLnkgJgUAAAAABKAACEjbBwAAyAXxKACCcZIDAAAr5INYFAAAAAAQ
gAIgEO0eAACwlpwQhwIAAAAAAlAABKHVAwAANiMvxKAAAAAAgAAUAAFo8wAAgO3IDe1TAAAAAEAA
CoDGafEAAIBZyQ9tUwAAAABAAAqAhmnvAACAeckR7VIAAAAAQABLAcYY0t63H5qEHDgAANCLYx89
IC82xgoAAAAACEAB0CCf/gMAAF3JFe1RAAAAAEAACoDGaOkAAIC+yBdtUQAAAABAAAqAhmjnAACA
vskZ7VAAAAAAQAAKAAAAAAhAAdAIy3IAAIChyBttUAAAAABAAAqABmjjAACAockd9VMAAAAAQAAK
AAAAAAhAAVA5y3AAAICxyB91UwAAAABAAAqAimnfAACAsckh9VIAAAAAQAAKAAAAAAhAAVApy24A
AIBc5JE6KQAAAAAggOUAY2zTpM1hAQAAMAwrACq0922HxH8AACAruaQ+CgAAAAAIQAEAAAAAASwF
GGNTLLOB2d3x0f2z/2cAWGXf22+1P2BGx644IFdWwkMAq+Pr/7DWHR89YKcA0KvNSuR9bz/U6+8B
GJMCAKiOwA9ALmvvQQoBoCaWalRk79sO+vifsIR+AEqnDCCyY1ecKVtWwAoAoFhCPwA1WX3fUgYA
JVIAAEUR+gFogTIAKJECACiC4A9Aq1bucVYFALn5nkYlfP+fVgn+AESjCKBVngNQPisAgCwEfwCi
siIAyEUBAIxK8AeAxykCgLHtGPsXAnEJ/wCwnvsjMBbPAKiA7/9TOxMbAJiN5wNQO88BKJsVAMCg
hH8AmJ37JjAkzwAABmECAwCL8WwAYChWAAC9E/4BoDv3U6BvCoDC+f4/tTFZAYD+uK9SG/mlbL4C
ULpJ6RsIj7vjigN2BQAM4MmvBLzt0ACvDkRiBQDQmfAPAMNzvwW6UgAAnZiMAMB43HeBLhQAwMJM
QgBgfO6/wKIUAAXbe9FBTwCgWCYfAJCP+zAlk2PKpQAA5mbSAQD5uR8D81IAAHMx2QCAcrgvA/NQ
AAAzM8kAgPK4PwOzUgAAMzG5AIByuU8Ds1AAFMqDMyiJSQUAlM/9mpLIM2VSAAAAAEAAywHGWKVJ
8hcAKcOxK84sY0MAgG1NVwHsfdvBbf8fEJMVAMCmhH8AqI/7N7AZBQCwIZMHAKiX+ziwEQUAAAAA
BKAAANbxqQEA1M/9HFhLAVCgUy66xRMAycZkAQDa4b5OTnJNeRQAAAAAEIACAHiSTwkAoD3u78AK
BQDwGJMDAGiX+zwwpQAAAACAAJYDjLE+HgHIyI79zpkj/0YAYGzTVQB7Lzo49q8FCmIFAAAAAASg
AIDgfPoPAHG470NsCgAAAAAIQAEAgfkUAADicf+HuBQAhTnlV2/xCEAAAKAJ8k1ZFAAQlPYfAOIy
D4CYFAAAAAAQgAIAAAAAAlAAQECW/QEA5gMQjwIAAAAAAlAAAAAAQAAKAAjGcj8AYIV5AcSiAAAA
AIAAFAAAAAAQwHKAMVZmUtn2UpNjv/PDNW0uADCC6dcA9l50ywi/CcjNCgAAAAAIQAEAAAAAASgA
AAAAIAAFAATh+/8AwGbMEyAGDwEsjWcAAgCQg3koNM8KAAAAAAhAAQAAAAABKAAAAAAgAAUAAAAA
BKAAgACOfeyHA4wSAOjCfAHapwAAAACAABQAAAAAEIACAAAAAAJQAAAAAEAACgAAAAAIQAEAAAAA
ASgAAAAAIAAFAAAAAASgAAAAAIAAFAAAAAAQgAIAAAAAAlAAAAAAQAAKAAAAAAhAAQAAAAABKAAA
AAAggOUAY6zLZFLX9gIA0A5zUWiaFQAAAAAQgAIAAAAAAlAAAAAAQAAKAAAAAAhAAQAAAAABKAAA
AAAgAAUAAAAABKAAAAAAgAAUAAAAABCAAgAAAAACUAAAAABAAAoAAAAACEABAAAAAAEoAAAAACAA
BQAAAAAEoAAAAACAABQAAAAAEIACAAAAAAJQAAAAAEAAywHGWJdJXZsLAEBDzEWhaVYAAAAAQAAK
AAAAAAhAAQAAAAABKAAAAAAgAA8BLI4nrwAAkIu5KLTMCgAAAAAIQAEAAAAAASgAAAAAIAAFAAAA
AASgAAAAAIAAFAAAAAAQgAIAAAAAAlAAAAAAQAAKAAAAAAhAAQAAAAABKAAAAAAgAAUAAAAABKAA
AAAAgAAUAAAAABCAAgAAAAACWA4wxrpM6tpcAAAaYi4KTbMCAAAAAAJQAAAAAEAACgAAAAAIQAEA
AAAAASgAAAAAIAB/BQAAgN6ddeUFM7/mzW+5Zub/C8DiFAAAAHQyT9jfyEY/rxQA6J8CAACAhXQN
/ltZeW1FAEB/FAAAAMxsyNC/kdW/TxkA0I0CoDiT4rYIAGDs4L9VGaAIGJK5KLTMXwEAAGBLJYT/
1UrbHoBaWAEAAMCGSg7anhEAMD8rAAAAWKfk8L9aLdsJUAIFAAAAVYdqJQDAbBQAAAA8qdYwXet2
A4xJAQAAwGNqD9G1bz/A0BQAAAA0E56VAACbUwAAAATXWmhubTwAfVEAAAAE1mpYbnVcAF0sd/lh
BjAZ4DUBADbQekieju/mt1zjvZ+HuSg0zQoAAICAWg//K6KME2AWCgAAgGCEYoCYFAAAAIFEDP8R
xwywEQUAAADNUwIAJAUAAEAUQjBAbFYAAAAEIPwn+wAITwEAANA44R+AKQUAAEDDhH8AVigAAAAa
JfyvZ58AkSkAAAAaJOgCsJYCAACgMcL/1uwfICoFAABAQ4RbADajAAAAaITwD8BWFAAAAA0Q/gHY
jgIAAAAAAlgOMMaqTNKkqu0FAPLz6f/8pvvs5rdcM/8PNs5cFNpmBQAAQMWEfwBmpQAAAKiU8A/A
PBQAAAAVEv4BmJcCAACgMsI/AIvwEMDSeAYgALAF4Z9BmYtC06wAAACohPAPQBcKAACACgj/AHSl
AAAAKJzwD0AfFAAAAAUT/gHoiwIAAAAAAlAAAAAUyqf/w7n5LdcM9+IAhVIAAAAUSPgHoG8KAACA
wgj/AAxBAQAAUBDhH4ChKAAAAAoh/AMwJAUAAEABhP/xeAAgEJUCAAAgM+EfgDEoAAAAMhL+x+XT
fyAyBQAAQCbCPwBjUgAAAGQg/AMwNgUAAAAhWP4PRKcAAAAYmU//AchBAQAAMCLhPw+f/gMkBQAA
wFiE/zyEf4DHLdsRhZlMCtsgAKAPwj9VMBeFpvkKAADAwIT/fHz6D/AUBQAAwICE/3yEf4CnUwAA
AAxE+M9H+AdYTwEAADAA4T8f4R9gYwoAAICeCf/5CP8Am1MAAAD0SPjPR/gH2JoCAACA6gn/ANtT
AAAA9MSn/3kI/wCzUQAAAPRA+M9D+AeYnQIAAKAj4R+AGigAAAA6EP7z8ek/wHwUAAAACxL+8xH+
AeanAAAAWIDwn4/wD7AYBQAAwJyE/3yEf4DFKQAAAOYg/Ocj/AN0owAAAJiR8J+P8A/QnQIAAGAG
wn8+wj9APxQAAAAUS/gH6I8CAABgGz79z0P4B+iXAgAAYAvCfx7CP0D/lvt/STqZdPppAKBHwj/h
mItC06wAAADYgPCfj0//AYahAAAAWEP4z0f4BxiOAgAAYBXhPx/hH2BYCgAAgCcI//kI/wDD8xDA
4njyCgDkIPznI/yXxFwUWmYFAAAQnvCfj/APMB4FAAAQmvCfj/APMC4FAAAAoxP+AcanAAAAwvLp
fx7CP0AeCgAAICThPw/hHyAfBQAAEI7wD0BECgAAIBThPx+f/gPkpQAAAMIQ/vMR/gHyUwAAACEI
//kI/wBlUAAAAM0T/vMR/gHKoQAAAJom/Ocj/AOURQEAADRL+M9H+AcojwIAAGiS8J+P8A9QJgUA
AAC9Ef4ByrVc7qYFNQk6bgDokU//8xD+G2AuCk2zAgAAaIrwn4fwD1A+BQAA0AzhHwA2pwAAAJog
/Ofj03+AOigAAIDqCf/5CP8A9VAAAABVE/7zEf4B6qIAAACqJfznI/wD1EcBAABUSfjPR/gHqJMC
AACojvCfj/APUC8FAABQFeE/H+EfoG7LdW9+iyYtDgoAqJzwH4W5KLTMCgAAoBo+/c9D+AdogwIA
AKiC8J+H8A/QDgUAAFA84R8AuvMMAIACzBNufBpHNPOcH/TL9QagLQoAgJF1DTMb/bxJOq3qer6w
ONcVgPYoAABGMmSQWXltE3ZaMuQ5w9ZcSwDapAAAGNDYAWb17zOBp2Zjnzs8xbUDoF0KAIABlBBe
rAqgViWcP1EJ/wBt81cAAHpWWngpbXtgK47XfIR/gPZZAQDQk5KDi9UA1KDkc6h1wj9ADAqA0kxK
2yBgFrUEl+l2mugDq7km8DTmotA0XwEA6KiW8L+itu0lBsdlHsI/QCwKAIAOag0ttW43bXI85iH8
A8SjAABYUO2hpfbtpw2OQwAYjwIAYAGthJZWxkGdHH/5+PQfICYFAMCcWgstrY2HOjju8hH+AeJS
AADModXQ0uq4KJPjLR/hHyA2BQDAjFoPLa2PjzI4zvIR/gFQAADMIEpoiTJO8nB85SP8AzClAADg
aYQ0huC4ykf4B2CFAgBgGxGDS8QxMxzHUz7CPwCrKQAAthA5uEQeO7RA+AdgLQUAAJtSAtCVYygP
4R+AjSgAADYhuDzOfmBRjp08hH8ANqMAAGBbghzzcswAQHmWy9uk6CbRdwBQqGmg88kisxD+83GO
0p25KLTMCgCADQgwG7Nf2I5jJB/hH4DtKAAAmIuAx2YcG/kI/wDMQgEAsIYQsz37COdNOYR/AGal
AABgIUoAVjgW8hH+AZiHhwCWxnNXgIp4MCDCfz7CP4MwF4WmWQEAQCcCYFze+3yEfwAWoQAAoDNB
EMYj/AOwKAUAwCqC7OLsu1i833kI/wB0oQAAoDdCYQze5zyEfwC6UgAA0CvhsG3eXwColwIAgN4J
iW3yvubj038A+qAAAGAQwmJbvJ/5CP8A9EUBAMBghMY2eB/zEf4B6JMCAIBBCY918/7lI/wD0DcF
AACDEyLr5H3LR/gHYAgKAABGIUzWxfuVj/APwFAUAACMRqisg/cpH+EfgCEpAAAYlXAJGxP+ARia
AgBgFRPwcSgByuW9ycO1B4AxKAAAyELQLI/3JA/hH4CxKAAAyEbgLIf3AgDapwAAICvBMz/vQT4+
/QdgTAoAALITQPOx7/MR/gEYmwIAYA2T8jwE0fHZ5/m4zgCQgwIAgGIIpOOxr/MR/gHIZTnXL2Zj
k8nEroECTCfoAlIe0/0uIA3LsZ2PY5vSmYtC26wAAKA4Aupw7Nt8hH8AclMAAFAkQbV/9mk+wj8A
JVAAAGzChD0/gZUWuJYAUAoFAABFUwL0w37MQ/gHoCQKAIAtmLyXQXjtxv7Lw/UDgNIoAAC2YRJf
BiF2MfYbALBCAQBANYTZ+dhf+SgOASiRAgBgBibz5RBqZ2M/5eN6AUCpFAAAMzKpL4dwuzX7Jx/X
CQBKpgAAmIPJfTmE3I3ZL/m4PgBQOgUAwJxM8ssh7D6d/ZGP6wIANVAAACzAZL8cQu/j7Id8XA8A
qIUCAGBBJv3liB5+o48/J9cBAGqiAADowOS/HEIwY3P+A1AbBQBAR0JAOSKWABHHXALnPQA1UgAA
9EAYKEekQBxprCVxvgNQKwUAQE+EgnJECMYRxggA9EsBANAjJUA5Wg7ILY+tdM5xAGqmAADomYBQ
jhaDcotjqoVzG4DaKQBKM0nJP/ug92OA0QkK5WgpMLc0lto4pwnDPKz/eZh9SkEUAAADERjK0UJw
bmEMtXIuA9AKBQDAgASHctQcoGve9to5hwFoiQIAYGACRDlqDNI1bnMrnLsAtEYBADACQaIcNQXq
mra1Nc5ZAFqkACiOp4R48soQxwAlECjKIVizFecqsQ0xD/Ga5reUQgEAMCLBohyllwClb1+rnKMA
tEwBADAyAaMcpYbsUrerdc5NAFqnAADIQNAoR2lhu7TtAQDaoQAAyEQJUI5SQncp2xGR8xGACBQA
ABkJHeXIHb5z//7InIcARKEAAMhM+ChHrhCe6/eSnH8AhKIAACiAEqAcY4fxsX8fT3HeARCNAgCg
EMJIOcYK5WP9HtZzvgEQkQIAoCBCSTmGDudDvz6bc54BEJUCAKAwwkk5hgrpQ70u23N+ARCZAgCg
QEJKOYT1djivAIhOAQBQKGGlHH2WAH2+FrNzPgFAUgAAlExoKUcfwb2P12B+ziMAeJwVAACFE17K
0SXAd/lZAIA+KABKM0nJP/ug92OA6ikByrFIkF/kZ+iHcwfmZB7W/zzMPqUgCgCASggy5Zgn0M/z
f+mXcwYAnk4BAFARgaYcswT7Wf4Pw3CuAMB6CgCAygg25dgq4Av/+ThHAGBjCgCACgk45dgo6Av/
+Tg3AGBzCgCASgk65Vgd+IX/fJwTALA1BQBAxQSeckyDv/Cfj3MBALanAAConOBDdM4BAJiNAgCg
AQIQUTn2AWB2CgCARghCROOYB4D5KAAAGiIQAQCwmWW7pjST0jYIqMy0BPAwOlqn7IKhmItCy6wA
AGiQcETLHN8AsBgFAECjhCRa5LgGgMUpAAAaJizREsczAHSjAABonNBECxzHANCdAgAgAOGJmjl+
AaAfCgCAIIQoauS4BYD+KAAAAhGmqInjFQD6pQAACEaoogaOUwDonwIAICDhipI5PgFgGMvDvCwL
myz8kwBzmYass668YK6fAaBx5qLQNCsAAALzSSulcUwCwHAUAADBCVyUwrEIAMNSAAAgeJGd8A8A
w1MAAPAYAYxcHHsAMA4FAABPEsQYm2MOAMajAADgaQQyxuJYA4BxKQAAWEcwY2iOMQAYnwIAgA0J
aAzFsQUAeSgAANiUoEbfHFMAkI8CAIAtCWz0xbEEAHkpAADYluAGAFA/BQAAM1EC0IXjBwDyUwAA
MDMhjkU4bgCgDAoAAOYizDEPxwsAlGO5nE3hcRM7AijeNNSddeUFxW8neQn/UCNzUWiZFQAALES4
YyuODwAojwIAgIUJeWzEcQEAZVIAANCJsMdqjgcAKJcCAIDOhD6mHAcAUDYPASyN564AlfJgwNiE
f2iEuSg0zQoAAHojBMbkfQeAOigAAOiVMAgAUCYFAAC9UwLE4b0GgHooAAAYhGDYPu8xANRFAQDA
YATEdnlvAaA+CgAABiUotsd7CgB1UgAAMDiBsR3eSwColwIAgFEIjvXzHgJA3RQAAIxGgKyX9w4A
6qcAAGBUgmR9vGcA0AYFAACjEyjr4b0CgHYoAADIQrAsn/cIANqiAAAgGwETAGA8CgAAslIClMn7
AgDtUQAAkJ2wWRbvBwC0SQEAQBGEzjJ4HwCgXQoAAIohfOZl/wNA2xQAABRFCM3DfgeA9ikAACiO
MDou+xsAYlAAAFAkoXQc9jMAxLEcZ6iVmEwq2VCA4U3D6VlXXjD8LwpK+AfWMReFplkBAEDRhNRh
2K8AEI8CAIDiCav9sj8BICYFAABVEFoBALpRAABQDSVAd/YhAMSlAACgKgLs4uw7AIhNAQBAdQTZ
+dlnAIACAIAqCbSzs68AgCkFAADVEmy3Zx8BACsUAABUTcDdnH0DAKymAACgeoLuevYJALCWAgCA
Jgi8T7EvAICNKAAAaIbgm+wDAGBTCgAAmhK5BIg8dgBgewoAAJojCAMArKcAAKBJ0UqAaOMFAOan
AACgWVFCcZRxAgDdKAAAaFrr4bj18QEA/VEAANC8VkNyq+MCAIahAAAghNbCcmvjAQCGtzz8r2Au
k7n+NwBzmIbms668YI6fKJPwDwzGXBSaZgUAAKHUHp5r334AIB8FAADh1Bqia91uAKAMCgAAQqot
TNe2vQBAeRQAAIRVS6iuZTsBgLJ5CCAAoa2E6xIfDij4AwB9UgAUZuLRqwBZlPYXAoR/IAdzUWib
AgAAnlDCagDBHwAYigIAANZYHcLH+GqA0A8AjEEBAABbGHJVgOAPAIxJAQAAM9gorM+zOkDYBwBy
UwAAwIKEegCgJjtq2lgAAABgMQoAAAAACEABAAAAAAEoAAAAACAABQAAAAAEoAAAAACAABQAAAAA
EIACAAAAAAJQAAAAAEAAywHGWJdJXZsLAEBDzEWhaVYAAAAAQAAKAAAAAAhAAQAAAAABKAAAAAAg
AAUAAAAABKAAAAAAgAAUAAAAABCAAgAAAAACUAAAAABAAMsBxliZSWXbCwBAO8xFoWVWAAAAAEAA
CgAAAAAIQAEAAAAAASgAAAAAIAAFAAAAAASgAAAAAIAAFAAAAAAQgAIAAAAAAlAAAAAAQADLAcZY
l0ldmwsAQEPMRaFpVgAAAABAAAoAAAAACEABAAAAAAEoAAAAACAABQAAAAAEoAAAAACAABQAAAAA
EIACAAAAAAJQAAAAAEAACgAAAAAIQAEAAAAAASgAAAAAIAAFAAAAAASgAAAAAIAAFAAAAAAQwHKA
MVZmUtn2AgDQDnNRaJkVABDAnl/4uwCjBAC6MF+A9ikAAAAAIAAFAAAAAASgAAAAAIAAPASwNJ67
AgBADuah0DwrAAAAACAABQAEsecCfwkAANiYeQLEoAAAAACAABQAAAAAEIACAAAAAAJQAEAgvt8H
AKxlfgBxKAAAAAAgAAUAAAAABKAAgGAs8wMAVpgXQCwKAAAAAAhAAQAAAAABKAAgIMv9AADzAYhH
AQAAAAABKAAAAAAgAAUABGXZHwDEZR4AMSkAAAAAIAAFAASm/QeAeNz/IS4FAAAAAASgAIDgfAoA
AHG470Nsy7GHX6DJpMCNAgCgCeaaEJoVAEDa8/M32QsA0Dj3e0ABAAAAAAEoAIDH+FQAANrlPg9M
KQCAJ5kcAEB73N+BFQoAAAAACEABADyNTwkAoB3u68BqCgBgHZMFAKif+zmwlgIAAAAAAlAAABvy
qQEA1Mt9HNiIAgDYlMkDANTH/RvYjAIA2JJJBADUw30b2IoCAAAAAAJQAADb8mkCAJTP/RrYjgIA
mIlJBQCUy30amIUCAJiZyQUAlMf9GZiVAgCYi0kGAJTDfRmYhwIAmJvJBgDk534MzEsBACzEpAMA
8nEfBhahAAAWZvIBAONz/wUWpQAAOjEJAYDxuO8CXSx3+WEGMBngNWFge86/Kd39uRcM/FsAILbp
/RagCwUA0IuVSYkiAAD6JfgDffEVAKBXJikA0B/3VaBPCgCgdyYrANCd+ynQN18BAAbhKwEAsBjB
HxiKAqA4ngJIW/ac/7fp7s/9WFuDAoCBTO+bAENRAACDW5nMKAIAYGOCPzAGzwAARmNyAwDruT8C
Y7ECABiV1QAA8DjBHxibAgDIQhEAQFSCP5CLAgDIShEAQBSCP5CbAgAogiIAgFYJ/kApFABAUVZP
kvzVAABqJfQDJVIAAMVSBgBQE6EfKJ0CAKiCMgCAEgn9QE2WatrYKE5+3TcnUcYKffBVAQDGIvDD
fO7543NkzoJYAQBUb7PJmGIAgEUJ+kCLFABAs0zeAADgKTvsDAAAAGifAgAAAAAC8BWAEnkEIAAA
AD2zAgAAAAACUAAAAABAAAoAAAAACEABAAAAAAEoAAp0z+fPWSpwswAAAGYm15RHAQAAAAABKAAA
AAAgAAUAAAAABKAAAAAAgAAUAAAAABDAcoAxVmmSJlVuNwAAAGWyAqBQxz//Qn8KEAAAqJI8UyYF
AAAAAASgAAAAAIAAFAAAAAAQgAIAAAAAAlAAFMyDMwAAgNrIMeVSAAAAAEAACgAAAAAIQAEAAAAA
ASwHGGPdJnVvPgAAAGWwAqBwx6974VLhmwgAAPAY+aVsCgAAAAAIQAEAAAAAASgAAAAAIAAFQAV8
jwYAACid3FI+BQAAAAAEoAAAAACAABQAAAAAEIACoBK+TwMAAJRKXqmDAgAAAAACUAAAAABAAAoA
AAAACEABUBHfqwEAAEojp9RDAQAAAAABLAcYY2MmjY0HAACAMVgBUJnj171oqbJNBgAAGiWf1EUB
AAAAAAEoAAAAACAABUCFLLMBAAByk0vq4yGAtfIsQAAAAOZgBQAAAAAEoACo1PE/8dcAAACAPOSR
OikAAAAAIAAFAAAAAASgAKiYZTcAAMDY5JB6+SsAABTnzj8+J+3csTTodl1+9a3ptz53eNDfsZUf
XHNOOmFXv2N8zydvSR+/4WjvYxrq/fjEnx1N7/7ELb1v7zzOPnBC+ubHfnSeH5nZUO8HACzKCoDK
ad8AFvOu1z47PWuPHhwA5iF/1E0BAEBIe3bvTL/2utNDjh0AiEkBAEBYb33Faek5p+0KO34AIBYF
QAMswwFYzIm7ltLFr9+/2A8DQDByR/0UAACE9sZ/vi/9w+ecGHofAAAxKAAaoY0DWMz0rw1c8kar
AABgK/JGGxQAAIR33k+ekl7y/N3h9wMA0DYFAACklC5/0wH7AQBomgKgIZblACzuZ15wcnr5i/cs
/gIA0Cg5ox0KAAB4wqUXHkhLS3YHANAmBUBjtHMAi3vh2T+Uzv/pvYu/AAA0Rr5oiwIAAFZ57y8e
SLt2WgYAALRHAdAgLR3A4n5k/zPSL//sqYu/AAA0Qq5ojwIAANb49QvOSCed6BYJALRlua3hsGLa
1p30mr+Z2CMA8ztj73K66FWnpd+69vD8P5zVJKVJRZf+6abm3t5Bf39l7wfAKse/8GLfh2uQjzcA
YAPvfO3pad/JO+0bAKAZCoCGae0AFvfM3TvTv/n5MxZ/AQColBzRLgUAAGzirf/ytPSc03bZPwBA
ExQAjdPeASzuxGfsSBe//sDiLwAAlZEf2qYAAIAtvPGl+9Lzn3OifQQAVE8BEIAWD2BxO3cspUsv
tAoAgPbJDe1TAADANs77yVPSS56/e7v/BgBQNAVAENo8gG4u/6Uzu70AABRMXohBAQAAM/iZF5yc
/sWL98zwPwEAyqQACESrB9DNZW86My0tdXsNACiNnBCHAgAAZvTCs38ove6n9834vwEAyqIACEa7
B0T1vSMP9jL09/7i/rRrp2UAALRBPohFARCQkxyI6OM3HE1H73q489DPPnBCevPLT+38OgCQm1wQ
jwIAgBDuue/R9KFrD/cy1t/4hTPS7hPcQgGAupi9BKXtAyL6T18+mr7bw1cBzti3K1306mdH3IUA
NEIeiEkBAEAYDzw0Se//zK29jPddP3d62nfyzl5eCwBgDAqAwLR+QESf+c+3p2999/7OQ3/m7p3p
184/o/PrAMDY5IC4luMOnanpyX/Sa/5mYm8AUTw6SemyTx1Kn734RzoP+VdecVr62PVH0i0/eKjz
a0X01lec9tg/AMYj/MdmBQAA4Xzpr+5MX//7453HfeIzdqSL37C/8+sAAIzBCgAeXwVwnlUAQOOm
a51WrXf6zasOpr/4wPM6D/rClz4rfeS6I+n/fL/71wo6WzNGMvN+AIU5/qcvXipskxiZFQA8xsUA
iOa/f+t4+vJf39V52Dt3LKVLLzzQ+XUAYEjm+0wpAAAI69I/PPTYMwG6Ou8fn5J+4nm7u74MAMCg
FAA8SSsIRHPTzfela792Ry/DvvzNZ/byOgDQN/N8VigAeBoXByCa9119KD34cPdlAP/0x05OL3vx
nmi7D4DCmd+zmocAsoHuE2GA8mz8RLabDz+Qfu/Pj6ZfeeWzO2/yZW86kL76v+5Kk6yX0ay/nHW8
HwCUwwoA1jn+pz/u6aBAKB/87K3p+P2Pdh7zi567O/3cP9nX+XUAoA/m9aylAGBDLhZAJEfufDh9
9Au39TLkSy48kJZ36lEByMt8no0oANiUiwYQyYevO5x+cNfDnYd89oET0i+//NTOrwMAizKPZzMK
AABIKd1z36PpQ9ce7mVf/Prr96fdJ7jFAgBlMTthS9pDIJJP/tmR9N3bHuw85P37dqVffXX3hwoC
wLzM39mKAoBtuYgAUTzw0CT92z861Mtw3/26M9K+k3f28loAMAvzdrajAGAmLiZAFJ/+6u3p7797
f+fhPnP3zvSe8/d3fh0AmIX5OrNQAADAKo9OUrrsUwd72Sf/6pWnpTNP3dXLawEAdKUAYGZaRSCK
L37jzvSNbx/vPNwTn7EjXfyGA51fBwC2Yp7OrJZn/Y8wNb24nHTe/5zYG0DrfvMPDqavfOB5nYf5
ppc9K33kusPp/97yQOfXas0nbjiS3v3x72cd1vTPNn7zP/6jrNsA0IXwzzysAGBuLjJABP/tW/ek
P7/xrs5D3bljKV164ZmdXwcA1jIvZ14KABbiYgNEcMlVB9OkhzVPr/mpvenc5+2OsMsAGIn5OItQ
AADAJm66+b50zdfu6GX/XP5LVgEAAHkpAFiY1hGI4H1XH0wPPdJ9GcA/O2dPeumL9kTYZQAMzDyc
RSkA6MTFB2jdzYcfTFd++Wgvw5yuAlha6uWlAAjK/Jsu/BUAOnvsLwO82l8GACqw4Af5H/yjW9OF
Lzs1nXRit978Rc/dnV77U/vS5/+yn68VrDMd34JjzKKE7R1yf5UwPqApx6//cTUynXSbycATXIyA
lh258+H00S/c1ssQL7nwQFreaf4GwHzMt+mDAoDeuCgBLfvIdbelH9z1cOchPvfME9KbX35q59cB
IA7zbPqiAKBXLk5Aq+6+95H0oWsP9zK833jD/rTDHRiAGZhf0yfTD3rnIgW06pM3HEnfO/Jg5+Ht
37cr7fI1AAC2YV5N3xQAADCjBx6apPd/+tCM/xsAoCwKAAahrQRa9emv3p6+/b37Wx0eAIUwn2YI
CgAG46IFtOjRSUqX/eHBFocGQCHMoxmKAoBBuXgBLbr+63emb3z7eItDAyAz82eGpABgcC5iQIve
+wdWAQDQL/NmhrY89C+AqenF7KRX3zixN4B8ppeg/i5D//Xv7k5fufGu9LPnPjPfkNbpd4zj6O89
WcyQv7/G9wPI5fj15y7l+t3EYQUAo3FRA1pzyVW3pMmQ+RGAEMyTGYsCgFG5uAEt+dvv3Jeu/drt
LQ0JgJGZHzMmBQCjc5EDWvK+qw+lhx6xDACA+ZkXMzYFAFlML3YueEALvnPrA+n3vny0haEAMBJz
YXJRAJCVEgBowQc/e2s6fv+jLQwFgIGZ/5KTAoDsXASB2t127KF0xRduq30YAAzMvJfcFAAUwcUQ
qN2Hrzucbr/74dqHAcBAzHcpgQKAYrgoAjW7+95H0oeuvbXmIQAwEPNcSqEAoCgujkDNPvGlI+n7
Rx+seQgA9Mz8lpIsl7QxMDW9SJ70qhv9TS2gX9OrysBXlgcenKT3X30o/e47/kG/2z6PgcfYu9zb
O/TvH/r1gaId/+K5S0VvIOFYAUCRphdLF0ygRp/+6u3p29+7v8ZNB6An5rKUSgFA0ZQAQG0eeXSS
LrvqYG2bDUBPzF8pmQKA4rmIArW5/uvH0l/97+O1bTYAHZm3UjoFAFVwMQVq897fv6W2TQagA/NV
auAhgFRj5aLqAYFADf7ypnvSX9x4V3r5uc+sYXMBWJDgT02sAKA6LrJALS656pY08RR4gGaZl1Ib
BQBVcrEFavDN/3df+tx/uaOGTQVgTuaj1EgBQLX8eRWgBpd/6mB66GHLAABaYQ5KzRQAVE/7CpTs
O4ceSL//laMlbyIAMzLvpHYKAJrgYgyU7AOfuTUdv//RkjcRgG2Yb9KCpRYGAav5KwEAAPRF8Kcl
VgDQHBdpAAD6YF5Ja6wAoGlWAwAAMC/Bn1ZZAUDTXLwBAJiH+SMtswKAMKwGAABgM4I/ESgACGX3
q/7aH+MGAOBp7v3iT8hFhOBAJyRFAAAAgj/RKAAITREAABCP4E9UHgJIaC7+AACxmP8RmRUA8ASr
AQAA2iX4Q1IAwFq7X+lBgQAArbj3Sx7wByusAIBNKAIAAOol+MN6CgDYhiIAAKAegj9sTgEAM1IE
AACUS/CH7SkAYE6KAACAcgj+MDsFACxIEQAAkI/gD/NTAEBHigAAgPEI/rA4BQD0RBEAADAcwR+6
UwDAAJQBAADdCf3QLwUADEgRAAAwP8EfhqEAgJEoAwAANif0w/AUADAyRQAAwFMEfxiPAgAyUgYA
ABEJ/ZCHAgAKoQwAAFom9EN+CgAokDIAAGiB0A9lUQBA4ZQBAEBNhH4olwIAKqMQAABKIvBDPRQA
UDmFAAAwJoEf6qUAgMYoBACAPgn80A4FAASgFAAAZiHsQ9sUABDU7lf8j0nQoQMAKaV7b3iJLADB
OOmBdZQDANAGIR9YTQEALExRAAB5CPYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAABAz/4/7GmFrEEBdicAAAAASUVORK5CYIJpYzExAAAGS4lQTkcNChoK
AAAADUlIRFIAAAAgAAAAIAgGAAAAc3p69AAABgpJREFUeF6tV2tsFUUU/mZ2995L36VIAxhfoCCG
SJQfKhGKCPIIMYYUJKBEf9REI2pExEes/UNMbFSMBpVoDAZBamJQMUKsLQKRH2KKUAgKBRJryqOU
2vb2PnbnmDO7e+/utqU8PM20tzcz55z5vu+cmRG4LCNxWdMGmKCrW8dWTYYe12rsY9vQfgbZmb/b
YPb/FwLsJ4xKJIH8hPKXLi4FsBRKTSClLBcIdZlUSA29kDILwzgBRQ1d9WVfuj7CSeQdkrvL8rVd
JciKzYgXLYSyoQeugUppgQele3YpEsv+fbe0S7sTLhL5BGpJ8helXR07ZGHlPOo7kyVAGkLoOVea
gl4kAKWIlypRONqivnNNF8uPzgWqFOqE4ik6qBZJnVClnR2LZWLkPOrtyIJgGRBGb0pJHpksXdHQ
6/qVlBAG+6LesxmRGDmr7MLEZTp4bZPJofUvNHhSJ3oMdlZBMX2E3pTCjNvieHl+EcoLJRiL4UTA
2+U9dycV6nf2ovFoGkVxwUgYsNOKlFgB4AscOZejgH0Si6P06fbDwhwxGXa/shUkBz1YV6mDX431
pAh31p7B2W4HliEUzLikbOp49+hxE10KSIQ9ExmcvgChP024dbSpg9sOoGj44SjKjawDFCcEJlYa
6M8QJAikCMQxfOpzFPjmKEAqVo6uVuUoDachWbSXxoBAkIFJHIXXKocgiH2yA9d30KIIuKv8oWjY
wLo7aNQEejJJVO94A0811iNlZ921PnS+z4i5Isxp0IWJQdBwBYqPgyhSMGW4O5OuMiCjbNQ0vo3t
bXtxS8lYpOw0EqYFIgVSPDQJIEY5YKEE4DA7QbLzMxleKSLBQVAgGEJiVdN67Di5H2MKR+Hj2atR
lijS2tbM+SjwhvhzwCIUsNr09vPDQ+FI5ylsOrozt9RHhIO/uu8TbDn2EwqsON6b+SxmXj8VtuZa
eHRGfeYtjEBI6rzIzZa5fOGXD7Dr1H60nDuOd2Y8k6Oj/sBWbDi0HZY0se6+Gjwy/n7YysmjFfSp
q/0SCPCumNPg8G35pDmoLKzAp63f47nm9VoLn7X+gLd+26ynrJ22HE/esUAHD+ok6s/XjG9hBHTd
RDUg4JDC47c/BIccrNnzEbb82Yi/+87j8Pk2pOwMVk1djNV3PzoguDZ9EvjcE+CEERhIgVsC7uC6
1V1DaudPTF6g/1+zZwP2/XMI/XYaKybNwbrpNTpJQw7SMXP8czK+3yE1wI0igoJnDKufBCf04p4P
sfCme/H+rOc1dVJ3gkG6VVQDkSoY0Ad4gu4BPFHrIZCtNLT4Vk6eh+ljp+CG4krEpKl59U7tkOne
wz9ef/E/By2iAU/5nhaU1wntEG8CNilMKBunKzbLrTZHdt7YhWUKcGXrXQc7bPNQFHAgoXS3KogB
h9v6ceh0ClNuTIS35oVkyhn6oexYexotJ5IosNxzRWvqkp2QyGGhcOs0pEAypfBw3UnUzK/AqBLu
giJ/J/B6TNRcyggXehxs/LETPX02EjGp0dRdlmNUQWG3u5IpIFRvM9AgHKiWk4A1iSilHIdkzATa
OzN4ZWO7u2l9lwNga3IBM5KFfxp6c2MjJOKmgMO7Jr50moqITrk3IpL819XA2es8HNVmQC6EUg47
493EDGBEsVte7J/P9k2v34SfW3oRMwUqSgzsbe3D3LuKsW5rR0i0zKjeuQaF1WDG4JB7O25uZqeB
azZndKRBFKQn7JTxitmUOp/li3W0tvjSsf3N8SgtNHGwLYmCuETMEqgsszD/tb8gZfSmr/uvIxIV
MZW+sDfZrh7Age8coE53hnwV1PHEajLn/rrEpu6vpFX2ICgLilzL4zGBpj8yyNgp3DwmjrbTGexr
7cWie8pgmrFImQsIaQKGZVC6e7fMoBoHptlArU/o0A+TgkW/ryQYS4RyxgPew8R7O3DNp7JKU6Bp
97Xh9wzvzg8hsyTMNiHU18lvv/kcqNP3wODraIinWeD5xNQ087EdKF4AM6uqsLs5/F3YqqDV7t3/
PSEMeJoNZUI/Kr3HyjUZ+3AfuYM2jOGu+Vr8V/4u8m34R9V/ADmktm3i//IAAAAASUVORK5CYIJp
YzEyAAANFIlQTkcNChoKAAAADUlIRFIAAABAAAAAQAgGAAAAqmlx3gAADNNJREFUeF7tWw2MVNUV
/u59M29m9pfdRQqiQgkWBLVUmgqKoEjRNNEYW4jV0hqiEW3xB61JbZWImiZWowgaqqZabTEFtUqx
UlvkR6ym0QpaEakiCMrys+zv/L97b3POm4HZmffezA4sJS3f5mZmdt6775xzz3fOuT8DHMdxHMf/
M0R1yhuBGZAYA4HNMBgDU10/h4nNEAdlWA4NiP6WwwgsM9Zhit1/YNlMnwa18ovnG4m7hWbp526N
NEcGnWeEmGSMHi2MGgijK+/rSEBIAyPaIUNbAPNmtCu+fvfjQxPcdaGsZVCZ0DOMheVCYca/7OZh
J99gYK4Xlv01WDZgNGBUuef0D4QEhAWoLIzKbAPME3br9kV7fjcuflDmwzZATvmmH7eeYWKxp6Rd
O95k4jBOiryBeEfUq8yQRxqGOE+0N1KEohJ2HUwm/qFOJWZ3LR7yD6bETBE4OsGC55Rv/MnOqTLa
+CKk1WjS3Q7I9ILMfwzBsCtqYdeGjDFJZLuu6Fh40opynuBvgByPmm7ePdbI2FtCoN5kUw6ECB1D
apfCaAXLtiCsjM4kz2NPCIgJPqOYc+m5JqKNXCpkqN5kkjnl2eWO3SakBZVRQkhbSvlcy+x99a6V
vGnqbYD5ay2K+ANM63Uy2nSmSXW5yps85XrrT0y0BBA6So2exRnfs9E/hUVUFbHmEaouO4+zF+nk
AS8KCOp55FzY+82XWxCKDYOTMn6clwLQBuhMGhh+eP9DCKAhKmFJ99k+0JBhAZ3ZJ2GfemDRwC7X
C3oXS6V8nmEkpbx9atckGakfbjI9GkJKHv0iSCGQyhqEJPCjiTGce6qNWFiwgP0BEiHtGLy9LYMX
3kkhmTGI2QLa0wpCQqWViDQOUumuaQBexDJIzESvrFBqACpvCUJMgQwbGEp1poQqpGQ6qzGwTmLp
dc04d6TdHzp7YvakGsyZksUVSw7gi3aFKA10yfgwXQ0gSYPz2QAflnp8aQyg2t6l12lGK0HlFvVT
/EdXZJXBE1c3sfJZBTj66LSMAs4aFsYz1zaxgbTxkpAlF0Y7AgKjcpZ0K9kCeHmAa0tjmrnKy1mj
EMT77qTBOSNtTB8bgdJA+CjPEMjYE0bYuGC0jVUfpNAYk1AlXkABSlFrZvnvLp20+RczHGHJjUqb
hIHjaIwZEjoYiP8bINFOHxqGcgwEu7xPC4B/UaOJ+rkOi5EzDsWBfop3FcF9fqHSHrflU7cP/A1Q
mGO9DOBBjf6AZhqSmTm/c+bphbzSeXk9B8tfsuCyllOfz91B3x0hUHCTB6ccruKuGYoQKEuADkCQ
AQpcy4cCXrXBkYIyCpawsG7XRjz83nLU2TX4xbdmYVTTKWyYQ2aogAJE5yNOgQC3Olw4WiEkLWz4
8n18/9UFyOoskk4GO7paseqyXyEWjsBw4ueitXfrIwV8s4DRmktbv1YuuFQLZTQr/8H+bbj6tV8y
5wdE6jC4tgWfdn6BPcl2UGLnGidPUK4DSCRveXXAaFU/p+8HDyDlLSF5pK9adQ/i2RQiVpgf1Zbs
xMQhp+OkuhPc2FBp/ikjZ0AWqCAGBPTuGawCQNGelN+f7MCVqxagNXEA9eEY39GVSWBMy3A8dsEt
CEualBZoVZz7vQJkwCQt2AP8CovCIqk4INPkwWgeH3rNu2qw8jTZFDzis/5yH7Yc+BwNdg3fknDS
GFzTjN9ffCcG1TS5ffdKhQEFUF5+/xhYrhKsYN2jCMRPSl0ZleXXQr56IcdeKK1xzd/ux9u7N6Mp
Ws+KplUWteEoKz+8YTBT5FBazKESGQNoEOABlfR8SIr8dCThpDBv/WJM+MMcXP/6g+jJJtkIbkHT
G663uLn+pnWP4M/b30JLrIGNQY2+f3r6z3DGwBGcGYgi3igja1UUKCyFfWvsQ6Z13V7g0U0vYfHG
F9GW6sKzH72GH6y6F/FskpUsNgIpSUrd+daTfO0JsQH8v7zrL5l6GyadeObBtOirvC9V86W8PwfK
TIb6ToGP2z9HvV2LiAxjSG0LFzJuRO9thHyuf+i95Xhk4wsYVEPKK+Z3R7oHD06+AZeMOKeM8nn5
vJfqKpmpBVKgXB3Q27PcAvWqUdM4d2e0A8codul1uzb1MkJGOZzrn/loFRa8/TRaoo2svCUttKU6
cdeEq/HD0y4ur3zeANq/Xsnr4IfD84ACkCuTi19w8ln49YW3cfQmflPgOmSEezml2VYIL2/bgFvX
P8ZFDglJyu9NdODGcd/FLd+YUZnylQbCqrLAQfOW48EhEM+phr985GQsmXorkkVGWLPzn5iz+gH8
6bO/Y+6ahYiF3GU0S0rsS3Zg1mnTcc/Ea9yCSFZao5WTr9rJENXaZdYDvKIrTWCI32QEwpzXH0Qs
FOFdtJZYI9bueg+rd76LaMiGhMWKtiW78J3hE7Fwyo3sRUQh+qsIhTWJV7Tvt/WAgNRC/PYyAq3n
R0J2rkgit5doT3VjwpAxeHLa7fyZuq1YeS8KFCPYAYKmwwErQhx8cpHXB/5GoJqAltItjgejm0/B
sxf9nAsed/Qrdf0cKimFAyqhgAWR6ihQCC8jRC2bud+ZjnOJu/TiuzCQ8n9uLtB3FJXCJR5A31db
B5SbSlWAQiMsmTqPgyRNdJqjDVziDsuVuP5VXv/C1wPYaLn5tZdR3Tl4ZXNiMgKN8OUjp2BM83Bs
2v8pJg/9OhdK+VlgtXBXww7VAZ7CBuyflVkT9FkSLMw8FSJfJ4xuHsaN0HvNrzocXA4sJ6tfrPJ9
bAXrATQrDUgGJcjPB0hxMkjJCm8fQTpLPiQSFK98lvZzCPAA5oCnC7hKG3TFqXbv2+E0MgLtLB0J
UDddiZycvivDwTStqhSm3dhIROLNzXHEU+4CBW2PHS3Qs+iZjjJY+34PwvkdYs+isFoDUODIt6Jc
Syuy0ZDAjtY07nimlUeU9urZLypYoDmcawj0LGoLntuDj3YkUWNLd4u8uOOgarY8BQqLnVIrKmXQ
UGth0Yp9SKYUbv/eIIw8MdJvZwMKsX1PBg+9tA+PrtyP+hoLys/96DwEGaVP+wJ0/NRlfjsfBGMX
8iatVgb1MYknXm3D8xs6cerQCCLh/PGCI0uIvCdnHINPvkyjrdNBfZ3lLpD6eTnfRGcJRQdLMx+i
eIe4NAjuXeuKrvTHJiyMcXcffbUh4zfUWUg7Gu/8O+6bcokmxFvey6czRdJ9T6BsQC5Mn+j/PGg+
3KWgGw1LfqYKyO8Mkl1Yxhi9lT+vXUtE7RWtSg0w6Hw3xkusFyp7B7SWfCIzAEQHuqI2QtYuupAm
NwJIZQwyjkZNRCJkCXQlFGIRd3U/kdaoi1qgGXB3kjZGgLpo7lSOR39kG3pmWdDwaS2gsN7v2lLN
+NS1EYmM84bJdO+CtGlIaJsoMMKRK9IoEi0KG8kf71GYPb0ZL981Aie1hPm6FfNHYPzIGow9Jcrv
vzIghHRK4zc3n4ybLjsB8R7HnTUW9ceeUlEU1TT6Umc6D4Qc+RobYN35JadGPYZWGExZa2HlNxMG
YrEI1Qp3n6y6EE9eqLIa40bEcOmERtx55WA4jsElZzdiaHOIFaf3qbRCujXN15w7phYqTYuswUb3
HxSWVYlwvRAGj3e+cmY7pqwJeVUs3r5NlppvZCIhFutU+1ZYNSFo5Vqv0gWYXtfR0jfw+d4MJo2t
w0Xj69EZVzyaFNSIy7/96TD8ceEo2GHJAY4lq+ZZLKNWkJGQSXd8EXKs+zF/vvQafY4/3tzInaX7
67g4pL4S2klDhi1oOnBThVSajrNJfNaaxqKX9+L+a4a6YZUXP1wub/k8hY2fJJB1yFi5Xd+qnkVL
y7SyAi2UvopHf/NY33rVP7rR6coZy6zES+Pf1dnumRBWClbMgjZZroQq4mEugWgDOyTw1cERLH6+
lQPhgFoLWUfDtgRH/vuW7sbdD+9gbxhQR0fgKRT1iXYUhBzIiAWENZyeWT0rz1rnHpae6XtiPDi8
041T1oSSr0xcoZyeqVDqY2EPCEPwwTxFZ6X4VcO3GW2UZQm16dOEenNzj3ISSt22ZKd644Nutbcj
q9q6HH5fF5MqMiis1m/qVhs/SfA9dG9Q371kgCWE3UQ7p9uhu6fHV569lHlPv3MIQGXlSu7YfMul
G+qTaJgHY64VVmQop0diRcC6c76MSmfdLFETtZDKaK7jo7Zrf/pMKZHiRDKtIaXggsq/BMtDApJ+
JWOgneQeKcRTMrH3ge7V324rd0w+j8oMQCg4ct407Z3GVCxyoTBqsoEeJbRpBnSgN/GskY7taXC+
J/b3KoRydKHvysxgc6AiTVK1ulUI+YZMJFd3rz67jb+csSzQ7Q8D9GuxY/hHUyzbUfn1Ss4QxDHy
DHfWcfQbPZtkOHqKH8dxHMf/GP4D93R2rL84ctQAAAAASUVORK5CYIJpYzEzAAAq/IlQTkcNChoK
AAAADUlIRFIAAAEAAAABAAgGAAAAXHKoZgAAKrtJREFUeF7tnQmUXFW19//n3Ftzj+mMEGaBR4Cg
EEBUZHJ4gMOnEkDU9x4uvogoICgLh/WZtM/xgcggDuCSp4JgWhEZBCRIwqAEDZAQIkOYyUCGnqu6
hnvv+dY+t26n0unudNJ1b92qu3+ssk13Vd3pnP/ZZ5+99wEYhmEYhmEYhmEYhmEYhmEYhmEYhmEY
hmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhgkGEcxh6gkloAB9Z+gn
0xh4z1MIfqoVRFQAlMBCCBwKgWchsAYKc8rdvVM4jdHimdEpP/s1EJhD7X8psGazQtd8B4ieOERE
AJTA/C6JOfPdzt4l7LG6R/vl3a2OkBJDSqHYH5H7EwHiLQqpNtH3fdEz5tUuVBKAdNsIIiEIjd3A
5y82MGeaQOdJVuVDn7VQpQtDA/sAxiFwSocrp7QPZHxfOEUJIQ4FYECxpdhwCAMK9otCGFk4do8w
U6sA+3VhF1dblvli3zXtvdtd82JloAtoZDFoPAFQSqALEmdWKPhiZXQ8mTtSWcV3K6XeC4ijAHtP
EW82IE3AsQHlGgXKKvDkv4ERRgIQAhAS+tkrG6qYowe/BQqrBPCwEIlHIPP/2HrFtIHhW0Fi8CxU
o00RG0cAhjv+NvO+/dK+dylDfUw46nQhjUMQSwHKgbLygF2kjm5D0dyfGoRy74WC3OYwauCeEDU8
xy7Ix1O27vSzh4CAhIwJYSYBGdNtw7GLbwrgASXEHb35t+7HdQfRyADMV4b2FzWIr6j+mzh1/EVL
Dc/Mz1y0cUY8mf6Icpz/kkK8C7EMYA1BlYboYdMwT72dHjpde/1fP1MdlFIQcMqiIGHGpTDT7oBh
F54TQtwmLPxu61UtzzWSENR3ByCzrDzi646fSH0ewPkilp4BuwRVHPQ6Pc3tycHDMBND0RSSXo4U
sZSEmYIqZQtQ+C2UfVXPDztW6y/SbbB+HYb1KQDkrV0ERWu6mS9vmB5H+gIInC/imRmqOEAmnO2O
8tzpmSqgFE0bFIRhiGQrVDFL88dbthMCmhqMs7oUVupPACpu9JRLez6rhPhvkWjeQxX6AbtE3n4D
grw8DFN1FJTjQEhDJNtcIRDG/6B/05U9NxzQV4/WQB11FFrLhySVbb70zYMM2XytjGU+SCO+sovc
8ZkgKQuBYcjUFDjFgRccp3BR/1Uz7tcnQRZqnTgJ60MAKm5o66Vbz5NG4kpIo1UV+i1AGRCyPq6D
aTCUglK2iKVNWlZUVuHq3hWrLsOyk6x6mRKEv+OUTf4pFz7e4iQO+aEwk+ep4iDglGwyxRqsRTH1
iPYRACLdIVVh8DG7NHDuwLV7vVgPIhBuz/hCZWqT/6I3DnQSBy8R8abzVL7HhmMp7vxMaCBnsxBS
5bZYwky824g1Pd5y8boPaqcgteEQE14LgG5cp7BaLlp/tIw33SekMUUVBiwICt9imJCiHBtG3BBm
Ck5hYEHfNdNvdC2BcC4VhtMCoBtGnf/CDWfKWNP9Aoo6vw1hcOdnwg1NS+2So4pZR8ZSN7RdumWh
awnQYFuONg0R4ROAstnfevG6/2uk238HVWpXpSG99KLjMjhJnwk1FFlO8SeWUFbOlqmORW1feusG
vSqwEEbYRCBcU4Cy2d964RtnyPS0LlUcsODYHMXH1Ck656Ao0jPianDj1b3XzrrEa+NhuaDwCEDZ
26/n/LHM/VB2q07Y4Wg+pq6hvHKplwqdYt+Cvmv2vDFMIhAOASiv87d+ccN+Mp5aAaBdWdrsD98U
hWF2GR1G7FD6uTO0eX7fdXv9PiwiEAIBcCP8Zuy9MVlw4kuFkZiniuTw4zV+poGgWAEZgzBifcjn
Tui5fuYzYYgYrP0IS46RLmEXiuo6kWilzk9LfRzgwzQWNJV1igrSaEfMvGXGlzdkdF3CGq8M1FYA
yst9rRdtOFekO86lQApe52caFiENHb6eaD2cBjy9PEj5LTWkdlOA8ry/5cK3DpCx+EooJ6lr8ul6
TQzTwChliVS7aee2nNV/3ezFtQwZrl1nK5dWauve+BeRaDlFFftsgE1/JgqQPyBB9Ua2FIsDR+Sm
7bsJnXTdwZekr435UV7ya+vZ8BmRmnKKm9XHnZ+JCkLCztOqwPSYkfy+DhJaXJvBuAYWAG3MsEg0
b7m03TCLqyGM6XCowEqNxIhhaoctzJRQpezJvdftsawWU4HgLYDFkOjsdKQcvFAkW2fCLlB8b/Dn
wTA1h2KETGr7i/SpeLtTBUjAFoC7717zF/unGGbheQg5BU6J5j4BnwfDhAaKEjQcK3tS3zWzlgZt
BQSbXUejvxC2vHDdhSLe0aGGtpYDfngXHiaqlLcmsJ2FoI0KA7YCAhx53VTIpgXrO8yk+RyP/gxT
RilHxDPSsXOBWwHBzb11KqRQRtz4mEi0dMAu0uaLAQoQw4QWHSYMRy3QZzg/uPMMrgO6O6+ibev6
x0W8aZ4qZUkAOOSXYdxkIap1kS3K/EG5q/fd4IYI+79deTA+ADfk126+eMOxwkwdpYo52tSjLjs/
1R/We0sGJ53MBKCkW5pN659151ISAo5N0YFNsbzzKQBXaou5E77XDQhGAOa4loZh4wwk0xJW3oKi
QooTeLK1pLyhJHV6elk2kCsqlGzAdsotjqk99HykAC2oJWMCMWrViizqshjURzsTtJ2dUOoMQP3Q
3ZbMfwK6NUrgwhfjbXbTKsRTB0GX+Ar/tl2GdBvQQJ46vUJbWuLAGSb2bDdw1N4xxKjAE+8wWlO8
wf7Z9RZe32rj+Y0WNlE2OYDmpNTPyAqkK00W3ZIUpFmynOIRgz/e8zmAps3+hgf7bwF4ST/O+sNF
LPE2ZWnzn7rWZO+Yb5B5bwigJ6d0A3rvwXF8eG4SHzgsiYNmmFoYmHDyRreNpc8XcPfKPB78VwFb
Bh20Z1xjkyyCUKMcW8Sb4ka+51QAz2EhBc35awn4LwBulJ8joN4D2mWVzH8RyHF3C+rctMNgT97B
aXOT+PIHmnDyIZS4sQ1qSLoxhb1BRQXyydAUUwJ7TTHwmePS+vWvDRauXTKIX/0tpy25pqTQ07jQ
QlvWKxtCOe8F8COs8b+F+S8A5YsQECdQEpS+yJBiGkBfzjX1fzq/DeefmNFnSo3HpqjNsvPP8wkw
4WN43g/gkFkmfvqZNpwxL4VLbuvDM2+WMLVZhlkEpLLytO310dMuWN20+Sdi0O/VAJ+NWSWo6MGs
BevSSql5dHF0daFrNgragdQz6ODIvWNY8pUO3fkdh5x9rsef/q4FIHQnz1RCz4gsAXqRGNCIf8oh
CTx8+VRtFWwdcLZN4UJnwQkBq6CkmZxZFO0H6evS+wn4h98WAJ28GpRqL8NMTINVoqLpMmw3nkb+
nkGFdx2YwN0XT0ELzVRs6N8z9Yu21AxXxMmq+/V57WhLSVy3ZBBTW8qWQNhEQMGBkTRQGpoL4Elv
Cu3XU/DXApjvqpeQOEIYyQT0mBouaKTozykctV8Md13kdn5qMNz5GwfPGqDneu2nWnH+yRls6XfC
+ozJSU5m59FBPAF/LYDy+r+U8mAlTShFEU9BXNbEoPtctIHmlMBNn21Ha9rt/OzlbzzIGqDRh4ag
q85qxVOvl/DUa0XtGKRnHhqEEnAsMkwOLp+Tr2fnrwVQdgA6yt4fyqJlzhB1f3dOPzDk4AfzWzBn
D1Ob/dz5Gxd63mTxp+ICN/5nGxJmufOHqlXSIgClyGPW7EteT2ERnbJ//cZfAfBSGxUO0CsAIbrT
1NHJ43/a3BQ+e3xGB4uw2d/40HMnoT98dgyXn9aMvqwDM2QCANsipZo9kFdJCH/zAfwVAI1OanDc
QO3wvEiP6MF/7fQmLUvhagOMn3g+gc+flMF+00zkaQc63VRD8tLtUdi27f+Q5KMAKEHFDlsvfrVV
AIcqq0DX5ePxJg41AArvPf7gBN5zYEIvF7HpHx3I90O+gCkZiU+/K41svmJpsOYIyglwhJloM00x
R5+Oj3sH+N8hi1IoJcwwhc1RA7AshQ+/Panvb/jWJhi/oTZAAz61gWRCwA5bhKAwhHKo3/iL/wKg
K/55CZrhWHS1LKA1I3Hq4a4AkHOIiRaexXfE7BgO3SOGXEkhHFvRen2EItAs3ztMIALg4l1LbSda
UigMlRz820wT+0419NmE48EzQUOWX9wUOO5tcRRLDtwItVq/KvuK//huYgxfT0iSZ8j0o2SfvdoN
xAyh5/9c3COaeHbp/tPMbdn3vo+5EyDAvhKgBRAO9NzPUZi7d0yfEM//o4sn/HP3MmGaIpJtIXIC
4EGmH8MQUW4LkRWA+qsbx/hFlNtCZAWAYRgE5ATUnraQlGv1SseGwtvDhILhcsIhqfIUYGljtgAY
JsKwADBMhGEBYJgIwwLAMBEmcpGA20V6MoxHZQRwrfHOJYAEpWAEIFR3lwhDvCcTLsLUJoJbjuAp
AMNEGBYAhokwAU0BGGbiKPpP0f+6SEHbSXHuhh8EIwBhdLAwocNRbulIg3aOH5GjTYJAf6W/+UJE
22gwAhA2wuTvYTTU+WW5c/cXc3ilfwMGilnEjRgOaN0THckWGLR3ZvnhsUVQHaIpAExocMPwle78
j61/Bre+8CAefnMlugv9yFtFxKSJtkQTjph6AM448ET9cgWDPsPTgskSkACEyb7S2xWOKFHGDakW
eHN96vydy/8X16+8HZZjI2MmEZMG4nHanVlhsDSEB994Eve+thy3v/Qwfnryl9Eaz1RRBIJbdpsY
wZ2PTxMqhhmfys7/1Ud/jiv+eSuaYmlMSbbApG3kytMCGulNYaAlnsb0VDvufvnvOOfeTvQWBsuV
fXk+NxmCEYBa11kc6/hMTaDHYTvunP+rj/0cP1n1R8zKdEApR1sA2/z/LvRvWzkoORZmptvx2PrV
OPcv33Pfq1cLqiACYWyjARCMADBMBdRxTWngl8/egx8/fTump6fozj2Rblx0LExPtWHJG//EDc/c
pUWEHIjM7sECwAQKdX6a39/2woN69J+eboftWLt0Dpay9XTh1ucfRNbKQ+qC3hORD2YkLABMYHgj
/x/WLsMX/vojpM3kdgE/E4X8AikzgRd6X8eara/omAH6HbPrBLIK4MDRK7hhSMJxmwk3lqChOTyZ
/au2vITLHvkJ0rHkpMx36vQlx8YzW17G0TMO0UIymcUcz5MQjpbh9ZVds4x2B7YAGN+hzk8RfNT5
z/zzQhTsEuLSnNTcnRZuae7fnR/w/fwbGf8tgD4A6RFL77UkHIZIZPA6/5uDm3DWnxeir5BF2kzo
308WsgJoKjBpRq4A1JoA2yhbAIxv0LycRv7+YhYLllyBLfl+ZGLJqnR+svjpuw/r2Fef/8jcAWZi
sAAwvuA65ZQO2Pnkvd/C4xvX6Og9cgROFsoDKDolzM5Mw5yO/fTXcVjw7sECwFQd16Hmxvd/4aEf
4ZF1q9CRbK1K5ydoGbGvmMVp+x2Haak22I7NyUG7CQsAU1W8EF8yz7/66M9w76vLMT3dpgN9qoEh
qPPnsH/LLFxy5Hw3H6AR93cPaDnCfycgeQFVM6V8ua9a46afheNcGgwvxJeW+9wQ3zswLdVetZGf
RCVvF9CebMKvP/gNnRtAKwGiGuOYbhMhWSH22md1NHNc2AJgqsZoIb62mvyc353jSx0GnDBiWHxa
J+ZOPUA7E70aAszuwQLAVIVqhPiOBTn9aKTPlfK44vgLdOen4/lWHShCsAAwk6ZaIb6jQQE/tMSX
s/K4/uRL8Im3nTB8PGbysAAwk2KsEN9qJecY0sSmXA++/+7P4eyDTtHhv+RjYKpDAE7AiijAEPgA
Q+PoaQBGC/FNGvGqBPoQ5PHflOvGF9/+cXz20NP9HfnDVLQqQGdkMAIQqrvrKRIzGfwM8SVolKc4
/wvm/h89+pMPwJByMvk+OyEMo5NHcArAUwBml/EzxJegQqCbcr04dd9j8f33nK/FhvwAXAm4+rAA
MLuEnyG+3si/Nd+H4/eci+tPuqS8zs+d3y9YAJgJ43eIL5n9FOL7zplzcOup39TlwCnJn+P8/SMY
H0AYHSxhmvLVAf6H+EpkS3lMTbbghvddhpZ4ZtjP4DsRTgcORgAiCHUYbS4rNZyq6kYhuymy9ZS+
GkyIbxGtiQx+d1onZjdND67zR5yABCBMJgDhr5fV85AbtHPNyD1Hyv/WMex14tjyovy8Kr4zMx2w
qpTcM1aIb7BRfv62h10nuPMJSADChn/2P4381HhpN5v7X3sCKzevxYu9b2pRoJFtzpR9cPp+x+k6
+K4UqVB7t4MK8SWz3wvxrU2gD7WJ6O0QFVEBqD6VO93c9Oyfce3KP+CNgU3bBa/o3W+Vwg/++Vuc
edDJ+PrRn0ImltpuY8wwMTLEtzme3q0qvqPhhfhmS0Mc4ltDghGAMM0AfLCuvLm93unm0Z/jxytv
1x5sqoBDZr6uWFuG/l20S7jm6S48vflF7e0mh1fl7rhhoNpVfEdCIb4bs1tx7YkXDYf4UqGPmtHg
bXQseBmwCtCWVtT5v1be5ormyHHD1J2IRlH66b3o37SstUe6A3/bsBqfvLdT18wL0w43flTxrSTQ
EF9mXFgAJomXk/7rf92Ha5/+A2akp2gH2XgbVdBgQ7ntU5Ot+PuGZ3F2iERgtBDfasb30/y+pxBk
iC8zHiwAk8Cte+emql79ZBfaE826Pt1EoTJZVCvv8ZCIAIf4Ro+ABGBkpEUY/j15dIw6BP7y2j/w
2uBbSJhxOLu4whAWEeAQ3zC0yZHn4H9NsGAEIIz3thorgeXvWLHpBb3d9e4uItVaBDjEt6IWYJja
qv/9PyABaFC8GPW1vev03LbS27+r1EoEahXiy/H94SAYC6DBqcY2V0TQIuCF+Orly3IVX/JjVGPz
DsKt4sshvmGGBWASeCP+7KZp5dDeSXxZmSBFoBZVfIMN8WV2BgvAJPDcCHOn7l92/lVBAQKyBIIK
8eUqvuEmEAGgkTJML8rQq0bRSipRRVDlmmnJNpRsq2px/X5aAlzFd0fC1D69cwnABxiMADQqtARI
838K/vnkwadga6G/quGsfogAV/FlKgnEAmhkyJtNcfyXz/sUTtzz7dic79M17apFNUWAQ3yZkbAA
TBJdrU4Ive/9Lad+E++adaiuaRc2EeAQX2Y0WACqgLd1FWX/3XrqQrwzZCLAIb7MWAQjAGGKrvIp
7dPL5qPU3ttCJAIc4jsBItA+aysAESFsIsAhvszOCMYCCKXE+kNYRIBDfHeVMJoB/hOQAESLMIgA
JSdxiC+zM1gAfKKWIlCwSzo5yaviOz09BbaaeJ2C8QhHFV+mWgQjANG0rgIXASov1lsYRMKI4bfP
P6ATfKan22FXqYS3t9qRK+UbL8Q3qm20WkrCjE6QlsCj65/BggevwC9W340vLfsxUmai6lV8qfrR
9Sdfgk+87QR/t+tmAoEFIACCEgGqMfjIulW4/NGfIWMmICGrkvNAUBXfTbkevVX32QedgpJj16h+
P1NNAhKAMNpX1SgJNHGCEAGK9kuZcV2S3L3j1bnGxq/iG932GZAAMEQQIkCBP9UqUEJwFd/GhgUg
YIIQgWpB+Qybcr063fn77znfLYJaJ/sZMhMjGAGIroU1KvUgAjTyU1LT8XvOxfUnXeJWPCr/15CE
sY0GUBAgGAFgdiDMIkCdv6+YxTtnztFbl5FPgTbO5EKejQcLQA0JowhQzb5sKY+pyRa9Yy8lN7m7
H1Wn3BkTLgISgDDaV+EgTCIQ7Sq+YWyj/s8BAhIAZjzCIAIc4htNghGAMIpryKilCDR0iO9EiWgb
DUYAmAlRCxGgmT0t7XGIbzRhAQgZQYsAh/hGGxaAEBKUCDR+iC+zM1gAQorfIsAhvgwRjAA4Su/G
E7pXyPFLBDjEdwTaARjN9hmMADC7TbVFIHIhvsy4sADUAdUSAQ7xZUbCAlAnTFYETGFwiC9TQwGo
Tm2K6hCmc9kFRorAcbMOxeahXj2nHytWn4J86O+DpSG0JjJYfFonZjdNH94qjClTp21isgRjAUQ0
ysoPKkWAtiE7cfbbsTHXjbxV1LH8tLRHpj696N+0FfimoR7MyLSj67ROHD71AO78oxHRNlq9bWzH
wS1N5b1qiyv09S33rggonan3+w/9N65/+nb8fu0yPN/9OkrKhuO4hTtIAGY3TcPZB5+My+Z9EtNT
7dz5x+j93i5K4WgZwfWVQASAqT5k8lOjpbn9xe+Yj88f8TE8+dbzWNP9KrrzA7oi8KEd++Kwjv0x
NdWqT8DbJJRhPFgA6hia3xOUrx+Xpt6VmF4j8fL5OaefGQkLQANApj5ZAzTCKwpoKUPTAAl3KsAw
oxGMAITHBbD9PqUNBFkDBlXt4cI9u0cY26j/9UACWgVgGCaUsG3IMBEmmClAqOwrIrhlFibMUDvw
5kxhahPBnQtbAAwTYYKxAMLoYGGYSiLaRtkCYJgIE1kBCEfIJxMGotwWIisABq+XM2Wi3BaC8QGE
aIKlA+UMYPVref34KVqOiSZe0OSzrxegLNr+TMIJhT3gOST8jwQKRgBC5GChhy4l8OqmEmxHcXw8
g5c2FsM0RgW6Sh25KQDFyidjAs+9WcCmPgtkAFSEzzMRwpBCP/vlL+QgTaFr10aNCAoAEItJbOkp
4aGVWd0AyBJgogUlTpH4r91QwFMvDSGVFHAi2A4iJwAaHQAm8Mfl/boRsB8gejiOe833rRjEQL+N
mBHNrhDJqyb1z6QlHnhqEC+uL0IKRFL9owrpP9VGKFoKv3qoB7FENM1/wn8B6CsPuSHaeEE5CjEJ
9PWV8MM/btZWQAStv8hi20o7gn//WB9W/CuLdFLCsZ3wbQ4SAP4LQEixbIXmZgO//Es3lq3OwjQE
+wIiAAk9Of+29Fv4+q82IJmSIbX+gvFLRVYACG/uf8H1b6I3a+uiGmwJNC7UpWj0J4vvSzeux2sb
i0jGZaRXgSItAOT1zaQk1ryaxxd+uk6bhTQ9YBFoTCxLIWYK/OSerbjlgR60tZjaEowykRYAghpA
W6uJ3/61B1/82ToYhtBOQV4abBz0Uq/tdv7/XdKDi362Di0thv5d1Im8AGgRsBRam01cf8cWLLju
TWTzjp4nkjhwkFD9Qt2bniGZ/CTsP75rC8675g2kEq7Zz88WAYYClxcDwgqNBmQJ3HjPVqx8eQjX
XzAb8w5MDVsJtGxExXU5cyD80BSOpnfk2KXXxh4LX/nFetyypEeP/Doy3Rv8w2gEBJcKEJAAhCkZ
YBzc6YCBf67N4cSvrsVXPjENF5w+FdNbt6VM0NSAGg/nEIULr0N7UzhpuOv8ty3rxaJbNuKVDQW0
tdXLnD+4kmC+JwOpkhRIOnUz1dDLgylDd/TOX2/ETQ9045wT2/HRY1tx9IEp3cCYcPOvN/K4f8UA
bl7agxXP5ZBIyTp0+FGIKrml/cXf1rxQSSyFzExd9TdppI9WVo42rfP9oqoB3Rjq7Pmig/yQg3hC
Ys7eSRx7cBr7z4zjqANTiBm0PRdPC2qJN/JTevcrbxWx/PkcVr4yhIEBG0ZcoCll6OlA/cz3KUnB
pG1eBuMlHNrzp8PfABRNPsvBy9XFdwsAy4QlPr4yqyfQtH2Nv5JTNbQDiZaNDIFki6ktgtWvDeHp
F3N6RiNM3oQjTCiLvHqAjAnt5KMlPgr5tun3ddLmhlG08aPjINvUX/6db54K/wXAzb3pEar8FHy7
FH+gkcNbK07HJWTC7fjUuJjw4O17qLdHc7Y9M019PSqKUybTsk+mixSf7Kt8+SsAS/UyIxVZeQYy
9jG4FnPdor3L3PFDSTgq+VQBBSVkDMrJv7L1zkMG9DS60x/zn/BXAMoI4A2lLCrG4W1oyzDMaNAg
SZu9Kryh/7zG3wmMvw65E6EdF45j/FM5eSq/4+/xGKbucdeYhZDL9aVsqmcB6HRN/kQ2/4qyC70Q
MS7AxTDjoSCVXVDCkU/rt033d9rs84gsFM1hepbcNQAHzwgZJ4+AO13jF98DbgMj2gAtAcaksvI9
sPLPaQHocq1ov/BZAADXEdjpCCEehjTJg17XjkCG8Q0FRxgJSkl9evDueVu0A5AGUR/xXwCGTRjj
YeXo8sv+H5Nh6hEaHGWM5v+P6tN3V9F8xfcDeCZMfCC/AlZuIyQV49K5WL5eWOMwkfs02nt29rnK
v+/KeyvZ3c8xO6K7hFT2kCOVuE//fXrXzm7wpAlgGVAozFdGT5foy3z0qftFIvUfqlSy3SVI36+v
IdArQ2OEg2zLbBtdBKi2wUi2ye+2z4x1jNHeW8nufo4ZgYIDIyGVNfT8QOzFFToAqEtQP/GVAARg
G1Kiy1HOf8JxpA4NZiaE5Sjki6OLZTwmEDfdDS5G6+iDRWeHvyVibppsJWMdY7T3VuNzzA5PyxFG
Uio7fze6ziziBGVimf97gwUjAF0UyaREq/n3v3YXxUvSSO2vnAJ5N1kFxoHCW3N5B8f8WxrfO3eP
7dKQvZTkr920Hk88l0WmnMFIkLVA4cstaQOLv74fmlI6D0Mvv9B3XvmHTbh3eR/SKUO/f7RjUMQj
vfe6Ozfjjkd6kcm4GZIe7rnZOP7wJiz69CwdJanLq5c/V3kMjp6cCMJQVs4SBm7S717mr/ffIxgB
oOZ3wlLzza6ThjIffepmmMmFKOZtynecyK2JKtSRqdN1NJs44fCmUW/Dtz4zCx/8+todJgAkEFQC
6wNHNeuEpkpuW9qjk2S8acV4x/jT433bvddDn5ulML0tNuq5bXcMnumNj4ItYhnplLKP5P70jmf9
Dv+tJLgOuGypXs80hP0bx8oWAEnDDzeNCUCjOXXSkuX+9F4lW+F972jGqce0YCBr6zJmlZAI9GVt
/X76jqLl6P9PhTJGxpeNPMbwe0vjZNMJDJ8Tfaf73WMfgxkLh7qDEHB+od+xdGlg/TKwA1EsADkD
+++Y95KwC78TsWaauPoa5NAo6Jp2Uuzw8vr7N8+Zqf0Ao5nao31uNIfiWMfYWeWj3f0cU0bR3D8t
nWL/89nevttB+TLLTvLd+Rf0FMBljls/Qyr7u46VOwsQMb1db/1lbAeDdvGTRo5uKFHnplH3mIMz
OOP4Nvx2yVa0lmsXjFv1snKXJmKcY+ywo9Nwwy0X1tuuuF6FBTJyJyhmdKj9GzGJUu57WHZSHmcq
sowDE4AALQAyAgRZAXLgzmOeh6OtAKkLHzC7hXYEluXhG5+ciUzacKvg7ta3McHjev5p9M+VNt6m
5/7aYR4cwQrAsBWgtBWg7HyRyh+xL2D3IPObakdQySsqV/Yf7+9AdtCuat1CsjK86rqj/Rzpd2B2
CQdmkqbC38V9pxXKqb+B+sWCFwBtBcC1Auz8lSLeagAqMJOn3vFaBzn3nnl1aJtFroCvnjkDU9pN
7ZDb2dx9ovTnbFg9JWztLaGv4tXdW9K/781aE/0qphKlbGE2m06h75FcYu0t5B8LIvBnJEEtA24P
ZTgtVDKxfPkP8qLvLCmT+ys7XzcFQ2tKhcfku7duxC8v3Ufvb0e+gL2nx3H+6dPw3Zs3INPkrvHv
Ll6JrfnHt2OfqXEkaAfdEXEAhaKDQ/ZJ6kN472cmAmX9GVBOqRQz5JfQdabtJv4ET20EgMKD1yyW
3fed2Z/50IrPKSO5BJA2VG1uQmipTJcdAQX5/G1NFr9e0o3PnT512Of2pY9Nx68e2IpN3SWIzDgi
4JkSYxzDsyBOPbpFv3bGqBZH5TGYSmyRaDVVfuu3++466kk9+nf6H/Y7GjVRHQ2p3nxlZO8+6kFV
HLxaxFtMKKdsT3Ki+I7FAraHlvxScYEfLN6AoYIzvL35tFZTi0BpiOICxut1o93jHSGnYqE09oti
E8aGn+MOm+IoxxZmxlT57uXZ9eo7rukfTNRfuARAiwAczF9s5FIvfUUVepeLWBOJAPsDJgCtnWSS
Eq+8PIRf3LdFj8Deytz5p0/FfvskdYjvaMlAuwI5/igfYKwXRRsyE8WmdF/pOKUe07HOwYp5JXdp
3N+c//Go0RTAQyjMUYpKh5mn/+Ockio+IWSsHU6J/QETgOb9MmXgqj+8hU+dPAXtTe7WV7QZxmXz
Z+LLN7y52wLg5Rq8sC6PdZtLemWBtnUYfnIQej/FaW0mDts3xdul7RwFmBaMeEwWehf03fPOl2tp
+nvUWACGYwOMvq5jXs6c/sTZSLY+gJLtUFoJ78A3PjrePy7w6voCrvvTZiz89CzXElDAf32gA79b
2o3+IRvN6V13CNIUg4JTr+x6Czd2vQWzdft99XQQ0qCF005oxz3fPnD4/cxYKFskp8TU0Fudg/e8
8/c6269L1HwJpXY+gEoo7/mEh8zsPccsUaWBBZC0f7N2CrqDDr/GxLaBdNrA9X/ahHVbS8PRgam4
xDfOmeUG+Y1krPs5Csm4gExJNI/yot+nE2M0IX5mFe1WWcJsMdXQlhuzdx29iNo67ZgVBrEMhwAQ
y06ySBVzd867EaVsp0h00AZppTDcpJoyno9NR+MqJEyBzVtKuGLxRm0BeB759x/Zgj2nxfXpjxsX
MM4xyJogf8OYr52cX+RRqiTi7aZTGlySvevIBXq5b9mJofFzhUcAtAiQJaDM7D1Hd6rClhtFsiNO
qZIVu7kzo0DFPNLNBm66bwteXJfXa/LUYTnJotYoSyTaY6o08A/DKJ7tpvkuIjkOjWyGSwCozS7T
HR6klk6x+2phJg1AOm7OQFTtyjHnla6dqWgTU6B/0NLBQe6KwHg5ARNbAtzGePd9J+cWyWdG8y7H
EmaTqUqD95t2/wcH7jh2q9v5OwON9d8ZYROAbeo4Xxm5O4+8BE5ugTDTBqRJ+yWFxnQKG+T9p+i/
2x7aiqfW5oZ9AUzAKNqLXNgiMdVUVvbG7J1z/73vnuN7gIW6PH7AZ7NTQigAZRHQjkFlDt4570Zl
9Z4FYfYIM2NAbzIYMcdgRebtdpm8I+4Dee3zeQffunm9++Bd42DHzNwxDIAJv3fE53f3cw33HB1l
Q8YFjJSBYvei4Tl/SDs/EVIBKEOeUloduOvYxaqQO0Up+ykRazO1JeDWEYgEnmPPoMkQbRUh3HJf
I0NwaF2+ucnEXX/rxbJVA3rt3vss/aSgnkonYSWVx6h8784CibzPed893jEaF1qtUpaIUQKG6IaT
O2vwziM73Tk/yVz4Rn6P2scB7Ay9OvCQmbvvmKc6PvLoCXm77SoRbzlP2UOAU7JQziduVKiDUbht
76DtRkZUFP2kaImRIqDrA1CT+816dP2/A3QHFuUlALu8tk+hvZWrAiOPQZ/x3kvViMdaQaDfU+Yh
nZv3/rGO0bDQYCSEFIk2Mvkfk3b23IF7jntRr/N3hmOpbzzqJ45z/mJD5w8AyHzk6bMhjB8KmdpD
FfvIOUitdNejXeoAr7inV9l3+Ikp6CCfUcupUAe2lY4MJItheDmgvCxAIcKVIjDqMbz3FhwUxhAB
+hyVIsuUqw4PVycRbqXhkULTUFA5OwFHO/qcogVlfye7/onvYMXnSu46/0mhWOffGfUjAO6kVmAh
BNUUSL3v0T1kqunbEPJcyDhUaYDGQ3J9N5wQUEerLMk9bL6NqPY70qS3rMrg3W1QFN/IUX2sY4z2
3kp293N1C23gQYX7aHVKJqDswoPKKnxj6M/z3O28tdkfbFWfyVBnAlCmonhC5kMrTnGkebmA8X4y
ApQ1SOXvSQiktn09T0F9Xunw6D3a6etLG22xv/y7sS55h8+N8/4xj1Fx7F06t3rCu7eujro7rJhJ
QxhxOFZ+tRDWj3J3HvVLfUnuqE8Wal35puq1W7jWwHxQDTV3WvDhVe93lLpMSPP9QppQVpaKXdKK
AXnLyBCu42tlaoI28/VobgozDV3Ew86vhqN+lEu/cLPewafCKq3JOU6S+u8U5BuY86xCp+tpJSEA
1GeUUh8VZrpFOSWAHIaApUsuux6xcK9+MDWCvPmC5va0eGrASAohkzSY0CY2f4VSN+fS5m3oOqyo
T7BGZbyqSf0LwPC0gJyE810/AIDUv6+cLUx1NpT6OKCOEbFmkm8opwA4RTLqSN3LAXMkDN69GDdq
nql7vOVj/ezJPnRNdqpGJU0pjCSgLcghMgDWSCH+DIjfZO+au2pbW9P1+8au115HNI4AVAoBUV4x
IJo+8uQcWxkfEMo5HgrzIOXe+kHT5euQAosiN91vUPaOu2kyjYOkOkm0Nkr708bLu9MJKKdI5n03
gKeEMB9xIP+STx3+xLZCnd6Uk5yA4YnlnyyNJwDDKIETlhpu5lXFA/vQunRKbTpMSDkHEG9XjnU4
HHuWMIyZyrGkMFKtvGVhI0IDvQSsXA5CFKDUAGRsrYJ6HcpaqYR8Kp6KP9PfdRiJwDbIuXfiiU49
efZ3hQYWgApoaYb2W5u+WVVaBpVWQ2vu2BYntlGWijjUQNwIcHMWJjASsK2htYlYcrBPFAu4e15u
h0Nv31Yawswfj2gIwHaQKdclsWmae+0NrO7MTqDOvgYCm5YKd3DY5kOKChEUgFEpl9Qkz24XrxA0
Ml3PKmBRea2+cebyDMMwDMMwDMMwDMMwDMMwDMMwDMMwDMMwDMMwDMMwDMMwDMMwDMMwDMMwDMMw
DMMwDMMwDMMwDMMwDMMwDMMwDMOEnf8Pg1qjUfJSQ6gAAAAASUVORK5CYIJpYzE0AABOZIlQTkcN
ChoKAAAADUlIRFIAAAIAAAACAAgGAAAA9HjU+gAATiNJREFUeF7t3QmcXWV9+P/vc86526yZCWEz
7b+1LghahQDiCihhFRBqsKi17c+XS1u0uFXtT4XUtmrVtoIrivx+/6ooaRGEsJYlqGArgcrmRqkg
ECDJ7DN3Pef5vb7PuXcySSYzd/Z7z/m87TQhmczce+be83yf7/N9vo8IAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAGARmEX4Gkg0y2sEaFvGtu1Dx5Lj5p569QFebxPv3BrsdjkOWmdlo6ml/hIB7ewd
d2d2Pfx1IoMSySaJdv0ZQUJaEQCkijVuoL9QfNm21cglR1Zne/pr/vzprtD3PZEBEemf7dMBtACT
t9Z27GcGNpqRWR/OBTaQbWJ2DwwICtKAACC5jOhov2GTJ30bPLnETDvY919ge8zEDlsOc7nAVN4u
JsiKxJN+E9mcGPN2a7ys2DC5VwpIGCMmkqDg2VrxLjFylw2tb3xT9fKrvVpp511BWX4cer6XrVZq
2790wNheT98FBVuNfHVdLR4lCAiSiAAgUayRDeJJn0w74OtgXy2PZPxK+V3iBYGE4ctMpvAyqRUj
KybwCn1dYrwpV8SKLY+IWJYRgfaj7+qCSJCvP3QrxhiJikNio+qIiG+MicoSyVdNoa9aK+38cVD1
79JPHrh4v90zB7sFBAQDSUEA0Pbqg/6hYvZcr9cBvzbyzMuDwuqXRqXBl5qg8ApbmxAv398jni9S
K4qtFsUN+jrIRzWN9q24l4UO+ppEsMHkfwJoH/HdXdf6o/g9rW9rfXubjHhB4/dicj1iPE+i4qBY
a0dMFFXE975mQztaM9mvFUrF0l5ZAg0INkpIZqC9EQC0qw3W33PQ1/X6UsG8KpPrPzoqDRxjgo6X
S1jq8TpWi60UxdZ0sDciYWOgF53uT5ny618CSL4paT0rYT3wz7iJgS4g5Hpd3BCVhsdMFJbE979m
w9porWf/r41tNDt2uz5aZHjJuhrBQPvhht9WrJELxJ8aea/+X9u7q/3mZX6m9zgpDb1N/Mz+XqF3
14BvdQJgdf1/ymDPQA9gOtbGyT9TE2uNWyo09YDAhmJrpTEbVn8kUXVLtWf/S8c3mmcmv4pmBR4S
K5sMBUNtggCgHUwz2+//8NiJ1uTiQT/I7K8Ruy0NiUSu1q9az+t79dQfP2cA87BnQOAHJtMhuoRg
w/KorZXuFJEttUrl62MXH7w9/gZ7T1TQmhgYWtmGK3zZtEHX71wVXte7n1wTZLJvFyOv9jIdJ4mf
F1sejgd9a2tijB/n+AFgSVjRtKLmCRrBgJ8TW9y5XbKrviZR+Y7Bf+i6cfI7UyvQ0hgsWpEO/Fds
iKRebdv3V2MniZd7tVSG3m4Kq9dIWNbqfA0KQgZ9ACtkVzDgZwJXNxCWJKpO3ChW7qhJ+ZKxf3xW
XC9AINCSCABayTQDvzHB+SLhyRIU4tl+WNVKfSOis30AaAW6VOCahfgm12NcVqA0MBBF9mIrmYtG
/mmVdhIjEGgxBACtYNqB3ztfxJ6sW/SY7QNoH1otKDbOCvSILQ0OWCsXRTa4mECgtRAArKjGQTvx
Gr+m+s2eA78xWgPAbB9Am3EFhOGMgYCrczqHXQMrhABgRVgj79gaNHrx971v7CST8c4XO2XG3xj4
Gz15AKCdNEYX63oO7AoEioMDkbUX25HiRSOX/vaA2zWgLcsJBJYdAcBy0y199X2y3X/x+Oogm73M
ZHtO1857carfaPEfM34AyTI1EMh2a0+BnTYK/3Toc73XuCfqGgrNfkAZFg8BwHJ6h83Eh/Js8Pve
f8nHxEbnmUxhtS2PWTGuXScDP4Bk00DAmJrxMnFLYi+4sVYc+tzIRQfeLBdYTx4SQzOh5UEAsBzi
Rj5WNpqo5z1PrfcKPR/0MoX1dmJAC2fjylnXi5NDdwCkgZ4zEuk2QjGFfmNLIzXr+X83/NjNn3BL
AZOTJSylqUe/YSkce1vgotmHNplVHxi6wPP9643x10djT1etremI72b9DP4A0sMdSmTEeMYWB0KR
yPMLqy5Y9ezXXa+TJJcpveACPaWMSeoS4uIuJU1nuVn/E+u9Qp+b9Ufj2yMX+Rp36gYAwM2CoqrJ
92VseSQU439iqLvv79wJp1PqprC4CACWwhXWlwfjlP+qD469TiS6yvhZ35aGqmK8zFJ8SwBoezYK
NSvgda/xwtEdm+3I028dufSFAxQILg0CgMXWiFY3XOH3/tZrv+dlCqfb6kQkUY1ZPwDMytVCVU2m
I2OtGTDV0bcO/vNBm+OMqls7oFhqkVADsJgusFld7+897/ETdC3Ly3WfbssjkdjQI+UPAM3QeanJ
2OqE1gb0WxNc1fv+nRfK7bfr6abWnSuARUEGYFG44y+Npvz7zt92ms10XW38wNfKVjGGFysAzEdc
L2XdksDY4Obhf/z8GSIbI+oCFgcBwELVC/202n/VUS/+3xKGH9VjMuNDexj8AWBh3G7Biin0ZW1U
u9mOD/zD8BfW/jt1AQtHALAQOvjLhSIPXWh61+682u9afVo06qr83faWhXxpAMAUNgpNvte3tWpk
qmOnD1508HUEAQvDIDVfk8V+1u9dO3i1l+89zRZ3lEUkJ1xWAFh81tbEy3jiB9aUxs8c/MJBm1kO
mD+KAOejPvj3vO2B/t61OxqDf1XEMPgDwFLRZdWoIhLVjM11XrXq/cOnu0Zrmo21NA2aKzIAc1U/
sKLvPU+eanM9/2Ks7bc1rValjz8ALAstDvQCazIdXlQtXjN8z31ny3G3R25JdqMeoY5mEADMRWPw
P+83p9l879ViI1/CMoM/ACw71w4gNIX9/Kg0uHn48VvPlEMftAQBzSMAaNaGK3w9pCIe/Huu1hSU
hBUR47GMAgArxlZNYb9MVBqKgwA9TMidIUDDoNkQADSjfppf3/BTp9igg8EfAFpKIwgY3Jz3am98
evSJilyyrkYQMDNmr7PR4pJNJjxo2zX5yGSuiNP+zPwBoHWYjO7C8rv2O61ctR+QS46syrt/lW2d
x9eayADMZHKf/2Gmd+1rrjJ+7lSpjWsvak7yA4CWYrUwsCZetmJKw28c/MJvbaZPwMwIAPapvoak
h/qsfc3VXn6V7vOn4A8AWpXuDvBzRjw/NKWRM10QUK/fatWHvJIIAKZljbxja3BA97OypVrwXa/Q
p4O/7vPnKF8AaGU2isTPitsmWJ44c3D1gdfLQ2JcvwDshhqA6bz7+qyuIZXL9gN+9371Dn8M/gDQ
8nRnltZp2ciPgswVWr8VD/7auh1TkQHYU73LX995vz7NZvu/K7aSlagWiBiuFQC0DRtK0GlsWL5u
uPf+s9zD3nicLuO6BgIQMgC7Ofa2QCPFvvc88UqbX3212GqnhFUGfwBoO8bXom2v0P+63sHnXykb
j6/JBUIB9xTMaidZE784bpfeoRfd6mU7XmXLIxzpCwDtzJiqyXRl7Nj2M4a+/P9dw+FBu7Am0qCD
/0ZT00jRy/e8ypaHQ3fwBACgfdkosNViTTpWX6nZXVcPoNlekAFw6uv+q/7s0dNN15rv28poTUR4
gQBAElhbM7meIKpM/GB41f2vETlOZKOkvh6ADECj6E8jw47+K12kKJZ1IgBICmMCzepqdrd38AVX
arZXNmxK/fiX8hqAqfv9veu9bBfr/gCQXDWT7Q7sxOCZQ1981jWyQVyr9+Q+3ZmlOwJ6x9Yg3u8f
fsDr3F/X/aus+wNAUlnP1kqRzWQvP+iCJwtyqJ4pfEFqx8H0rnNr6v8SU3Vb/rK9H7AT2unPC+Ij
pgEAiWOMNgkKTaazMDFQu1wuNmfGrYIT90ybktLIR/v8b5ID3r+tMzLZvzfG75Kwptci5UsiAJBg
boJnfKkWIy/Xe8aqv3j8DNl0TuiCgBRKZwCgqf9NG6JSRT7odez3Klsa1NR/Kl8AAJA+kbG1cmT9
zOU9732sXw7dYMVNDNMlhQHABZ58dV1N13+MCd5tiwPs9weAVDGeRJXQy68qeDXvPNloIjcxTJn0
BQAbDjNijJ0YMJdLttAvUVVTQqmL/AAg3WxgyyORZFd9cNV5T7xKJ4auNixF0hUAuD3/G6JV737y
WC/fd4ZUxnX7R6p+4AAAZYzYmjV+0GXF+4RODLU2LE3SFQC4H66x1tqNYkNd86HmHwBSywS2NBR6
ua5jdWIom94YpikLkJ41Dzf790L9IZts97G2Mqaz//Q8fwDANKyI8eKJodjj0pQFSFEGQGf/VtwP
2Xg6++etAACpZ3xbGY28XE/qsgDpmAHvNfsf1UMgWPsHALjJYZwFMKnKAqQjAJgy+zda6OGW/rXw
nywAAKSeEd+WRyZrAYYuftaWxkFxSb42yQ8Aps7+M13H2rLO/rXyn8EfANCYC7qJobVRlJosQApq
AOpr/xFr/wCAfZlSC/CXT746bhGc7L4Ayc4AuNm/CXve/cSJbvbP2j8AYJ+0FsBYG5pPyIYH1ots
SvQSQLIzAH1b3fPzIjnZBAXN70S88gEA++DZ6oQYY47p3n9Vt8sCJPiMgAS3wNWDHYzteveTawLr
PSi+v0aiqgvveOkDAKZlpWYKq4wtDn5i6OmD/lYOFSMbTS2JVyu5GQB3sIM1vnhvNh2r10hUqzL4
AwBmZKxvqxO6Tfy8Qw990JeNJrFZgOQGAIOPRJoBkKh2ioQlLfNM7nMFACwSYySqhpLt6nlyZ99L
3R6BDckcK5OZDp9S/Odnem60VT30J9nVnACAxWJDk+v1o9LIHcOVJ05wE0pXD5AsyZwVa/HfBut7
4p0sQU7b/lL8BwBolmcrY64YcP98X39SiwETGABYI5ccWZVDbzc2it5kyyNGxCZ7u2Mb0ZQTH1wD
XgPTvwbQKvSo4KhqCv1+Jez8Q/eoXF1ZsiTuCbm1mk0S9ux43vEm09kvYTl0tYBYdo39Fr63q/Fy
uUoPRmBfAk8k4xs9tsx1LI8i3i8rx3pSK/tiotPkHXd/Ka4rS5bkBQBx+l8889SpJtuZsRPFatz6
F8tBZ3aeG/CNlGtWIisyXqrfxYzIs/p98ZJZeQLMmw72GjAPTVgZcmeViWQyRvJZI77+3jdSi+rH
mGC5uJ4AYr3jdRngmU3nPB33BDCJ6SOfsABA0/+mKhfcFtjtzz1XSkPa+yeI559YOmZyll8JrYwW
rdRCkYNX+VLIiPzxKT0S+CK5QOSPX9EhWb2jAZikgbIGxj/5n4rc8YuKdOSN/Pi/K/KjX1WkVLOy
fSiUrk5PMp5x76WaxtRuGErMWNSK4mWAjn6vMiG6DPB5twxwieikMhGSdSfecIWvxRp95z15ig0K
V0ut5ItE9QQ0loKm9/VGNFLSQd/Kmi5PXvG8nLzquVn5o5d1SEfWSGcuWS8zYLkMT0Sy9dGq3PJQ
Wa7YWpRtQ6GMT1gXDOQDkVBLnIkBlpANTbbbt5Xxm7sy1TMff/zHFdm0Id5ingAJywAcqql+fU8c
bXLdGVsrVkRMNgE/p5bTGPiHi9ZVkr7uxXk36L/5mA45oGf32tLGbEXDAP13AKanmQD90PeKzvR7
Ozx5zQty7uMjr+uW/3ikIrf9rCzf+UlR/vvpmnQVPMlnRELd6MxFXQqerRXF2ujYnp6RMGm7ARI0
NbNGLhCzduQ3udFK5t9MtuMUcfv/Wf9fTO7GFBgZHI/c2uT6Q3PynhO6ZP1hud2+jS4BNAZ7mi8D
c9fI8GtAoL/XAsEGff99dcu4fGXLhDy6vSa9bnkgXhrAYtL8imfFz5dNVDx78OKDb2hkmhfzu6yU
ZM3HNprIRWkSvZbuf4vP3YCMyPaBmpx4aE6uec9queYvV7vBX98mu9Yl49mLDvwM/sD8uK2SJg6k
9b2nQUAYiQuu+zo9+fCp3XLvx9fIJ9/Q4+oHdo5byQZafovFoz8BWzP5noK1ol0BReJMcyIkJwDY
sMk9l20D/a8xQUcokW6gwWLRAV1vMOrvzumdHPhdylJXxEx8k2LAB5ZGYwlN34su4J4SCFz55/1y
8mE5eWag5oJ0dtosKl+bAllrXrr2vY8V5NDDakk5ITA5AUA9KtMoTaM1jdoYjhauMQPZORq5G4ze
aP76tG73hXU2ojca3fYHYPm4gFsDARGphiLHHZKTa89f7YJzDRQmKpZ6m0VjvTijHL3WZZg3msRM
LhNy67ZGo7LnvPuXOY3SNFpj7X/hdHDXGf5I0cobjiy4G4zeaPSGo39HQR+wsnSwz/hxMK7RgAbn
l7+zX/o6PBkrEwQsmiiKTKYz3Laj73j3NesZ53aXkABARKOywXyYNWJPkFpJc2SeC4/5mNc10AG+
WhOJalauOq9frvizfvd19EajNxwArcN129QiwFDkxMNy8rO/21/OeHFedg5H8fuV++ACroFrCxya
TFchisxx7qfe9+xEjJ2JeBIN5WGTs2ImaPyzMJrS11l+FFn5t/NWy6m/n4/X+T1m/UCramwd1CC9
t+C5TMAbji7I9qFIMgnb8L38NB1a09RnYtb/VTICgPohDYHf804vv6pHolqV9f/5mRz8Qyvfe09c
4e9S/rRTAtqCZgManQW/82dTggAydwtgA1sZ1TDgXX0feqTHHTjn2gK3t2QEAHVGozMvaPsfykrR
wiKdPVgd/N+92u3x15QiNw6gvegSnmb99Qb/3XoQoIW8WjiI+dKzGMLc4ODgxHy/QqtJRgBw0LpQ
XAGgPV6qxeRkNpaZBgDjJSv/et6umT83DKA9NYIA9Z139csJh+VkeNzynp4Xjai0DqAz2+//VmIK
ARMQAFijBYC93njBGnlNVJvQOM1zx2nyv1mvgM4T9H++LzIwFsmGo/Jy0guZ+QNJ4IKAKK7d2fj6
HpfNq4ZWjInf9433/+x3irR/hhhrw8hku3I1U32te20koBAwAQFALFvN1Ky143EbLLpiN0uvlA7+
Q2ORnPjCnPz/b+/frY0vgPam729d2jvm97Jy5Xv6ZawUTd4huVM2K75S1rpDF0aa/VetLjEBQDEf
5MUYVrjmSOMlrfDvKRjZeGbPZDc/OvoByaEZAK3nOemwvJxzdIcU6REwT5pf9jqSUACo2j8AqO8A
8Irdb/fyq7okCtkBMAdBIDI0FMmHTut2M4Sph/gASI7G7oCv/0mfrOowUq7SMnhubGDLI+LZ6B2r
P/jzriTsBGj/AKDOGsnrNoC5/UDTTW8II+NWTjoiL+e9povBH0gwd6yNFSlkjVz2tn4JQ5uAjWzL
Ta+ZyduSnoXa/hLTHkJbNbGw1aT6S1dvBnrNPn56j3TmjFsnJPUPJJfLAkQip7woL689LCc33V+W
7g4jYSIOt10mkURJmTonJgOgS9nux09Vy+ysiMavoxPWFf69/DlZN/jT2x9IPhf3W5GPnNrj5gJu
IoDm1K+VH1YScSBQQgIAa6zx8oz+zdNXrxErHz6th5gJSBEN9HXQf8Vzs7L+hTm3DEjwPwfGGFd0
ngBtHgBYo4UYWpDhRdE7tEBDxCZmWWOp6Jt9bMLK6UcU3E2gsU8YQDo0sgB/fVqPFDIiIVmAJhij
ReZabK5F5+4f1IvQ21WbBwAxLciwYsgANMkVA0VWXvuCvJsJaN9wAOmh5dJ6Hzjy2Vk5eLXvTv6k
/qdJxjOu6DwBEhEA1CViTWap6Zu8XBPp7fLkDUcV3H+T/gPSRd/3bsuvETn7iIJMTETcB+bAFZ0n
QJICADRBI/9yxcqrn5eTvg4vPuY3ERtaAMxFI/g/8bC8dHUYqSViSMNcEACkjIv8a1bWH5Z3fcFJ
/wPp1Oia8qrn5+TAVSwDpFGCAoD6pnZ+re+F3PtXPQCkXLVyYJ8nG44quNc76X8gneJlAOu2Ar75
mIJMFMP6/YB76ezjSDIkKABAM3TGr53AOrLk/QHEk4DeDo+lwBRKTgBA0Dpz0KpvdGOkWIzkT17R
4QIAF/0TBwCp5dfXAd768k45uN+XUjXOCHA/neUaJKReIjkBAGZW3+qntasZ3zDwA5iUy+jeYDqp
pg0BQMp4XhwAAECD9gPRIICWIOlCAJASmurX9N6B/b78ySs73bNupP8ApFOjELArb+SPX9Hhlgi5
L6QHAUDK6JJfXtN9AFCndwS9L3AwULoQAKQQe/8B7In7QvoQAAAAkEIEAAAApBABAAAAKUQAAABA
ChEAAACQQkFinrPuX2l8YHqu05du+NHfsBUQwBTu/sB9dFZur2QyegGTAQAAIIUIAAAASCECAAAA
UogAAACAFCIAAAAghQgAAABIIQIAAABSiAAAAIAUIgAAACCFEtQJsN7gTn/F9BrXCACmw310dtoE
MBmNAMkAAACQRsnJABC6NokUCYDZpv/cJ/YtOdeGGgAAAFKIAAAAgBQiAAAAIIUIAAAASCECAAAA
UogAAACAFCIAAAAghZLRB2BARDrpBDgrOgEC2JepXQCTs9V98SXo2iQjAACAJWTrd/3IWrF27xHA
9+JkqhGzhI9iGSRocMPsCAAAYB904A+jSALPd5/hG6Oj/D7p+BnZSDzjtXsogBQgAACAPeggbozO
540b/MeqRbfGeM8zv5I7n3xAOjK5OBsgVrJeRt50yAlu0O/Ndopv4mxAaEPxjE8ggJZFAAAAU9Si
cHLGv6M4LN/6+U3yjYeuc38+UpmQgdLI5CCvM37PGPnyfVdJJarKS9Y8V8578VlyxP7Pl65MoR4I
RJOfD7SSBAUAnGPZHBb5gOm4dX4rbvD/4ZP3yUX3/qvcs/1XbsDvCPIuI6Cz+4M795usCWgYroy7
bMEtj211GYI1hV55ywtOlPcd8Ub3b8K2CQK4j87OLfTM/mltIEEBAADMj6bzdSYfSiSfv+cKufin
V8pweUy6Mx3Sl+txSwJKg4RqVNvrmwTGd3+3KtflvtaO0oh87M5L5a5tD8p7Dz9HXnHwi3bLLKCd
JWcSRR8AAKmmA7bW9ekg/7abPyUf+dEl7nrowK+zfl3Lj1f7933jb/ydzvT19xoQrO3aX25//F55
w+aPu181s6DLCECrIAAAkFqNwV8H7T+9+VNy5cN3yO/0HChirRv450u/ntYErMp1S8bz5U3X/w1B
AFoOAQCAVNpz8P/ew3fIAR39Ug6ri5bkjQsKAzf7nxoENJYUgJWUnABgzy5W/LcraJr2A0g5naHr
mn9j5t8Y/Kdb318oHew1CPA9X958/Sfk1t/c4woGWzII4L657/tmo/YvOTWACQoAAKAJjeY+E7WS
vO3mTy/p4N+gg33WC0SMlXfd8jkphRUXBMxUVwAsteRkAACgCdUw3uf/tQeulW/94mY5qHP1ksz8
96QFgnk/L8OVMfnL2y9yBYbTdBUGlg0BAIDU0DX5rB+4grx/vmeTPKtrjVTCvbf1LRUtLOzM5OXf
Ht4idzzx03jrYX2LIbDcCAAApEKjw58O/lqQp+v9uv1vudPw2jJYv/eWx//LXffpDhcClgMBAIDE
23Pw1yWArJ9xOwGWmx4u1JvrdLUHg+VR91iWOwgBFAEAgETTFLsOsrc//l9u5q+/16r8larC18E+
52fl4eEn5Js/u9ldew0KgOVGAAAgsXTNXXvx3/30z+Xc6y9c8cF/Kk39Bx63YKycxJwFEKfQGh+Y
Tnx1lj/lCayEuNGP52b6n/zJN926e2em0BLtePWxFTI5d1bA2w47zWUk9L2pWwOXW+OOMPUeyn1i
Jsm5hxJ+AkicRpc/pS1+b338HteWt1V68evsPx9k3cmB5ajqdgO0huQMbpgdAQCARNm9xe8nXbHd
fvlVLTP4N2gQ0JHJrcisH1CJWQJgBaAJrJAg4RotfjXtrzP/pWzxuxhWYhfCPu3ZBhh7S9g9NDkB
AIBUa7T41VP4/uLWf2r5wV+1VACA1GEJAEAirFSL3/mKtwNmVqDsD4gRAABoeyvd4neufM+T0UpR
3nLIeumo70xYiR0ASDcCAABtrVVa/M6V1ilok6JWqf9H+lADAKBtTdfidyW7/DVLB/+8n5OXHnio
+yd6MiCw3MgAAGhLrdbit1namXC0MiGn/s4xcuzal7hgQP8MWG686gC0nVZu8TsbbfqjRxC/eu2L
XSEgOwGwUggAALSV6Vr8xif7tf6BOp4YKYYVOahztbz+916lyX9XEAisBF55ANpGq7f4nY3xjJRq
FfnC8efL6nyPWFcEyPo/VkZyigD1XO/GB6bnuljR6xvtafcWv63f5W9PGS+QpyZ2yh8+77Vywm8f
6TIWXqut/XMfnVnjHpqQ45vJAABoeY0Wv/prO7T4nW7wf3piQP7gOcfKV177/nj7H5X/WGHJyQAA
SKR2bPE7lc78dfA/6zmvlm+s/3Cc8nf/R+ofK4sMAICW1m4tfqcKPF92lIbc4H/Z+o+4QV+zyAz+
aAUEAABaVru1+N1z8B8qj8pr1h4hl63/sPsrHfx1GyDQCggAALSkdm3xq7S4rxJWXfr/I0e9xf23
FS36Y/BH66AGAEDLadcWv43BvxbV3HO4/JQL5cgDDnFFf77xW+46I93IAABoKe3a4nfPwf/bp3xc
jlv7EhcI0OoXrYgMAICWEbf49eXup38u515/oUuht8PhPvHgry1+q25/fzz4Hz6ZyQBaERkAAC2h
nVv8Nqr7NWBh8Ee7SE4GwHVoqn9gelwftKhdXf7ENfq59fF7ZHW+182g20HWD+R/RrbJZ171527m
r4f96J+1lan3UBqGpuIemqwMAC9aoO3s3uL3k/K9h++Q/fKr2mbw11n/tvGd8ubnr5e3v/B17nFn
fAr+0PraLEQFkCSNFr+6bt7OLX610c+l6z9U3+5nafSDtpCgAIA1gNnFPciAVpCkFr/a6EfrADSb
0b57/VkDaE5yUs3JWgIA0DaS2OK3fQd/pBEBAIBlR4tfYOURAABYVrT4BVpDgmoAALQ6WvwCrYMM
AIBlQYtfoLWQAQCw5GjxC7Se5AQAjZ0ZydmhsfjoBIgVMF2L385MoS0a/Uxt8XvZiR9Ofn9/dlPP
rHF9ohV4Iy0BlgAALJlGlz/VaPG7KtfdFoO/0na+T4xtl/OP2DDZ4jfw6PKHZCAAALAkaPELtLbk
LAEAaBm0+AVaHwEAgEVFi1+gPSQoAKB6ZXbJqgLUgUZpqtnavas/fS9e4dJCLiwfbfGra+dfvO97
8q1f3Cy/23OQlMPq8j2ABdD1/R2lIXe4z2XrP+JeOfrKSk+LX+6js9NrlIwqwAQFAEiLxgyzUYzl
GzPjGUfu7Wojd1IbocDSosUv0D4IANA2dBA3Rufzxg3+Y9Wim5/d88yv5M4nH5COTC7OBoiVrJeR
Nx1yghv0e7Od4ps4G6D70T3jEwgsgT27/Om110xA1AZ7c/WxVsKqZLxAPnLUW9x/N3oXAElFAIC2
0Bhc1I7isHzr5zfJNx66zv35SGVCBkojk4N8I2X75fuukkpUlZesea6c9+Kz5Ij9ny9dmUI9EIgm
Px8LR4tfoP0QAKCluXV+K27G/8Mn75OL7v1XuWf7r9yA3xHkXUZAZ/cHd+43WRPQMFwZd9mCWx7b
6jIEawq98pYXnCjvO+KN7t9oa9pGZgDzl8QWv+z1RxoQAKBlaTpfi69CieTz91whF//0Shkuj0l3
pkP6cj1uSUBpkFCNans9j8D47u9W5brc19pRGpGP3Xmp3LXtQXnv4efIKw5+0W6ZBcwdLX6B9pWc
AIBWwLNro2vUaCKjg/zbbv6UXP6LW+Tgrv3cwK+Djn7MprFLQGeoSgOCtV37y+2P3ys/evIBufyU
jye/tesSosVvwkzdAEBL9eklayMVnQDRenbvIPcpufLhO+R3eg4UsbapgX9fNCDQmgBtRZvxfHnT
9X/jggFN9+oaNppHi1+g/dEKGC2l0UFOf9Xe8d97+A45oKPf7SNfrElJXLAWuIGfIGDuaPELJAMB
AFpGY3//RK0kb7v505OD/3Tr+wulSwsEAXO3rwBtKX5GS0G3+T09MeAa/Vy6/kOukFQbRtEsCmlE
AICWEUY6KPvy9QeudR3kDupcvaQDC0HA3CxngLYUpg7+l63/sBv042wG7aGQTgQAaAmNrWQ/efrn
8o/3XCFru9ZIJdy7sn+xEQQ0T1v8aoD2tWUK0BbT3i1+Tcpa/AJ7IwBAS9A5mKaRP7P1chlx+/e9
vfb1LxWCgNnR4hdIngQFAHvuYeG/42NMpvtoLfG6suda+97z9C+lJ9sxucd/uRAE7NueXf40UIsP
yVmsssylM12LXyt6LgRp/71xz9z3PTOZeyQTFACgXenavw4m//ehG2SgPCK+FzfwWW4EAXubrsVv
1s+4tfNWp4N/Laq553D5KRfKkQccUu/+6Lf6QweWBQEAVpQO9O5gn0pRLnvwOukIchJFKze4EATs
ksQWv7R+BnZJTgBA9qqts1cFPclPrOvtv9IIAuJTE3WwvPvpn8u511/ogjTdNtlov9zKNL2vJ/vp
zP/bdHucG+6jzd1H4+aibS85AQDakq2nkvWwnqHymPgtkp5NcxAwXYvfOO3f+nc93dKnY5hu+WPw
B2ZGAIAV1VhL1gBgsDTiWvSuxPr/dNIYBNDiF0gPAgC0hI5MzqWcV271f3ppCgJo8QukCwEAWoIO
Pq02+DekIQigxS+QPgQAaAmtvq0syUEALX6BdCIAQEvI+ZmWb86S1CCAFr9AOhEAYEXpSWzqTYec
IGu79pdyWGnpw1mSFgTQ4hdILwIAtISsF7jDf9qhRWtSggBa/ALpRgCAFacDqu7bfsma58hYtUQQ
sAxo8QsgSMoliBvKWJE26FG+UvQaNRrvtAp3JrtY12jmA0f+ofzoyfslapM2W41MgHrT9X/TNo1n
ktjiVzsVYoHcLTS+R7TafaJl1K9Ru9yjZkMGACuukfY/fM1z5cDOfjc71cCgHbTbcgAtfgE0EABg
xelgr4O+NgJ68yEnys7iiGT89pnRtUsQQItfAFMRAKAlNHYDvOv3z5RTf/cYGSiNtFVat9WDAFr8
AtgTAQBaQuMQFz0O+ENHvtkVBeqJbnqme7to1SCAFr8AptM+d1ckni4BaIHaUQccIpefcqFbFqhF
ujWwfV6mrRYE0OIXwL60z50VqaBBgA78x619iauqJwiYP1r8ApgJAQBajm7pioOAwwkCFoAWvwAI
ANB2CAIWhha/AGZDBgAtiyBgfmjxC6AZyQkA6o0A+TVuiDjjRxshCJgbWvxiQWa7d/D38b01WtBV
bhnJCQCQWAQBzUlii18tCgWwNHh3oS0QBMyMFr8A5ipBAYDmZMhPNXcN2hNBwPRo8YvFwf2zufun
XqdkSFAAgDQgCNgdLX4BzBcBANoOQUCMFr8AFoIAAG0p7UEALX4BLBQBANpWWoMAWvwCWAwEAGhr
aQwCaPELYDEQAKDtpSkIoMUvgMWSnACAHSxp28GymzQEAbT4xZLiHpq6e2hyAgCkXpKDgFKt4p7f
7Y/fK2+6/m/c77N+xu0EaHWeO+K55gKYy0+5UI484BDXtdA3fqs/dCDRCACQKMkLAj4htzy2VfJB
1v36pus/4Z5j4AUS2dZvSD518P/2KR+X49a+xAUCtPgFVh4BABInSUGAMSLvvPWz8vf/+S/uV/3v
9hn8jVTCqhvw48H/8MllDAArjwAAiZSUIEDT/NWoJp/e+m33a5z2b/2ZvxHjlpQzXsDgD7QoAgAk
VhKCAGuteGJkTWGV+1X/ux1k/UCeGNsu5x+xwc38K2HN/TwAtI4EBQCUsKauhLUJiQgCRFzqvD2G
/njWv218p7z5+evl7S98nXvsGZ/Bvz1wH23uPtr6WbhmJCgAAKaXhCCgXejg//TEgJz1nFfLpes/
JB1BXnxPcxemXZ4CkBoEAEgFgoClN3Xwv2z9h92gHx9YxOAPtCICAKQGQcDS0Wu7ozTkZv6Xrf/I
ZBGgp9sWALQkAgCkCkHA4tNrOlQeldesPcLN/JWuJDP4A60tOQGA1mRQvzLzNWhco5QjCFg82uhH
9/pr+v8jR73F/beViMG/XXEPnX0c0ftoMmoAExQAAHNAELBwtPgF2ltyMgDAHBEEzB8tfoH2RwCA
VCMImDtd26fFL9D+CACQegQBzaPFL5AcBACA6AE7vutYp21r9eAa/b0eYaupbuxCi18gObi7AXUE
ATOjxS+QLAkKANi/Mvv+lcY1wr4QBEyPFr9pwD00bffQBAUAwOIgCNgdLX6BZCIAAKZBEBCjxS+Q
XMkJAMhepS17teTSHgTQ4jdl9B5KR9Xm7qMJkZwAAFgCaQ0CaPELJB8BADCLtAUBtPgF0oEAAGhC
WoIAWvwC6UEAADQp6UEALX6BdCEAAOYgqUEALX6B9CEAAOYoiUEALX6B9CEAAOYhSUEALX6BdCIA
AOYpCUEALX6B9CIAABagnYMAWvwC6ZacAMBa4aPJa4BF1Y5BAC1+Ma1m7yFp/7xIWya2v+QEAMAK
aqcggBa/ABQBALBI2iEIoMUvgAYCAGARtXIQQItfAFMRAACLrBWDAFr8AtgTAQCwBFopCKDFL4Dp
EAAAS6QVggBa/ALYFwIAYAmtdBBAi18ABADAClmpIIAWvwBmQgYAWAbLHQTQ4hfAbJITAFgRPpq8
BlgR+woCfLO4b0Na/GJemr1/8HmJsbh3HgAzmi4IKIZl8Y2/4CtnjHHBxNMTA3LWc14tl63/8GQR
oO4EAICpCACAZbZnENCd6ZCx6oQbpPXvtHJ/LnTQz3i+VMOajFTG5Q+ec6x8g8EfwCyC2T6hPQyI
lZ4p+W9Mx9b/h5WnA31oIzlu7eHyn+deIu/b8gW5+pEfSCUMpTfXKTk/4x5kZK1YqweP7B4U+J7n
/kS/xkhlQqpRVQ7sXC3fOO7DcuJvH+X+nWLmj2bp/UHXUblPzCZ+byVBQgIAoP3ozF0H8N5sp1y6
/kPyR4+fKD944j753n/fIQ8PPeGeUM7PSiHIugE9zuIbsdbKQHnC/Vnez8rJv3O0vPTAQ+Uth5wo
q3Jd7gbOwA9gNgQAwArSIEAHbE37azZAP979kj+Qf/nZjVKzodz7zMNy57b7pSPISaSnPUskWS8j
5x+xQcIolKMPPFSOX3v45DOIbOTa/gLAbAgAgBXWWPPXbIDO7nUWr0FAg67rx4GCsuKJJx2Z/G6P
uhaFblmAwR9AswgAgBbhtgOaeBU2jHTdX1ytQE+2c69HqAO+alT+6+cBwFwQAAAtRjMCUwf0uDhr
dwz4ABaKAABocXPdFggAzaBaCACAFEpOBmBqe0pMr3GNAGA63Edn1rg+cYlO2yMDAABAChEAAACQ
QgQAAACkEAEAAAAplJwiQKpXmkAVIICZUAU4O60ATEYVIBkAAABSiAAAAIAUIgAAACCFCAAAAEih
5BQBUrsyO2oAAezL1Hvo3udPQSXsHkoGAACAFCIAAAAghQgAAABIIQIAAABSiAAAAIAUIgBIoYgK
XwB74L6QPgQAKaLjvueJdOb4sQPYnbsvMDlIleT0AaARwIysFcn4IsMjNbn9gTE54cVdElkrvjGp
esED2EXvC54RKVetbHlgTIKsuPsCkcBMkhMlMRVMkWxgZGw0lNvuG3PPmpQfAN8zUqxEsuXBMcnk
TD0AQBokJwNAJ8CZGXHRvv66/6rk/NgBLFxX3pfugi/Fck3EJwGwT41xJhmnAZMBSA0rEkVWgqzn
MgDFinWpPxcUAEilRhbw1vvHZGi4JhnfiE3I4IbZsQSQIvpmDzJGfvDQhPieuNQfgPQK6zOAu381
IaPDNbdMiPQgAEiZwDdSq0Tyw4fG3TOPC34ApFHgGamGVu5+uChBwZeQwqBUIQBIER3rs76RkZFQ
brxnVMKIQkAgrRo7AAbHQrn1p2OSyWoBYFqvRjoRAKRMNbKS6/Tl3+4cqW8NNNQBAClUq4/2m344
LGMjNclnPO4FKUMAkDIuCxAYeWpHVe54sLEdkLAfSBstAarWrNx076iIz+w/jQgAUkgrfcfHw/iN
Tz8AIHU05tci4NFiJFseGJdszqMeKIUIAFJIlwEKXb58545ht/7ntv6QBABSo5H+/+qNO2V8NJRc
QPo/jQgAUkgH+1zWk0efLMuXr9/prkDjhgAg2fT9r7uBBsdD+dLmnRLkvMntgEiX5LSE01d14wOz
MG67T77gyZc375Q/O2W19Hb67vJxNACQbBrs6/a/L1+3Ux7fVpG+VYHLCjpkAmfmOgHq/0tGtyQy
AKlkxeoyQNaTx7eV5as3DLiCILIAQLLpOB/3/rfypWt3SL7Di9/3nP+TSgQAKaZv/K6eQD79nafk
zp9PuFoAGoEAydXY+/+/Pv+YPLWzKrkM9T9pRgCQYo21wOGJSC785lMyXorcDIGCQCB5NLjXTN91
d4/KpjuGpKNDO/8l73mieQQAKVcLrfT1BnLzj4flomt2uCwASwFAsjRS/6WqlT/+x8dcETBd/0EA
ANcMpKcvI5/Z9IzcsHXUFQixFAAkg2b09P2sGb4/+txjMjIWSjaj+/6T8fwwfwQAiAt/PZGxciRv
+exjbpaghUIR6UGg7VVC6zJ7muH7t5t2SqdL/TP6w932AXGDfUfBl7GJUN7y2UfjtUHDYUFAO9OT
/nKBkRvvHXUZvp41WZb4MIkAAJPC0Eo+78uVW4bknE/+erIYkMkC0H508NeZ/033jslZG/9HSrV4
1k+RLxoIALAbTQ329WfkyjuGZMMnfz35d1osCKA9lKu7Bv/Xb3xEjG8kk+HAH+yOAAB70aJADQK+
d8eQvOHvf+26A2rrUM0QAGhdOrvXjJ3u77/xntHJwT8IqOnB3pIRAMTt7Hd1s2p0teLXeV+TatVK
36qMfO+Hw3LK/35Ebrt/THw9MjSypBCBFqQBugbrkbXyd995Rs755KNijXHBexTO/17AfXSaa5eQ
AulkBABYErqGuKoncAVEp33sf+S6n4yK5xl3k6GKGGgNjSNQNEAfGg/ljZ96TD76lSfcg8sw88cM
knMY0G5hKhaHkVoYyapu380uTr/wETn7lb1yybt/S/q64sOD4gYji/PdADRP33/atEsL/dR1PxmR
t/3Tb2T7aCh9B2akVtO7ok5f9e9Zvls8ybmW3Loxg/iF7goAjUhnhydX3jksh73jZ7L5P0dcJkAH
fxcIRNxigOXgBv56ul8H/8Gx0BXsaoA+XAylq+C5Op548FfJGbCwuBKUAcBSamwd6i74MliM5OxP
/I+ccHi3/OXr18iJR3RPHiPcuDF5Jl4qALBwjW5+muZvFOXqwP/l63a4I72f2FmVrg7ffSOW59Cs
JAUACSnLaG16c9F1RZMxcv3WUfn3e0ddIHD+2Wvkpc/rkJ76TUg1tg5qV8EGggJgZo1gW5fXtKBP
Z/mNQV9tH67J128ckC9u3iFPPFWWfIcvPR0eB/ssG3d8ciLGm0QEALYWGBHTSapreTSKjno6fZdm
vO7uEbnlvjE5eHVGzn3lKjn+8C455vmdLhW5Jw0KSEgCu2us0jcGe6VL+379yJ6nh2ryzVsHZcsD
Y/KjB8ZkYDSUXN6TVasyLijnVL/losuhvu6u6Fyu77iU2jwAMFYusN7gf1xf6pS1t4pfOEmq45EY
iXNhWFKNVGNvV+C2B24bqMrff/sp+dzVvhzYH8hbX9PvZiZ/esJqyQTidhB05Sk7AWaiqX0NBO78
+bjc9eC4/PTRkmz56agb9PU83w4d+HsC9/6jQddy0qmP59nqRNlGcqv7zoOPtHUmoP1Xad9xd0Yu
ObLadfZP/8oUVn/aFgeqYiSznC8LxBppSr0paRFSaTx0f3jg/hn31slnjPzp+jgYALCLpvt1pew/
fzkhP7x/zLXkHhitSXEkFJP3JJ/zXE//uOCWLNrKsFbXPm1UHT7k0R+v2br1nVURq9nntk1qJuZW
bI3XaWhyvaL08uvAr7ROIN8Xx2HDGgiIyJAVufD/PLmijxFoaVlPCllPxis118Cnb7+MG/B1lw2z
/VagSwCeeXjt0Z2yVYZa4REtRGICABPZWrw4vZDLgcXS2KOsgilFgIVVmQSknYDF1ditr0V/7hhu
L57ta0dOtBhrI79cbuvUf0NiAgAtyjBGl/4bbyW0iqmJGWYxQBMY91uTu5mZzrjwvP21f0VWvQhD
izJsbaIsxqu3pgEAYJHo1r8gr0v+tw4Gz5S0AL2d1/9V+wcAmza4VMwLfnPnbbY2URTjswMAALDI
TGT8vHjW3CI3nFqWbVvbfqxp/wCgzhVliAkoAgAALA2rdRo9S/O1l19iagACOx5WpbtkRLrYJAMA
WFxGxEbWGplY3K+7chKQATBWewHs/P4rxqy1X5FMl27NrK3cJQUAJIu14nmZqDI84lUqX3PP7ZJ1
bT/OJCAAaNBmDDYQT5MalNACABaTjiu2I+d1lhfzq66kZAQA9Z0AxpjbbXVMdwL48SG1AAAskDWR
+HkdVW7tq/iVeAdA+0vEk5jcCfBo7VYbTlTirYAAACyKyAQFbQJ428M3PK++A6B9WwA3JKYIUD3S
Jx0iXlnEdLMKAABYNFHNSmgTNWYmZKYcFwIO/vu6ERtGXzeZbgoBAQCLQA8B8jJReWTcq1W/6r5g
AgoAVUICgAZjjecP6VaNRfipAwBQHyptsTA6WkrS5UhOAFCPyLxi7RtRZWRct2xQCAgAWBBraibr
VpUv3b7luHF3BH0C1v8TmAEQKRSHiyK2mLjkBgBgZdjImsgMJWXgb0hOBqBeB6ARmkZqGrHREAgA
MH+NBkAj41659g33dRKy/p/IDIAGAiaKhkRsKJw8DwBYEG0BbCfi7HKyJCgDsCsyMxMTl0XlYStG
qAMAAMyPW//v1Ynlt5K2/q8StafRLQNsuMIffyQ32NEZ3WYynettdSwSI21/bCMAYLkZz9Ymqias
Xe/Gl0Hrjp9PimRlAFTfsz3ZemTVitksflaXARL1AwMALAdd//f9qDY+cOTI8G3uO26SRI0nZjku
4/KyRiO1ztPvO8AG9nHjshyRFWsS+FwBAEukavL9mag08M8TmV9+QB6JJ5dL9L1WRMKWAFRjGaAy
0Lk2uNVkOk601XGWAbDk9AQK3xjXhbrZaLOmsekC2lYFvmnqe2lrrLDJ/lhzeR5z+br74ntGPK2z
auK6Lcb3A5pjPFstVkwYXSdXnRMm8ZTZBAYAeihAHKlFa396ve/nT5TahKZtqAPAktH80lgxElue
W4Yw2+FLNmPmFQRo4DA8VG3uvhQY6eyY/S0w5+fhG+nsnP3r7ot+v5GJUKTS5HVr8nkAC6Pp/4xv
w4nBo0aGb9sSf7EmX6Tto9mJSpuJlwG6Tr5nTZT3HzTGWyO2ZsXdboDFpbPXUimS1xzRLa9+YZeb
peqfNeNbtw3Kw0+UJZf1JJpDKkA/N5/x5LzT10g+u++sQ+Ox/PKJsnz3jkE3296XuTwPfaj6bnps
e1X+5ZaBeb2z9N+Xy5Gc+tJeOfp5HTNet7k8D2ARaPW/iSrDn5jI/PJv5ZkNRraY2iJ83ZaSzAyA
LgOsuzszdsMR2zte/1/fNNme8215UH94mZa6+kgEHVSrpUhOWtcj7z1r/zk9p987KCfnfvLXks9J
czN5TZNrujwSyWWN/M1bD2rq+93xwJh8+/ZBCfx9N8iez/N44NGSCwDc42r+KTieMVKtWHn9y1fJ
n5zQv2jPA1gYDW89P6qMVH0pf0E2ufR/kyF9e0neLoCGZ6+rp2vsDTYs6xQpuc8VK6++BFANrZQq
kft1xo+aFf04+5Wr5BUv6pLxYihes2mDOr1N7Riuue9T0a83zfcsVePHMjjW5OSlyedRrsbfb2C0
ya+7L/UlgNmu25yfBzBfViKT6dQw+8ejmUdHdWt50loANyR3UNxkQv3BTVx1+E1Rdewmk+n0xWp3
QGBpaPFcxjeuME9/nfEjMG7A18/5yDkHxCn0eRQDNvW9fDNj6n9Pc3keMy0pNEu/RrPXbTG+HzAj
44mNoopnzUdl0zkVkQ2JvWDJDQCUFgO61I1/vfg5zZ0mrogD7cv3RKJI5JSjeuTEdT0yNhG6PwOw
UuK9/zYcH/ntrP8fbmUrYXv/p0r27Wbrupr+/Pxy+K2oPDggJqA1MFpKY+vbX//hAZLJGFfsBmCl
mJoJusRa74sPyUOhrLs7SGr6XyU7AIiLAQMtBhSxF5lslwZ0C1y0BBaPywJYK684tEv+4JWrZGw8
FN9PZL0R0OKsFeMHUWV4IFMcv8gV/7lJZHIlPAAQqf8ATTAxcXFUHh7QH/C+66CBFVCf9X/4nAOk
u9OXWkgaAFh+pmYy3Vr8d9HITS8f0J1kSZ79q4RuA5wq3hI4ctORAx1n3HORyfVcaCuuewpbArE4
dLzWkvx5jttaDBhFVn7/dwvy5uP75Cvf3y69PcHMgYCuFcyhb8Buj3Ffj3Nez2OOj2Oqye83hws3
9THO4Z8BM9PZfxBE5aGBoDhxsVv7T/jsXyU/AzA1C1AqXazpHbIAaEU6Dn7gDQfIfn0ZqehxVq34
IIFEqs/+bdSY/Sd67b8hHQFAvRbApXVsdFGc5qEWAK3DZQGsuMZAbzt5tRTn0RcAwHzsWvvXSWJa
Zv/pyQCQBUAbcB3+rMhfnrW/rD0g67IAc+wNBGDO0jn7T1cAsGcWIGBHAFbOdMveOthrFuCgvoz8
xelrpFSae3dAAHPhZv++Lg2nbfafsgCgsSPAGlcLUB0patFHEk94Qutzs/1pHmYjC/Cu162R5/52
XoqlyHXmA7AkaibX79kovLhe+Z+Ktf+GlN1ajBXZ5OkP2trKueIFekYAtcRYVuOlSH7xeGnaIr84
C2BlVacv7ztrf6lUIjEtfoilPryFfAArwtrQ+F1+VNzxg56S/xnX8z8Flf9TpSwAUOe4MwKK3z/6
+7Y2scVke/Qw80Q3e0BraESa2ujnn698RnaM1OLdg3uEoHpKnv7ZH69fLS95XodMtHBBoD7OxsFG
8/lVT+mm+yFWhEatnud5En706ZtfMi7PrHHHyK/IY1khKQwA1AaRCy7wPGM/ZqPamBh/AZuZgbnJ
Z4zc83BRvn7DDncP0hn/VI0/K+Q8+asNB0gYxkfttiI9jKivK5j3R0934K4HsKz0YDi/4EXloe+P
fX/dHW72v+X41E0EU9AIaBp6UuC6uzNjW4/8Qcfr/vOzXufBF9ri01UxhuZAWBaFnJHPf+8Zeeep
a1y6X2fBUyv+G1mAN7yyT770oh1y1wNj0tHhu4ZBraBRl3DU8zrkV5cdOu+HpLFPPhvPQzSYAJae
jcTLGBuVi71Wzp2QCzzZ9GBrvLGWWToDAKVrPevuznSXg8+Oejte62V6X2UrI6EYo0sCQPNcd7rm
P13p7P6p35TlS9dsl/997oHuVMCp03zNAujMX48N/sgbD5QzH3hYRD+n8X3m8T0n/82MnQDn9jz0
eN7uwjK/ZRrPfY6PFYh5Vvycb2tD52679qiibFjnuUlhCqV0CUAZK89eF+najxfV/tpG4Zh4fjS3
/qrA/ESa1i/48pVrt8vjO6px8d8eh1X7/q7jgtcf2StjRT0uuPVmyY06hvn+Ciwbl/rPe7Y69n2t
A5MNm1I7+LtQaNkufCtqLAVce+QPbXX4sya/vy4BTFkHmjrV4Pe7TyG5HtNfj+bo5hM/Y+Tx7RX5
5yuf3ue2wMnjgs89QDLBnvUCc50Cz+Vn1ryF7ACY3waHuTwPPpf37WTaLHIzf5f6j86VC2xqU/8N
6Q4AlC4FHHtb0F3OfjYsPnWt+PlArM7P5npzBeYmiiLpKnhy2Y075JePl926+p5r/I3jgl95WJec
7Y4Lrrk/4/UJzEWkDX807zYuUfWN265dV5SHNhmRjXvk3dKFAECXArbc7pYCVkW/eaONqkWNEkUL
RYAlpCFmJmNkYLgm/7DpqX1X+tdjUa0F6O6oHxfceisBQCurmfyajI0mPjNxzZHXyrqtgWw6J5Xr
/lMRADgbI9lg/W3Xbi1pdCjijYsJNAtAGgBLSgv9Ojp9+c7tO+WeX01MHg2825u0cVzwszvkTa/t
l/Hx1qkFcH0AQjv/D/oAYKnFW/6CsPj0td3F4LNa/J22hj/7QgDQ4OoBTvc1OtQoUaNFEaks9WsT
6aa1AIFnZLwYyae++1R8MfYxu9fB9oNvONAdF6wDp2mBNICu4Wd8M/+PwHDgEZaQrvtnfc3saobX
NfzZeo0uBTC50623S3jl209ja2Ax+OyIeeYoP9N7mq0MhWK8Zd7nhDQJIytdHYFcfeeQ3H7fqBz3
+90SRlJf649pFkD/7PcOjo8L/vQ3t4nXu3JvXw1GdPB/7JmK/MstO+cVimiL43IlklNf2itHP7/T
1T/o8wQWhx70k4nE+JGE5TduW7e1JAXrp3XL33RW7g7SkoyVrbb2tJiqbLjizI7y827zMt2vsrWx
mojhWmHJ6Lins/pPfucpefULu6cdUHVo1IH3/LMOkP97804pV+08q+gXrhEAPLKtLB/9yuPza1Wo
jX9GatLV+btxAKDNkBb+0IBG2FwTP5+JKkNnFK89+lrJM/jviffbXozVXQFaIBJpfwDdEWACTyxF
gVg6cRbAl1vuGZFr/2PY7QjQ+oCp3C4BK3Jgf0b+/PT9ZawFjgvOZoz09mdkVX9G+uq/6u+b+Vjd
l5HM6ox05rkNYbHZqsn1ZWx15JritUdf49b9U9rsZya886ajPaE3WL+k/QHKw2eKZKx4gW4MiNeN
2FrMNdjXa6BZe/77KT713W1SqWk6fO8y1MZxwX9++ho59LcKMlFucrPKXF+zTVroYUDVqnVNkZo2
1+fB56frveruz7Zqsv0ZWxrePDEyerab0KXslL9mEQDsS71J0MR1x2y21ZEz47WkbCiWnQFYJFPL
kGzcA6Az78tdD47Jd28fnPagIF0q0Ffg6p5A3vcHB7hlAwB1URSaTG/Glkc2j+d/caZu8ZYtx1H0
tw8EADPZemRVU0caBESlsbNdkyDxUndiFJaPDudBYOQzm7bJeCmaPBRoqkZm4A+P65OD+uPzq+bX
UQ9IElszmW4/qk78wA3+mzZYkQvjtu+YFgHAbOpBQPGGo6+xlZFrTLYvI2Krs/0zYD40C9CR9+X+
h4vyjRunPy64MeDr6XlxV0Ag5bRGywSejaIwspW/dk1+jr3dEzFNrpGlE7ePZtTbBU+MjZ5tK8Ob
dX2JIABLRUtNsjlPPn/lM7JztOayAC1yCjDQenTw1xotk7G2Onym1m5pDZer5cKMCACaou2Cjwt1
PUlTS3EQoJmAqLz3+axUHaWr6mi+Z9Pu+3USWeuOC/7v35TkS9/fPln4tzBzeV02Y48Chjl9/eke
S7Pm8jz43IX/XFr5GqqoFg/+gbW18TN0uZaK/+YRADRN15EuFNn0oB3P//JMWxnZbPIH5vQVKBKy
xoRFpQcF5QtGvnLNM/LEjsq0xwUDqWbD0ARdgRhfbG3kjInNR10Xt/k9kiXaJhEAzImuJ2kQcE44
PjL4eikPXOjWmEzW0CcAi0lT/tmMJ08+U5F/uvKZfR4XDKRU1WRX+ZG1/y61kZMmNr+MwX8e6G43
ZxoEWCNbJBoTs7Hj1LvvNtncVSLWk6gaidEabWDhtCCw0OHLZTdul3ectkaee3COdrmANvnRff6V
kc0T17zkDJeF1TX/TYaZ/xwxWM2LLgeYSE7+ZW7iuiM328ro67UARfycdgycS1sTYJ90XUk77Q0M
1eQzVzzFVj+knNUmGGFj8NelWFfj4Dq3Gu6780AAsBA3PK/c6BOga1AiwYAEBd8FAY2qgFauoeGx
LW6N1Fw0c+1FpBZad1zw5bfukHsfnv644KY18z3nU83S7Nedrvvhcn6/+T5O/t3ivk/mcj0bXCt2
P5Kgy48qw9e4JdhND8avHqr9540AYKG04GTDFb6uQfnFx54b1Uq6TbAeBMzn7oa2tBQ/6vqNsnFc
8Ccv3xZfmqU8MG8pngcwX/p6jGwoXtbTbqyRrZ4xcc3hZ8iW47QeK87EYt4IABaDNp3YYP2Rm04e
KI6OvD6qDl8jmS5fjBeJHiYELEAY1o8L/tGQbLlv1PUF0KOBgWRz0WjVZVVNMGBrY68vXv2ia9x6
vxv46fC3UAQAi8WtQV3gaWSqEaqV6ulislZbU4pYGlKkhCZ9mvmYq8ZxwX9/+bb4KN760cDNfC/3
OXP8hk1/3bl+4Wm4REeT120Rvh3agTt4zUSmcEAmCkubNbvq9vhvuEKL/ZhULRICgEW1UaPSSC6w
3sRVL7pWwomTIys3m0xvIDbS3QPcvxJMB2ntyZ8JjPt1z4/G3zf+fC4mjwveuuu44Om+x55/pu2C
9c90GaFZsz0P/Xp+4+v6zX/dfdF2xjNdN/f45/E80LZqEhT0HRTpVmvNqmp2Na70P4fBfxGxDXAp
bDSRVqaObz7630U23NZx+ke/ZzLdp7vGgWE1FGP8pfi2WDk6SJUqVkYnQqlFdtoBV6O/xnCpxX1z
Hjrr/0BrAV72gk63Q0DN9HVCa8U3RsaKzd03m3keSrsV6lLEaJNfd1/0+xXL0YzXTc31eaAd1SdI
fiEQawZsFL11/Nrf3+y2WOvWa2b+i27O9yDMgYtY9b5voo7X3/86E3n/R4yslrBYzwRwhltS6K0r
lzWSy+i9apZRWUQmSpELFOb6BtRXjAYPPR2+eO5s4Fm+V/3v9d/oQDubpp9H/etqfcJEE193X/T7
5bPGNT2a8bnM8XmgzejOKT/ji5cTW524xi/t/NPRW9bvpLPf0prr/QfzYjWdZbtfe/PqML/6MpPp
iLMBUU0bV2gWhp9DAuiqpTbvaYbvxan5+WgEAXNZUNLZerMtqubyPIxZ+ImEujimGYVmzOV5oA3o
wG/EE79gxMpO60V/4pZPlVvvJ+W/lOZ5C8KcxZ2qXB62cOb9pxtrLjN+brVUR3SLayjGc6upljKn
tmNE7106m9c4r8mH7wrz4gxAc0NfvfDP/TqH79PQxPdbyPNQc3ku8ecvz3VDq6mXsFqpmUxHRsQT
Wx27xi8NxrN+N2Fyr5Bm3xqYp2ZvV1gUu17YLhtQ6DtPxHzMZLp8WxmOt7VQHwAgsVyqJxTjBybX
L1It3mRN7XMTV73oJveUp0yUsPQIAFbClNRW5+k/WS9+5/vFRie5U62qo3FzCwIBAInRGPiDwGS6
JKqM7BQTfKF4zd9+QmRTyKx/ZRAArBhrZN3WoHF0ZceZPzvJiD1frD1ZF3ltdYxAAECb22vgHzDG
XhRUKheP3PTygXjWz1r/SiEAWGkXWE82up0Cbr3LBQLWni+yVyCgPRv4eQFoA00M/HqIz5bjtS6K
tf4VwoDSKlwUvGGyveVegUCtqO+Tmohrg8nPDUCrse7QHq3q9zLGBJ2a6t97xu8G/uNCivxWHgNJ
q9kzEDjt/pNMEJxvbe3lxsv22LAoElW1gFzrBMgKAFhhrjm1DuiBDvo2LOnuvh0i8sVMtXzRZKqf
gb/lEAC0qj0Cga5zn9gvGt72F9aY84zx9zN+XmxtPM4KxDvQCAYALBOrkxDdw++72b5fEBtVRoz4
d9lw4p8mwtpdcsMxI+7BMPC3LAKAVrdHICAn/7inww9eZvyO91oJX+ayAjYUCUsiNpoaDCh+vgAW
Qb1TUzzoB2ICMdlesRXtYxLuMNZ+wes96Itjlz9LZ/4xBv6WxwDRNqyRY2/3ZcvxkycLdp61bX9b
eeJt1nrHGj/zcuNnu6cEA1pao50GvXp2gIAAQJMarRmN3m+M7tt3N5DJQb/6jBf0XmrD8dsnRjN3
ypYXjsVf2BrZsMmbWs+E1kUA0HYab7A36t7ZyUc/GQyIOc742WMkrPRoow0bToiEZc0OxAGBcc2I
6ocRUUwIoH7AtKsrEj0woj7gG9E9+65nZWVkzEo04QXdl9qwePuEN36XfP+Vo5PXjtl+WyIAaGua
FRBftrgofVL/m3f0lAYffblke19qq4PHGL/wconKPSbbH5cMVF3tgIguHbigoPFP7TSnQxIkAO1t
6kEL7gCpxkCv6oO9FfHzYrycnvUYD/jWlsQzXzPWjnqm62tjhVpJNjVm+vUU//7bLbP99kUAkBi7
NxbaKyDY+etjJL/qZbY6kBHrvUuMyRhjeky2Lw4ENCSoahZvjy25NtTggn26QLuJD47IaIfRXRoD
fTYuEbKR2OrwiA7+tla8y3j+XRLZmufZr46N5ku7Uvt1x9pA9t/EoJ8QBADJE58Rq+twjzzba3Qa
3M3JP+7pF5FSEBxj/d6Xm9pwaG1YEGveLp6fdcsF8e3BM9neLi0jANBOdGeeL7YypEV6I/FOIRsa
v+DZsHSXEXuXFd831hb9XHhJpvP3qgPf2i+u2p9KU/tj3Ua2rqtnGTmgJ0kIAJJv94Cga9ROLSTc
483e1V8oTI72lSDIRqG8XYxOF3ZbZQDQyowXSabHk9LIXXmp/Tgs5rygdzy03YeYaQf6hnV3Z6Rr
nZUtEqcFGfATjQAgleqnEjayBGqmwABAsuhA38DsPrUIADBF47jiKfTAIgDt6dmPRHGR3lSk8QEA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWET/DzvD5N5hQ96uAAAAAElFTkSuQmCC
__ICON_END__

echo "Building app…"
osascript -e 'tell application "NH Driver Quiz" to quit' >/dev/null 2>&1 || true
rm -rf "$APP"
osacompile -l JavaScript -s -o "$APP" "$WORK/main.js"

RES="$APP/Contents/Resources"
cp "$WORK/quiz.html" "$RES/quiz.html"
base64 -D -i "$WORK/icon.b64" -o "$RES/applet.icns"

PL="$APP/Contents/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier com.local.nhdriverquiz" "$PL" 2>/dev/null \
  || /usr/libexec/PlistBuddy -c "Add :CFBundleIdentifier string com.local.nhdriverquiz" "$PL"
/usr/libexec/PlistBuddy -c "Set :CFBundleName $NAME" "$PL" 2>/dev/null \
  || /usr/libexec/PlistBuddy -c "Add :CFBundleName string $NAME" "$PL"

codesign --force --deep --sign - "$APP" >/dev/null 2>&1 || true
touch "$APP"
rm -rf "$WORK"

echo ""
echo "Installed: $APP"
open "$APP"
